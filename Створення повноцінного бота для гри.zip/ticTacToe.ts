import {
  GameRuleError,
  requirePlayer,
  type ArcadeAction,
  type ArcadeEngine,
  type ArcadeEngineContext,
  type ArcadeEvent,
  type ArcadePlayer,
  type ArcadeStep,
} from "./engine.js";

export type TicTacToeMark = "X" | "O";
export type TicTacToeState = {
  players: ArcadePlayer[];
  board: (TicTacToeMark | null)[];
  marks: Record<string, TicTacToeMark>;
  activePlayerId: string;
  turnMs: number;
  deadline: number;
  status: "playing" | "won" | "draw" | "forfeit";
  winnerId: string | null;
  winningLine: number[] | null;
};
export type TicTacToeView = {
  board: (TicTacToeMark | null)[];
  players: { id: string; name: string; mark: TicTacToeMark }[];
  activePlayerId: string | null;
  deadline: number | null;
  status: TicTacToeState["status"];
  winnerId: string | null;
  winningLine: number[] | null;
  isYourTurn: boolean;
  legalActions: { type: "move"; cell: number }[];
};

export const WINNING_LINES: readonly (readonly number[])[] = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];
const TURN_TIMEOUT_MS = 30_000;

function choose(
  randomInt: (maxExclusive: number) => number,
  max: number
): number {
  const result = randomInt(max);
  if (!Number.isInteger(result) || result < 0 || result >= max) {
    throw new RangeError(
      "randomInt returned a value outside the requested range"
    );
  }
  return result;
}

function event(
  type: string,
  actorId: string | undefined,
  at: number,
  publicText: string
): ArcadeEvent {
  return { type, actorId, at, publicText };
}

export const ticTacToeEngine: ArcadeEngine<TicTacToeState, TicTacToeView> = {
  gameId: "tic_tac_toe",
  minPlayers: 2,
  maxPlayers: 2,
  create(players, settings, context) {
    if (players.length !== 2 || new Set(players.map(p => p.id)).size !== 2) {
      throw new GameRuleError(
        "Для хрестиків-нуликів потрібні рівно два різні гравці.",
        "INVALID_PLAYERS"
      );
    }
    const first = choose(context.randomInt, 2);
    const configuredTurnMs = settings.turnMs;
    const turnMs =
      typeof configuredTurnMs === "number" &&
      Number.isSafeInteger(configuredTurnMs) &&
      configuredTurnMs > 0
        ? configuredTurnMs
        : TURN_TIMEOUT_MS;
    const marks: Record<string, TicTacToeMark> = {
      [players[first]!.id]: "X",
      [players[1 - first]!.id]: "O",
    };
    return {
      players: players.map(p => ({ ...p })),
      board: Array(9).fill(null),
      marks,
      activePlayerId: players[first]!.id,
      turnMs,
      deadline: context.now + turnMs,
      status: "playing",
      winnerId: null,
      winningLine: null,
    };
  },
  applyAction(
    state,
    actorId,
    action: ArcadeAction,
    context
  ): ArcadeStep<TicTacToeState> {
    requirePlayer(state.players, actorId);
    if (state.status !== "playing")
      throw new GameRuleError("Партія вже завершена.", "GAME_OVER");
    if (actorId !== state.activePlayerId)
      throw new GameRuleError("Зараз хід іншого гравця.", "NOT_YOUR_TURN");
    if (
      action.type !== "move" ||
      !Number.isInteger(action.cell) ||
      (action.cell as number) < 0 ||
      (action.cell as number) > 8
    ) {
      throw new GameRuleError("Некоректний хід.", "INVALID_ACTION");
    }
    const cell = action.cell as number;
    if (state.board[cell] !== null)
      throw new GameRuleError("Ця клітинка вже зайнята.", "CELL_OCCUPIED");
    const board = [...state.board];
    board[cell] = state.marks[actorId]!;
    const line = WINNING_LINES.find(
      ([a, b, c]) =>
        board[a] !== null && board[a] === board[b] && board[b] === board[c]
    );
    if (line) {
      const next = {
        ...state,
        board,
        status: "won" as const,
        winnerId: actorId,
        winningLine: [...line],
        deadline: context.now,
      };
      return {
        state: next,
        events: [
          event(
            "move",
            actorId,
            context.now,
            `${state.marks[actorId]} зробив хід.`
          ),
          event("win", actorId, context.now, "Гру завершено перемогою."),
        ],
        outcome: {
          winnerIds: [actorId],
          draw: false,
          reason: "three_in_a_row",
        },
      };
    }
    if (board.every(mark => mark !== null)) {
      const next = {
        ...state,
        board,
        status: "draw" as const,
        winnerId: null,
        winningLine: null,
        deadline: context.now,
      };
      return {
        state: next,
        events: [
          event(
            "move",
            actorId,
            context.now,
            `${state.marks[actorId]} зробив хід.`
          ),
          event("draw", actorId, context.now, "Нічия."),
        ],
        outcome: {
          winnerIds: [],
          draw: true,
          reason: "board_full",
          refundIds: state.players.map(p => p.id),
        },
      };
    }
    const other = state.players.find(p => p.id !== actorId)!;
    return {
      state: {
        ...state,
        board,
        activePlayerId: other.id,
        deadline: context.now + state.turnMs,
      },
      events: [
        event(
          "move",
          actorId,
          context.now,
          `${state.marks[actorId]} зробив хід.`
        ),
      ],
    };
  },
  toView(state, viewerId) {
    const playing = state.status === "playing";
    const yourTurn = playing && state.activePlayerId === viewerId;
    return {
      board: [...state.board],
      players: state.players.map(({ id, name }) => ({
        id,
        name,
        mark: state.marks[id]!,
      })),
      activePlayerId: playing ? state.activePlayerId : null,
      deadline: playing ? state.deadline : null,
      status: state.status,
      winnerId: state.winnerId,
      winningLine: state.winningLine ? [...state.winningLine] : null,
      isYourTurn: yourTurn,
      legalActions: yourTurn
        ? state.board.flatMap((mark, cell) =>
            mark === null ? [{ type: "move" as const, cell }] : []
          )
        : [],
    };
  },
  getDeadline(state) {
    return state.status === "playing" ? state.deadline : null;
  },
  onTimeout(state, context) {
    if (state.status !== "playing" || context.now < state.deadline) return null;
    const winner = state.players.find(p => p.id !== state.activePlayerId)!;
    const next = {
      ...state,
      status: "forfeit" as const,
      winnerId: winner.id,
      winningLine: null,
      deadline: context.now,
    };
    return {
      state: next,
      events: [
        event(
          "timeout_forfeit",
          state.activePlayerId,
          context.now,
          "Гравець пропустив хід через таймаут."
        ),
      ],
      outcome: {
        winnerIds: [winner.id],
        draw: false,
        reason: "timeout_forfeit",
      },
    };
  },
};
