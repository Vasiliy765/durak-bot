import { and, eq, lt } from "drizzle-orm";
import { getDb } from "../../db";
import { gameTables } from "../../../drizzle/schema";
import { lockTable, timeoutTable } from "./tableService";

let timer: ReturnType<typeof setInterval> | undefined;
let busy = false;

export async function runGameCenterWorkerOnce(now = new Date()) {
  if (busy) return;
  busy = true;
  try {
    const db = await getDb();
    if (!db) return;
    const expired = await db
      .select({ id: gameTables.id })
      .from(gameTables)
      .where(
        and(eq(gameTables.status, "lobby"), lt(gameTables.lobbyExpiresAt, now))
      )
      .limit(100);
    for (const { id } of expired) {
      await db.transaction(async (tx: any) => {
        const table = await lockTable(tx, id);
        if (
          table.status === "lobby" &&
          table.lobbyExpiresAt &&
          table.lobbyExpiresAt <= now
        )
          await tx
            .update(gameTables)
            .set({
              status: "cancelled",
              endedAt: now,
              version: table.version + 1,
            })
            .where(eq(gameTables.id, id));
      });
    }
    const active = await db
      .select({ id: gameTables.id })
      .from(gameTables)
      .where(eq(gameTables.status, "playing"))
      .limit(100);
    for (const { id } of active) {
      try {
        await timeoutTable(id, now.getTime());
      } catch (error) {
        console.error("[game-center] timeout transition failed", id, error);
      }
    }
  } catch (error) {
    console.error("[game-center] worker cycle failed", error);
  } finally {
    busy = false;
  }
}

export function startGameCenterWorker(intervalMs = 5000) {
  if (timer) return;
  timer = setInterval(() => void runGameCenterWorkerOnce(), intervalMs);
  timer.unref?.();
}
