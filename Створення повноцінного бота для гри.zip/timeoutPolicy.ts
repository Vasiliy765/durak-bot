export const RECONNECT_HEARTBEAT_STALE_MS = 35_000;

type Timestamp = Date | string | number | null | undefined;

function timestampMs(value: Timestamp): number | null {
  if (value == null) return null;
  const ms = value instanceof Date ? value.getTime() : new Date(value).getTime();
  return Number.isFinite(ms) ? ms : null;
}

/** A missed turn may wait only when the last heartbeat was before that turn's deadline. */
export function shouldWaitForReconnect(
  lastSeenAt: Timestamp,
  turnDeadline: number,
  now: number,
  graceMs: number
) {
  const lastSeen = timestampMs(lastSeenAt);
  return (
    lastSeen !== null &&
    lastSeen <= turnDeadline &&
    now < lastSeen + graceMs
  );
}

/** Grant one fresh turn only when a stale, offline current player returns inside reconnect grace. */
export function shouldExtendTurnForReconnect(input: {
  isCurrentPlayer: boolean;
  lastSeenAt: Timestamp;
  turnDeadline: number | null;
  now: number;
  graceMs: number;
  graceAlreadyUsed: boolean;
  heartbeatStaleMs?: number;
}) {
  const lastSeen = timestampMs(input.lastSeenAt);
  const deadline = input.turnDeadline;
  return (
    input.isCurrentPlayer &&
    !input.graceAlreadyUsed &&
    lastSeen !== null &&
    deadline !== null &&
    deadline <= input.now &&
    lastSeen <= deadline &&
    input.now - lastSeen >=
      (input.heartbeatStaleMs ?? RECONNECT_HEARTBEAT_STALE_MS) &&
    input.now < deadline + input.graceMs
  );
}
