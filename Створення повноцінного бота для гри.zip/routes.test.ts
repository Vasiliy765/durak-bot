import express from "express";
import type { Server } from "node:http";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  table: null as any,
  getDb: vi.fn(),
  projectTable: vi.fn(),
  activeRoom: vi.fn(),
  getActiveRoomId: vi.fn(),
  player: null as any,
}));

vi.mock("../../db", () => ({ getDb: mocks.getDb }));
vi.mock("../auth", () => ({
  identityFromRequest: () => ({ id: "viewer", preview: true }),
}));
vi.mock("./tableService", () => ({
  createTable: vi.fn(),
  listPublic: vi.fn(),
  privateInvite: vi.fn(),
  readConfig: vi.fn(),
  publicConfig: vi.fn(),
  lifecycle: vi.fn(),
  projectTable: mocks.projectTable,
  activeRoom: mocks.activeRoom,
  getActiveRoomId: mocks.getActiveRoomId,
  PLAYABLE_ARCADE_GAME_IDS: ["durak", "battleship", "tic-tac-toe"],
}));
vi.mock("./stats", () => ({ getLeaderboard: vi.fn() }));

import { gameTablePlayers, gameTables } from "../../../drizzle/schema";
import { gameCenterRouter } from "./routes";

const fakeDb = {
  select: () => ({
    from: (table: unknown) => ({
      where: () => ({
          limit: async () => table === gameTables ? [mocks.table] : table === gameTablePlayers && mocks.player ? [mocks.player] : [],
      }),
    }),
  }),
};

let server: Server;
let origin: string;

beforeAll(async () => {
  const app = express();
  app.use(gameCenterRouter);
  server = app.listen(0, "127.0.0.1");
  await new Promise<void>(resolve => server.once("listening", resolve));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Test server did not bind TCP");
  origin = `http://127.0.0.1:${address.port}`;
});

afterAll(async () => {
  await new Promise<void>((resolve, reject) =>
    server.close(error => (error ? reject(error) : resolve()))
  );
});

beforeEach(() => {
  vi.clearAllMocks();
  mocks.table = {
    id: "table-1",
    gameId: "durak",
    status: "lobby",
    ownerId: "viewer",
    visibility: "public",
    options: {},
  };
  mocks.player = { id: 1, tableId: "table-1", telegramId: "viewer", status: "active" };
  mocks.getDb.mockResolvedValue(fakeDb);
  mocks.activeRoom.mockResolvedValue({ table: null });
  mocks.getActiveRoomId.mockResolvedValue("table-1");
  mocks.projectTable.mockImplementation(async (table: any) => ({
    id: table.id,
    status: table.status,
  }));
});

describe("GET /tables/:id user visibility", () => {
  it("returns the finished result to the table owner", async () => {
    mocks.table.status = "finished";
    mocks.player.status = "winner";
    const response = await fetch(`${origin}/tables/${mocks.table.id}`);
    expect(response.status).toBe(200);
    expect(mocks.projectTable).toHaveBeenCalled();
    expect(await response.json()).toEqual({ table: { id: mocks.table.id, status: "finished" } });
  });

  it("returns 404 for a cancelled table", async () => {
    mocks.table.status = "cancelled";
    const response = await fetch(`${origin}/tables/${mocks.table.id}`);
    expect(response.status).toBe(404);
    expect(mocks.projectTable).not.toHaveBeenCalled();
  });

  it.each(["lobby", "playing"])("still returns an active %s table", async status => {
    mocks.table.status = status;

    const response = await fetch(`${origin}/tables/${mocks.table.id}`);

    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({
      table: { id: mocks.table.id, status },
    });
  });

  it("does not reopen an active room after this player has left it", async () => {
    mocks.player.status = "left";
    mocks.getActiveRoomId.mockResolvedValue(null);

    const response = await fetch(`${origin}/tables/${mocks.table.id}`);

    expect(response.status).toBe(403);
    expect(mocks.projectTable).not.toHaveBeenCalled();
  });

  it("returns the server's single active room for quick-join recovery", async () => {
    mocks.activeRoom.mockResolvedValue({ table: { id: "table-1", status: "playing" } });

    const response = await fetch(`${origin}/tables/active`);

    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ table: { id: "table-1", status: "playing" } });
  });
});
