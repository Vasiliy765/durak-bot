import { and, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../db";
import { spyGroupPermissionSnapshots } from "../../drizzle/schema";
import { isTelegramAdmin, telegramCall, type TelegramChatMember, type TelegramPermissions } from "./telegramApi";

const CHAT_PERMISSION_KEYS = [
  "can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos", "can_send_videos",
  "can_send_video_notes", "can_send_voice_notes", "can_send_polls", "can_send_other_messages",
  "can_add_web_page_previews", "can_react_to_messages", "can_change_info", "can_invite_users",
  "can_pin_messages", "can_manage_topics",
] as const;
const SEND_PERMISSION_KEYS = new Set([
  "can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos", "can_send_videos",
  "can_send_video_notes", "can_send_voice_notes", "can_send_polls", "can_send_other_messages",
  "can_add_web_page_previews", "can_react_to_messages",
]);

function permissionSnapshot(source: Record<string, unknown> | undefined, defaultSendAllowed: boolean) {
  const permissions: TelegramPermissions = {};
  for (const key of CHAT_PERMISSION_KEYS) {
    const value = source?.[key];
    if (typeof value === "boolean") permissions[key] = value;
    else permissions[key] = SEND_PERMISSION_KEYS.has(key) ? defaultSendAllowed : false;
  }
  return permissions;
}

function permissionsEqual(current: Record<string, unknown> | undefined, expected: TelegramPermissions) {
  if (!current) return false;
  return Object.entries(expected).every(([key, value]) => current[key] === value);
}

function hasAnySendPermission(permissions: TelegramPermissions) {
  return [...SEND_PERMISSION_KEYS].some(key => permissions[key] === true);
}

async function database() {
  const db = await getDb();
  if (!db) throw new Error("Permission snapshot database is unavailable");
  return db;
}

async function fetchChatMember(chatId: string, userId: string) {
  return telegramCall<TelegramChatMember>("getChatMember", { chat_id: Number(chatId), user_id: Number(userId) });
}

export async function protectSpectatorMessage(input: {
  chatId: string;
  roundId: string;
  chatType: "group" | "supergroup";
  userId: string;
  messageId: number;
  roundEndsAt?: number | null;
}) {
  let deleted = false;
  try {
    await telegramCall("deleteMessage", { chat_id: Number(input.chatId), message_id: input.messageId });
    deleted = true;
  } catch (error) {
    console.warn("[Group moderation] Could not delete a spectator message:", error instanceof Error ? error.message : String(error));
  }

  if (input.chatType !== "supergroup") return { deleted, restricted: false, reason: "basic_group" as const };

  let member: TelegramChatMember;
  try {
    member = await fetchChatMember(input.chatId, input.userId);
  } catch (error) {
    return { deleted, restricted: false, reason: error instanceof Error ? error.message.slice(0, 180) : "member_lookup_failed" };
  }
  if (isTelegramAdmin(member) || member.status === "left" || member.status === "kicked") {
    return { deleted, restricted: false, reason: "admin_or_not_member" as const };
  }

  const originalPermissions = member.status === "restricted"
    ? permissionSnapshot(member as unknown as Record<string, unknown>, false)
    : await (async () => {
      try {
        const chat = await telegramCall<{ permissions?: Record<string, unknown> }>("getChat", { chat_id: Number(input.chatId) });
        return permissionSnapshot(chat.permissions, true);
      } catch {
        return permissionSnapshot(undefined, true);
      }
    })();
  if (!hasAnySendPermission(originalPermissions)) return { deleted, restricted: false, reason: "already_read_only" as const };

  const db = await database();
  const existing = await db.select().from(spyGroupPermissionSnapshots).where(and(
    eq(spyGroupPermissionSnapshots.chatId, input.chatId),
    eq(spyGroupPermissionSnapshots.roundId, input.roundId),
    eq(spyGroupPermissionSnapshots.telegramId, input.userId),
  )).limit(1);
  if (existing[0]?.restoreStatus === "applied" || existing[0]?.restoreStatus === "captured") {
    return { deleted, restricted: existing[0].restoreStatus === "applied", reason: "already_recorded" as const };
  }

  const appliedPermissions: TelegramPermissions = { ...originalPermissions };
  for (const key of SEND_PERMISSION_KEYS) appliedPermissions[key] = false;
  const nowSeconds = Math.floor(Date.now() / 1000);
  const appliedUntilDate = Math.max(nowSeconds + 1800, Math.floor((input.roundEndsAt || Date.now()) / 1000) + 180);
  const originalSnapshot = {
    status: member.status,
    isMember: member.is_member ?? true,
    untilDate: member.until_date ?? null,
    permissions: originalPermissions,
    appliedUntilDate,
  };

  try {
    if (existing[0]) {
      await db.update(spyGroupPermissionSnapshots).set({
        originalStatus: member.status,
        originalSnapshot,
        appliedPermissions,
        restoreStatus: "captured",
        lastError: null,
      }).where(eq(spyGroupPermissionSnapshots.id, existing[0].id));
    } else {
      await db.insert(spyGroupPermissionSnapshots).values({
        chatId: input.chatId,
        roundId: input.roundId,
        telegramId: input.userId,
        originalStatus: member.status,
        originalSnapshot,
        appliedPermissions,
        restoreStatus: "captured",
      }).onDuplicateKeyUpdate({ set: { restoreStatus: sql`${spyGroupPermissionSnapshots.restoreStatus}` } });
    }
    await telegramCall("restrictChatMember", {
      chat_id: Number(input.chatId),
      user_id: Number(input.userId),
      permissions: appliedPermissions,
      use_independent_chat_permissions: true,
      until_date: appliedUntilDate,
    });
    await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "applied", lastError: null })
      .where(and(eq(spyGroupPermissionSnapshots.chatId, input.chatId), eq(spyGroupPermissionSnapshots.roundId, input.roundId), eq(spyGroupPermissionSnapshots.telegramId, input.userId)));
    return { deleted, restricted: true, reason: "restricted_until_round_end" as const };
  } catch (error) {
    const message = (error instanceof Error ? error.message : String(error)).slice(0, 500);
    await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "failed", lastError: message })
      .where(and(eq(spyGroupPermissionSnapshots.chatId, input.chatId), eq(spyGroupPermissionSnapshots.roundId, input.roundId), eq(spyGroupPermissionSnapshots.telegramId, input.userId)));
    console.warn("[Group moderation] Could not temporarily restrict spectator:", message);
    return { deleted, restricted: false, reason: "restrict_failed" as const };
  }
}

export async function restoreGroupPermissionSnapshots(chatId?: string, roundId?: string) {
  const db = await database();
  const statuses = ["captured", "applied", "restoring", "failed"] as const;
  const conditions = [inArray(spyGroupPermissionSnapshots.restoreStatus, [...statuses])];
  if (chatId) conditions.push(eq(spyGroupPermissionSnapshots.chatId, chatId));
  if (roundId) conditions.push(eq(spyGroupPermissionSnapshots.roundId, roundId));
  const rows = await db.select().from(spyGroupPermissionSnapshots).where(and(...conditions)).limit(250);
  let restored = 0;
  let conflicted = 0;

  for (const row of rows) {
    const original = row.originalSnapshot as {
      status?: string;
      isMember?: boolean;
      untilDate?: number | null;
      appliedUntilDate?: number;
      permissions?: TelegramPermissions;
    };
    try {
      await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "restoring", restoreAttempts: row.restoreAttempts + 1 })
        .where(eq(spyGroupPermissionSnapshots.id, row.id));
      const current = await fetchChatMember(row.chatId, row.telegramId);
      if (isTelegramAdmin(current)) {
        await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "conflict", lastError: "Користувача підвищено до адміністратора; права не змінювалися." })
          .where(eq(spyGroupPermissionSnapshots.id, row.id));
        conflicted++;
        continue;
      }
      if (current.status === "member" || current.status === "left" || current.status === "kicked") {
        await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "restored", lastError: null }).where(eq(spyGroupPermissionSnapshots.id, row.id));
        restored++;
        continue;
      }
      if (current.status !== "restricted") {
        await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "conflict", lastError: `Невідомий статус учасника: ${current.status}` }).where(eq(spyGroupPermissionSnapshots.id, row.id));
        conflicted++;
        continue;
      }
      if (!permissionsEqual(current as unknown as Record<string, unknown>, row.appliedPermissions as TelegramPermissions)) {
        await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "conflict", lastError: "Поточні права відрізняються від тимчасового обмеження бота; зовнішню зміну не перезаписано." })
          .where(eq(spyGroupPermissionSnapshots.id, row.id));
        conflicted++;
        continue;
      }

      if (original.status === "restricted" && original.permissions) {
        await telegramCall("restrictChatMember", {
          chat_id: Number(row.chatId),
          user_id: Number(row.telegramId),
          permissions: original.permissions,
          use_independent_chat_permissions: true,
          ...(original.untilDate ? { until_date: original.untilDate } : {}),
        });
      } else {
        await telegramCall("unrestrictChatMember", { chat_id: Number(row.chatId), user_id: Number(row.telegramId) });
      }
      await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "restored", lastError: null }).where(eq(spyGroupPermissionSnapshots.id, row.id));
      restored++;
    } catch (error) {
      const message = (error instanceof Error ? error.message : String(error)).slice(0, 500);
      await db.update(spyGroupPermissionSnapshots).set({ restoreStatus: "failed", lastError: message }).where(eq(spyGroupPermissionSnapshots.id, row.id)).catch(() => undefined);
      console.warn("[Group moderation] Permission restore will be retried:", message);
    }
  }
  return { restored, conflicted, processed: rows.length };
}
