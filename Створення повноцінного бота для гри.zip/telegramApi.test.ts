import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TelegramApiError, telegramCall } from "./telegramApi";

describe("telegramCall deadline", () => {
  beforeEach(() => vi.stubEnv("TELEGRAM_BOT_TOKEN", "test-token"));
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  it("bounds the complete request even when response JSON never resolves", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: true,
        status: 200,
        statusText: "OK",
        json: () => new Promise(() => undefined),
      }) as unknown as Response)
    );

    const startedAt = Date.now();
    await expect(
      telegramCall("answerPreCheckoutQuery", { pre_checkout_query_id: "query" }, 15)
    ).rejects.toMatchObject({
      name: "TelegramApiError",
      message: "Telegram API deadline exceeded after 15ms",
    });
    expect(Date.now() - startedAt).toBeLessThan(250);
    expect(fetch).toHaveBeenCalledOnce();
  });

  it("preserves Telegram API errors instead of replacing them with timeout errors", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: false,
        status: 400,
        statusText: "Bad Request",
        json: async () => ({ ok: false, error_code: 400, description: "query expired" }),
      }) as unknown as Response)
    );

    await expect(telegramCall("answerPreCheckoutQuery", {}, 1000)).rejects.toBeInstanceOf(TelegramApiError);
  });
});
