export type ParsedGroupCallback = { action: string; parts: string[] };

/**
 * Group game callbacks use `g:<action>:<roundId>[:payload]`.
 * Keep the `g` namespace out of the action and preserve roundId as parts[0].
 */
export function parseGroupCallback(data: string): ParsedGroupCallback | null {
  const [namespace, action, ...parts] = data.split(":");
  if (namespace !== "g" || !action || !parts[0]) return null;
  return { action, parts };
}
