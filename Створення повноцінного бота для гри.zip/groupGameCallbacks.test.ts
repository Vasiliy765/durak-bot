import { describe, expect, it } from "vitest";
import { parseGroupCallback } from "./groupGameCallbacks";

describe("Telegram group callback payload parser", () => {
  it.each([
    ["g:j:round-123", { action: "j", parts: ["round-123"] }],
    ["g:l:round-123", { action: "l", parts: ["round-123"] }],
    ["g:s:round-123", { action: "s", parts: ["round-123"] }],
    ["g:m:round-123", { action: "m", parts: ["round-123"] }],
    ["g:d:round-123", { action: "d", parts: ["round-123"] }],
    ["g:start:round-123", { action: "start", parts: ["round-123"] }],
    ["g:q:round-123", { action: "q", parts: ["round-123"] }],
    ["g:vote:round-123", { action: "vote", parts: ["round-123"] }],
    ["g:t:round-123:104", { action: "t", parts: ["round-123", "104"] }],
    ["g:v:round-123:104", { action: "v", parts: ["round-123", "104"] }],
  ])("parses %s into the actual action and round", (payload, expected) => {
    expect(parseGroupCallback(payload)).toEqual(expected);
  });

  it.each(["", "g", "g:j", "g:j:", "gs:123:round-123:0", "x:j:round-123"])(
    "rejects malformed or non-group callback %s",
    payload => expect(parseGroupCallback(payload)).toBeNull(),
  );
});
