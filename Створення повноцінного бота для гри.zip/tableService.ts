import { randomBytes, randomUUID } from "node:crypto";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { getDb } from "../../db";
import {
  gameCenterBank,
  gameCenterBankLedger,
  gameCenterConfig,
  gameTableEvents,
  gameTablePlayers,
  gameTableResults,
  gameTables,
  gamePlayerActiveRooms,
  spyEconomyLedger,
  spyProfiles,
  spyWallets,
} from "../../../drizzle/schema";
import type { ArcadeEngine, ArcadeOutcome } from "./engine";
import { secureRandomInt } from "./engine";
import { applyArcadeVipCommission, calculateBlackjackBankPayouts, calculatePayouts } from "./payouts";
import { recordPlayerStatTx } from "./stats";
import { battleshipEngine } from "./battleship";
import { durakEngine } from "./durak";
import { blackjackEngine } from "./blackjack";
import { ticTacToeEngine } from "./ticTacToe";
import {
  RECONNECT_HEARTBEAT_STALE_MS,
  shouldExtendTurnForReconnect,
  shouldWaitForReconnect,
} from "./timeoutPolicy";
import { PLAYABLE_ARCADE_GAME_IDS } from "./playableGames";
import { syncEconomyUserTx } from "../economy";
import { broadcastDurakReaction } from "./reactionSocket";
export { PLAYABLE_ARCADE_GAME_IDS } from "./playableGames";
export const STAKE_OPTIONS = [10, 20, 30, 40, 50, 75, 100, 150, 200];
export const DEFAULT_CONFIG = {
  enabledGames: {
    battleship: true,
    durak: true,
    tic_tac_toe: true,
  },
  stakes: STAKE_OPTIONS,
  minStake: 10,
  maxStake: 200,
  maxOpenTablesPerUser: 5,
  turnTimeoutSeconds: 90,
  lobbyExpiryMinutes: 20,
  reconnectGraceSeconds: 120,
  gameOptions: {
    durakModes: ["throw_in"],
    battleshipExtraShotOnHit: [false, true],
  },
};
const titles: any = {
  battleship: "Морський бій",
  durak: "Дурень",
  tic_tac_toe: "Хрестики-нулики",
};
const err = (message: string, status = 400): never => {
  throw Object.assign(new Error(message), { status });
};
export const inviteParam = (token: string) => `arcade_${token}`;
export function isReconnectGraceExpired(
  lastSeenAt: Date | string,
  now: number,
  graceSeconds: number
) {
  return now - new Date(lastSeenAt).getTime() >= graceSeconds * 1000;
}
function stateCurrentPlayerId(state: any): string | null {
  const direct =
    state?.currentPlayerId ??
    state?.activePlayerId ??
    state?.turnPlayerId ??
    state?.turn ??
    state?.currentPlayer;
  if (typeof direct === "string") return direct;
  if (typeof direct?.id === "string") return direct.id;
  if (Number.isInteger(state?.currentIndex)) {
    const hand = state?.hands?.[state.currentIndex];
    if (typeof hand?.playerId === "string") return hand.playerId;
    if (typeof hand?.id === "string") return hand.id;
  }
  return null;
}
export function inviteLink(token: string) {
  const param = inviteParam(token);
  const username = process.env.TELEGRAM_BOT_USERNAME?.trim().replace(/^@/, "");
  const shortName = process.env.TELEGRAM_APP_SHORT_NAME?.trim();
  if (!username || !/^[A-Za-z0-9_]{5,32}$/.test(username)) return "";
  if (shortName && /^[A-Za-z0-9_-]{1,64}$/.test(shortName))
    return `https://t.me/${username}/${encodeURIComponent(shortName)}?startapp=${encodeURIComponent(param)}`;
  // Verified by Telegram getMe: the bot currently has its Main Mini App configured.
  return `https://t.me/${username}?startapp=${encodeURIComponent(param)}`;
}
export function newInviteToken() {
  return randomBytes(32).toString("base64url");
}
export const arcadeEngines = new Map<string, ArcadeEngine>();
export function registerArcadeEngine(e: ArcadeEngine) {
  arcadeEngines.set(e.gameId, e);
}
registerArcadeEngine(battleshipEngine);
registerArcadeEngine(durakEngine);
registerArcadeEngine(blackjackEngine);
registerArcadeEngine(ticTacToeEngine);
export async function readConfig() {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  const r = await db.select().from(gameCenterConfig);
  const c: any = {
    ...DEFAULT_CONFIG,
    ...Object.fromEntries(r.map(x => [x.key, x.value])),
  };
  c.enabledGames = { ...DEFAULT_CONFIG.enabledGames, ...c.enabledGames };
  // Do not expose or reopen legacy Blackjack configuration; keep its rows intact.
  delete c.enabledGames.blackjack;
  const rawMin = Number(c.minStake);
  c.minStake = Number.isSafeInteger(rawMin) ? Math.max(10, Math.min(200, rawMin)) : 10;
  const rawMax = Number(c.maxStake);
  c.maxStake = Number.isSafeInteger(rawMax) ? Math.max(c.minStake, Math.min(200, rawMax)) : 200;
  const sourceStakes = Array.isArray(c.stakes) ? c.stakes : STAKE_OPTIONS;
  c.stakes = sourceStakes.filter((stake: unknown) => Number.isSafeInteger(stake) && Number(stake) >= c.minStake && Number(stake) <= c.maxStake && Number(stake) <= 200);
  if (!c.stakes.length) c.stakes = STAKE_OPTIONS.filter(stake => stake >= c.minStake && stake <= c.maxStake);
  c.gameOptions = { ...DEFAULT_CONFIG.gameOptions, ...(c.gameOptions || {}) };
  c.gameOptions.durakModes = ["throw_in"];
  delete c.gameOptions.blackjackDoubleAllowed;
  return c;
}
export async function publicConfig() {
  const c = await readConfig();
  return {
    games: [...arcadeEngines.values()]
      .filter(e =>
        (PLAYABLE_ARCADE_GAME_IDS as readonly string[]).includes(e.gameId)
      )
      .map(e => ({
      id: e.gameId,
      enabled: c.enabledGames[e.gameId] !== false,
      name: titles[e.gameId],
      minPlayers: e.minPlayers,
      maxPlayers: e.maxPlayers,
      playerCounts: Array.from(
        { length: e.maxPlayers - e.minPlayers + 1 },
        (_, i) => e.minPlayers + i
      ),
      options:
        e.gameId === "durak"
          ? { modes: ["throw_in"] }
          : e.gameId === "battleship"
            ? { extraShotOnHit: c.gameOptions.battleshipExtraShotOnHit }
            : {},
    })),
    stakeOptions: c.stakes,
    minStake: c.minStake,
    maxStake: c.maxStake,
    gameOptions: c.gameOptions,
    limits: {
      maxOpenTablesPerUser: c.maxOpenTablesPerUser,
      turnTimeoutSeconds: c.turnTimeoutSeconds,
      lobbyExpiryMinutes: c.lobbyExpiryMinutes,
      reconnectGraceSeconds: c.reconnectGraceSeconds,
    },
  };
}
export async function lockTable(tx: any, id: string) {
  const r = await tx
    .select()
    .from(gameTables)
    .where(eq(gameTables.id, id))
    .limit(1)
    .for("update");
  if (!r[0]) err("Table not found", 404);
  return r[0];
}
async function players(tx: any, id: string, lock = false) {
  let q = tx
    .select()
    .from(gameTablePlayers)
    .where(eq(gameTablePlayers.tableId, id))
    .orderBy(asc(gameTablePlayers.id));
  if (lock) q = q.for("update");
  return q;
}
async function setActiveRoomTx(tx: any, telegramId: string, tableId: string) {
  await tx.insert(gamePlayerActiveRooms).values({ telegramId, activeRoomId: tableId })
    .onDuplicateKeyUpdate({ set: { activeRoomId: tableId, updatedAt: new Date() } });
}
async function clearActiveRoomTx(tx: any, telegramId: string, tableId: string) {
  await tx.update(gamePlayerActiveRooms).set({ activeRoomId: null, updatedAt: new Date() })
    .where(and(eq(gamePlayerActiveRooms.telegramId, telegramId), eq(gamePlayerActiveRooms.activeRoomId, tableId)));
}
async function clearActiveRoomForTableTx(tx: any, tableId: string) {
  await tx.update(gamePlayerActiveRooms).set({ activeRoomId: null, updatedAt: new Date() })
    .where(eq(gamePlayerActiveRooms.activeRoomId, tableId));
}
async function closeOtherActiveRoomsTx(tx: any, telegramId: string, keepTableId: string) {
  const otherSeats = await tx.select().from(gameTablePlayers).where(and(
    eq(gameTablePlayers.telegramId, telegramId), eq(gameTablePlayers.status, "active")
  ));
  for (const seat of otherSeats) {
    if (seat.tableId === keepTableId) continue;
    const other = (await tx.select().from(gameTables).where(eq(gameTables.id, seat.tableId)).limit(1))[0];
    if (other?.status === "lobby" && other.ownerId === telegramId) {
      await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(and(
        eq(gameTablePlayers.tableId, other.id), eq(gameTablePlayers.status, "active")
      ));
      await tx.update(gameTables).set({ status: "cancelled", endedAt: new Date(), version: other.version + 1 }).where(eq(gameTables.id, other.id));
      await clearActiveRoomForTableTx(tx, other.id);
    } else {
      await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(eq(gameTablePlayers.id, seat.id));
      await clearActiveRoomTx(tx, telegramId, seat.tableId);
    }
  }
}
async function resolveActiveRoomTx(tx: any, telegramId: string) {
  // This row lock serializes concurrent Create/Join attempts for one registered player.
  await tx.select({ telegramId: spyProfiles.telegramId }).from(spyProfiles)
    .where(eq(spyProfiles.telegramId, telegramId)).limit(1).for("update");
  const pointer = (await tx.select().from(gamePlayerActiveRooms)
    .where(eq(gamePlayerActiveRooms.telegramId, telegramId)).limit(1))[0];
  const check = async (tableId: string) => {
    const table = (await tx.select().from(gameTables).where(eq(gameTables.id, tableId)).limit(1))[0];
    const participant = (await tx.select().from(gameTablePlayers).where(and(
      eq(gameTablePlayers.tableId, tableId), eq(gameTablePlayers.telegramId, telegramId)
    )).limit(1))[0];
    const expiredLobby = table?.status === "lobby" && table.lobbyExpiresAt && new Date(table.lobbyExpiresAt).getTime() <= Date.now();
    if (expiredLobby) {
      await tx.update(gameTables).set({ status: "cancelled", endedAt: new Date(), version: table.version + 1 }).where(eq(gameTables.id, tableId));
      await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(and(
        eq(gameTablePlayers.tableId, tableId), eq(gameTablePlayers.status, "active")
      ));
      await clearActiveRoomForTableTx(tx, tableId);
      return null;
    }
    if (table && ["lobby", "playing"].includes(table.status) && participant?.status === "active") {
      await closeOtherActiveRoomsTx(tx, telegramId, table.id);
      return table;
    }
    if (table && participant?.status === "active" && !["lobby", "playing"].includes(table.status))
      await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(eq(gameTablePlayers.id, participant.id));
    await clearActiveRoomTx(tx, telegramId, tableId);
    return null;
  };
  if (pointer?.activeRoomId) {
    const current = await check(pointer.activeRoomId);
    if (current) return current;
  }
  // Recover rooms created by an older server version during a rolling deployment.
  const candidates = await tx.select().from(gameTablePlayers)
    .where(and(eq(gameTablePlayers.telegramId, telegramId), eq(gameTablePlayers.status, "active")))
    .orderBy(desc(gameTablePlayers.joinedAt)).limit(20);
  for (const candidate of candidates) {
    const table = (await tx.select().from(gameTables).where(eq(gameTables.id, candidate.tableId)).limit(1))[0];
    const expiredLobby = table?.status === "lobby" && table.lobbyExpiresAt && new Date(table.lobbyExpiresAt).getTime() <= Date.now();
    if (expiredLobby) {
      await tx.update(gameTables).set({ status: "cancelled", endedAt: new Date(), version: table.version + 1 }).where(eq(gameTables.id, table.id));
      await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(and(
        eq(gameTablePlayers.tableId, table.id), eq(gameTablePlayers.status, "active")
      ));
      await clearActiveRoomForTableTx(tx, table.id);
      continue;
    }
    if (table && ["lobby", "playing"].includes(table.status)) {
      await closeOtherActiveRoomsTx(tx, telegramId, table.id);
      await setActiveRoomTx(tx, telegramId, table.id);
      return table;
    }
    if (table && !["lobby", "playing"].includes(table.status))
      await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(eq(gameTablePlayers.id, candidate.id));
  }
  return null;
}
export async function getActiveRoomId(telegramId: string) {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  const pointer = (await db.select().from(gamePlayerActiveRooms)
    .where(eq(gamePlayerActiveRooms.telegramId, telegramId)).limit(1))[0];
  return pointer?.activeRoomId ?? null;
}
export async function activeRoom(telegramId: string) {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  return db.transaction(async (tx: any) => {
    const table = await resolveActiveRoomTx(tx, telegramId);
    return { table: table ? await projectTable(table, telegramId, tx) : null };
  });
}
export async function projectTable(t: any, viewer: string, dbArg?: any) {
  const db = dbArg || (await getDb());
  if (!db) throw Error("Database unavailable");
  const ps = await players(db, t.id);
  const active = ps.filter((p: any) => p.status !== "left" || (t.status === "playing" && Number(p.contribution) > 0));
  const participant = ps.find((p: any) => p.telegramId === viewer);
  const member = t.status === "finished"
    ? Boolean(participant)
    : active.some((p: any) => p.telegramId === viewer && p.status === "active");
  let projection = null,
    turnEndsAt = null;
  const engine = arcadeEngines.get(t.gameId);
  if (t.status === "playing" && engine) {
    try {
      projection = engine.toView(t.state, viewer);
      turnEndsAt = engine.getDeadline(t.state);
    } catch {
      projection = null;
    }
  }
  const events = await db
    .select()
    .from(gameTableEvents)
    .where(eq(gameTableEvents.tableId, t.id))
    .orderBy(desc(gameTableEvents.sequence))
    .limit(25);
  const result =
    t.status === "finished"
      ? (
          await db
            .select()
            .from(gameTableResults)
            .where(eq(gameTableResults.tableId, t.id))
            .limit(1)
        )[0]
      : null;
  const resultBankSettlement = (result?.outcome as any)?.bankSettlement;
  const vipWallets = await db.select({ telegramId: spyWallets.telegramId, vipUntil: spyWallets.vipUntil }).from(spyWallets).where(inArray(spyWallets.telegramId, active.map((p: any) => p.telegramId)));
  const vipSet = new Set(vipWallets.filter((wallet: any) => wallet.vipUntil && new Date(wallet.vipUntil).getTime() > Date.now()).map((wallet: any) => wallet.telegramId));
  return {
    id: t.id,
    gameId: t.gameId,
    name: t.name,
    stake: t.stake,
    minPlayers: t.minPlayers,
    maxPlayers: t.maxPlayers,
    visibility: t.visibility,
    status: t.status,
    ownerId: t.ownerId,
    players: active.map((p: any) => ({
      id: p.telegramId,
      name:
        [p.firstName, p.lastName].filter(Boolean).join(" ") ||
        p.username ||
        "Гравець",
      nick: p.username,
      avatarUrl: p.avatarUrl,
      vip: vipSet.has(p.telegramId),
      ready: p.ready,
      status: p.status,
      owner: p.telegramId === t.ownerId,
      ...(p.telegramId === viewer ? { contribution: p.contribution } : {}),
    })),
    options: t.options,
    version: t.version,
    bank:
      t.status === "playing"
        ? active.reduce((n: number, p: any) => n + p.contribution, 0)
        : 0,
    isOwner: t.ownerId === viewer,
    myPlayerId: member ? viewer : undefined,
    projection,
    turnEndsAt,
    events: events.reverse().map((x: any) => {
      const payload = { ...(x.publicPayload || {}) };
      const actorId = payload.actorId;
      if (payload.actorId) {
        const actor = active.find((p: any) => p.telegramId === payload.actorId);
        payload.actorName = actor
          ? [actor.firstName, actor.lastName].filter(Boolean).join(" ") ||
            "Гравець"
          : "Гравець";
        delete payload.actorId;
      }
      return { type: x.eventType, at: x.createdAt, ...(actorId && x.eventType === "reaction" ? { playerId: actorId } : {}), ...payload };
    }),
    result:
      result && member
        ? {
            winners: active
              .filter((p: any) => result.winnerIds.includes(p.telegramId))
              .map(
                (p: any) =>
                  [p.firstName, p.lastName].filter(Boolean).join(" ") ||
                  "Гравець"
              ),
            reason: result.outcome?.reason,
            draw: !!result.outcome?.draw,
            myPayout: (result.payouts as any)?.[viewer] ?? undefined,
            totalPot: result.totalPot,
            bankSettlement: resultBankSettlement
              ? {
                  bankBalanceBefore: resultBankSettlement.bankBalanceBefore,
                  availableBank: resultBankSettlement.availableBank,
                  bankBalanceAfter: resultBankSettlement.bankBalanceAfter,
                  bankCapped: resultBankSettlement.bankCapped,
                  myTargetPayout: resultBankSettlement.targetPayouts?.[viewer] ?? 0,
                }
              : undefined,
            payouts: Object.entries(
              (result.payouts || {}) as Record<string, number>
            ).map(([playerId, amount]) => ({ playerId, amount })),
          }
        : undefined,
    ...(member && t.ownerId === viewer
      ? { inviteToken: t.inviteToken, inviteLink: inviteLink(t.inviteToken) }
      : {}),
  };
}
export async function createTable(owner: string, identity: any, b: any) {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  if (!(PLAYABLE_ARCADE_GAME_IDS as readonly string[]).includes(b?.gameId))
    return err("Unsupported or retired game", 403);
  const e = arcadeEngines.get(b?.gameId);
  if (!e) return err("Unsupported game");
  const c = await readConfig();
  if (c.enabledGames[e.gameId] === false) err("Game disabled", 403);
  if (typeof b.requestId !== "string" || !/^[\w-]{8,64}$/.test(b.requestId))
    err("Invalid requestId");
  if (
    !Number.isInteger(b.stake) ||
    !c.stakes.includes(b.stake) ||
    b.stake < c.minStake ||
    b.stake > c.maxStake
  )
    err("Invalid stake");
  if (
    b.options !== undefined &&
    (!b.options || typeof b.options !== "object" || Array.isArray(b.options))
  )
    err("Invalid options");
  const requested: any = b.options || {};
  const allowed: string[] =
    e.gameId === "durak"
      ? ["deckSize"]
      : e.gameId === "battleship"
        ? ["extraShotOnHit"]
        : [];
  if (Object.keys(requested).some(k => !allowed.includes(k)))
    err("Invalid options");
  if (e.gameId === "durak" && requested.deckSize !== undefined && ![36, 52].includes(requested.deckSize))
    err("Invalid Durak deck size");
  if (
    e.gameId === "battleship" &&
    requested.extraShotOnHit !== undefined &&
    !c.gameOptions.battleshipExtraShotOnHit.includes(requested.extraShotOnHit)
  )
    err("Invalid options");
  if (
    !Number.isInteger(b.minPlayers) ||
    !Number.isInteger(b.maxPlayers) ||
    b.minPlayers < e.minPlayers ||
    b.maxPlayers > e.maxPlayers ||
    b.minPlayers > b.maxPlayers
  )
    err("Invalid player limits");
  if (!["public", "private"].includes(b.visibility)) err("Invalid visibility");
  return db.transaction(async (tx: any) => {
    const current = await resolveActiveRoomTx(tx, owner);
    if (current) {
      await setActiveRoomTx(tx, owner, current.id);
      return {
        table: await projectTable(current, owner, tx),
        inviteParam: inviteParam(current.inviteToken),
        inviteLink: inviteLink(current.inviteToken),
      };
    }
    const old = await tx
      .select()
      .from(gameTables)
      .where(
        and(
          eq(gameTables.ownerId, owner),
          eq(gameTables.createRequestId, b.requestId)
        )
      )
      .limit(1)
      .for("update");
    if (old[0] && ["lobby", "playing"].includes(old[0].status)) {
      await setActiveRoomTx(tx, owner, old[0].id);
      return {
        table: await projectTable(old[0], owner, tx),
        inviteParam: inviteParam(old[0].inviteToken),
        inviteLink: inviteLink(old[0].inviteToken),
      };
    }
    if (old[0]) err("Попередній запит створення вже завершений. Спробуйте створити новий стіл.", 409);
    const profile = (
      await tx
        .select()
        .from(spyProfiles)
        .where(eq(spyProfiles.telegramId, owner))
        .limit(1)
    )[0];
    if (!profile || profile.blocked) err("Registered profile required", 403);
    const opens = await tx
      .select()
      .from(gameTables)
      .where(
        and(eq(gameTables.ownerId, owner), eq(gameTables.status, "lobby"))
      );
    if (opens.length >= c.maxOpenTablesPerUser) err("Open-table limit", 409);
    const id = randomUUID(),
      token = newInviteToken(),
      now = new Date(),
      t = {
        id,
        ownerId: owner,
        gameId: e.gameId,
        status: "lobby",
        visibility: b.visibility,
        name:
          (typeof b.name === "string" ? b.name.trim() : "").slice(0, 80) ||
          titles[e.gameId],
        stake: b.stake,
        minPlayers: b.minPlayers,
        maxPlayers: b.maxPlayers,
        options: requested,
        state: {},
        inviteToken: token,
        createRequestId: b.requestId,
        version: 1,
        lobbyExpiresAt: new Date(now.getTime() + c.lobbyExpiryMinutes * 60000),
      };
    await tx.insert(gameTables).values(t);
    await tx.insert(gameTablePlayers).values({
      tableId: id,
      telegramId: owner,
      firstName: identity.firstName || "Агент",
      lastName: identity.lastName ?? null,
      username: identity.username ?? null,
      avatarUrl: identity.avatarUrl ?? null,
      seat: 0,
      ready: true,
      status: "active",
      contribution: 0,
    });
    await setActiveRoomTx(tx, owner, id);
    return {
      table: await projectTable(t, owner, tx),
      inviteParam: inviteParam(token),
      inviteLink: inviteLink(token),
    };
  });
}
export async function listPublic(gameId?: string, stake?: number) {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  const rows = await db
    .select()
    .from(gameTables)
    .where(
      and(
        eq(gameTables.status, "lobby"),
        eq(gameTables.visibility, "public"),
        inArray(gameTables.gameId, [...PLAYABLE_ARCADE_GAME_IDS] as any),
        ...(gameId ? [eq(gameTables.gameId, gameId as any)] : []),
        ...(stake ? [eq(gameTables.stake, stake)] : [])
      )
    )
    .orderBy(asc(gameTables.createdAt))
    .limit(100);
  return Promise.all(
    rows.map(async (t: any) => {
      const ps = await players(db, t.id);
      return {
        id: t.id,
        gameId: t.gameId,
        name: t.name,
        stake: t.stake,
        minPlayers: t.minPlayers,
        maxPlayers: t.maxPlayers,
        visibility: t.visibility,
        status: t.status,
        ownerId: t.ownerId,
        players: ps
          .filter((p: any) => p.status === "active")
          .map((p: any) => ({
            id: p.telegramId,
            name: p.firstName,
            ready: p.ready,
            owner: p.telegramId === t.ownerId,
          })),
        options: t.options,
        version: t.version,
      };
    })
  );
}
export async function privateInvite(token: string, viewer?: string) {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  const t = (
    await db
      .select()
      .from(gameTables)
      .where(eq(gameTables.inviteToken, token))
      .limit(1)
  )[0];
  if (!t || t.status !== "lobby") err("Invite not found", 404);
  if (!(PLAYABLE_ARCADE_GAME_IDS as readonly string[]).includes(t.gameId))
    err("This game is no longer available", 410);
  const ps = await players(db, t.id);
  return {
    id: t.id,
    gameId: t.gameId,
    name: t.name,
    stake: t.stake,
    minPlayers: t.minPlayers,
    maxPlayers: t.maxPlayers,
    visibility: t.visibility,
    status: t.status,
    ownerId: t.ownerId,
    options: t.options,
    isMember:
      !!viewer &&
      ps.some((p: any) => p.telegramId === viewer && p.status === "active"),
    players: ps
      .filter((p: any) => p.status === "active")
      .map((p: any) => ({
        id: p.telegramId,
        name: [p.firstName, p.lastName].filter(Boolean).join(" ") || "Гравець",
        ready: p.ready,
      })),
  };
}
export async function settleTx(
  tx: any,
  t: any,
  ps: any[],
  outcome: ArcadeOutcome
) {
  if (t.status !== "playing") return;
  const active = ps.filter(p => p.status !== "left" || Number(p.contribution) > 0),
    ids = active.map(p => p.telegramId);
  if (
    (
      await tx
        .select()
        .from(gameTableResults)
        .where(eq(gameTableResults.tableId, t.id))
        .limit(1)
    ).length
  )
    return;
  if (
    !Array.isArray(outcome.winnerIds) ||
    outcome.winnerIds.some(x => !ids.includes(x))
  )
    outcome = {
      winnerIds: [],
      draw: true,
      reason: "invalid_refund",
      refundIds: ids,
    };
  const contributions = Object.fromEntries(
    active.map(p => [p.telegramId, p.contribution])
  );
  const pot = Object.values(contributions).reduce((a: any, b: any) => a + b, 0);
  let pays: Record<string, number>;
  let settledOutcome: ArcadeOutcome = outcome;
  if (t.gameId === "blackjack") {
    const bank = (
      await tx
        .select()
        .from(gameCenterBank)
        .where(eq(gameCenterBank.id, "main"))
        .limit(1)
        .for("update")
    )[0];
    if (!bank) throw Error("Shared Blackjack bank is not initialized");
    let settlement;
    try {
      settlement = calculateBlackjackBankPayouts({
        playerIds: ids,
        contributions,
        outcome,
        bankBalance: bank.balance,
      });
    } catch {
      outcome = {
        winnerIds: [],
        draw: true,
        reason: "invalid_refund",
        refundIds: ids,
      };
      settlement = calculateBlackjackBankPayouts({
        playerIds: ids,
        contributions,
        outcome,
        bankBalance: bank.balance,
      });
    }
    pays = settlement.payouts;
    settledOutcome = {
      ...outcome,
      bankSettlement: {
        targetPayouts: settlement.targetPayouts,
        bankBalanceBefore: settlement.bankBalanceBefore,
        availableBank: settlement.availableBank,
        bankBalanceAfter: settlement.bankBalanceAfter,
        bankCapped: settlement.bankCapped,
      },
    };
    const bankDelta = settlement.bankBalanceAfter - bank.balance;
    if (bankDelta !== 0) {
      await tx
        .update(gameCenterBank)
        .set({ balance: settlement.bankBalanceAfter })
        .where(eq(gameCenterBank.id, "main"));
      await tx.insert(gameCenterBankLedger).values({
        tableId: t.id,
        kind: bankDelta > 0 ? "retained_blackjack_losses" : "blackjack_payout",
        amount: bankDelta,
        balanceAfter: settlement.bankBalanceAfter,
        idempotencyKey: `arcade:${t.id}:blackjack-bank`,
      });
    }
  } else {
    try {
      pays = calculatePayouts({ playerIds: ids, contributions, outcome });
    } catch {
      outcome = {
        winnerIds: [],
        draw: true,
        reason: "invalid_refund",
        refundIds: ids,
      };
      settledOutcome = outcome;
      pays = calculatePayouts({ playerIds: ids, contributions, outcome });
    }
    const vipRows = await tx.select({ telegramId: spyWallets.telegramId, vipUntil: spyWallets.vipUntil }).from(spyWallets).where(inArray(spyWallets.telegramId, ids));
    const now = Date.now();
    const vipActiveByPlayer = Object.fromEntries(vipRows.map((row: any) => [row.telegramId, !!row.vipUntil && new Date(row.vipUntil).getTime() > now]));
    const commission = applyArcadeVipCommission(pays, settledOutcome.winnerIds, vipActiveByPlayer, 0.1);
    pays = commission.payouts;
    if (commission.totalCommission > 0) {
      const bank = (await tx.select().from(gameCenterBank).where(eq(gameCenterBank.id, "main")).limit(1).for("update"))[0];
      if (!bank) throw Error("Shared arcade bank is not initialized");
      const bankBalanceAfter = bank.balance + commission.totalCommission;
      await tx.update(gameCenterBank).set({ balance: bankBalanceAfter }).where(eq(gameCenterBank.id, "main"));
      await tx.insert(gameCenterBankLedger).values({
        tableId: t.id,
        kind: "arcade_victory_commission",
        amount: commission.totalCommission,
        balanceAfter: bankBalanceAfter,
        idempotencyKey: `arcade:${t.id}:commission`,
      });
      settledOutcome = { ...settledOutcome, bankCommission: { rate: 0.1, amounts: commission.commissions, total: commission.totalCommission } } as ArcadeOutcome;
    }
  }
  for (const p of active) {
    const n = pays[p.telegramId] || 0,
      w = (
        await tx
          .select()
          .from(spyWallets)
          .where(eq(spyWallets.telegramId, p.telegramId))
          .limit(1)
          .for("update")
      )[0];
    if (!w) throw Error("Wallet missing");
    const key = `arcade:${t.id}:settle:${p.telegramId}`,
      exists = await tx
        .select()
        .from(spyEconomyLedger)
        .where(eq(spyEconomyLedger.idempotencyKey, key))
        .limit(1);
    if (!exists.length && n) {
      await tx
        .update(spyWallets)
        .set({ balance: w.balance + n })
        .where(eq(spyWallets.telegramId, p.telegramId));
      await syncEconomyUserTx(tx, p.telegramId);
      await tx.insert(spyEconomyLedger).values({
        telegramId: p.telegramId,
        kind: "arcade_payout",
        amount: n,
        balanceAfter: w.balance + n,
        idempotencyKey: key,
        referenceId: t.id,
        note: "Arcade settlement",
      });
    }
    const win = settledOutcome.winnerIds.includes(p.telegramId),
      draw = settledOutcome.draw || settledOutcome.refundIds?.includes(p.telegramId);
    await tx
      .update(gameTablePlayers)
      .set({ status: draw ? "draw" : win ? "winner" : "loser" })
      .where(eq(gameTablePlayers.id, p.id));
    const ratings = await tx
      .select()
      .from((await import("../../../drizzle/schema")).gamePlayerStats)
      .where(
        eq(
          (await import("../../../drizzle/schema")).gamePlayerStats.gameId,
          t.gameId
        )
      );
    const ratingById = new Map(
      ratings.map((r: any) => [r.telegramId, r.rating])
    );
    const opponents = active
      .filter((x: any) => x.telegramId !== p.telegramId)
      .map(
        (x: any) =>
          ({
            rating: Number(ratingById.get(x.telegramId) ?? 1000),
            result: settledOutcome.draw
              ? "draw"
              : settledOutcome.winnerIds.includes(x.telegramId)
                ? "win"
                : "loss",
          }) as const
      );
    await recordPlayerStatTx(
      tx,
      p.telegramId,
      t.gameId,
      draw ? "draw" : win ? "win" : "loss",
      n - p.contribution,
      n,
      opponents
    );
  }
  await tx.insert(gameTableResults).values({
    tableId: t.id,
    gameId: t.gameId,
    winnerIds: settledOutcome.winnerIds,
    outcome: settledOutcome as any,
    totalPot: pot,
    payouts: pays,
  });
  await tx
    .update(gameTables)
    .set({ status: "finished", endedAt: new Date(), version: t.version + 1 })
    .where(eq(gameTables.id, t.id));
  await clearActiveRoomForTableTx(tx, t.id);
}
export async function lifecycle(
  id: string,
  user: string,
  action: string,
  b: any,
  identity: any
) {
  const db = await getDb();
  if (!db) throw Error("Database unavailable");
  const result = await db.transaction(async (tx: any) => {
    let t = await lockTable(tx, id);
    if (!(PLAYABLE_ARCADE_GAME_IDS as readonly string[]).includes(t.gameId))
      err("This game is no longer available", 410);
    let ps = await players(tx, id, true),
      me = ps.find((p: any) => p.telegramId === user && p.status === "active"),
      cfg = await readConfig();
    if (action === "join") {
      if (t.status !== "lobby") err("Table not joinable", 409);
      const currentRoom = await resolveActiveRoomTx(tx, user);
      if (currentRoom && currentRoom.id !== id)
        err("Спочатку вийдіть зі свого активного столу.", 409);
      if (t.visibility === "private" && b.inviteToken !== t.inviteToken)
        err("Invite required", 403);
      if (cfg.enabledGames[t.gameId] === false) err("Game disabled", 403);
      const profile = (
        await tx
          .select()
          .from(spyProfiles)
          .where(eq(spyProfiles.telegramId, user))
          .limit(1)
      )[0];
      if (!profile || profile.blocked) err("Registered profile required", 403);
      if (!me) {
        if (ps.filter((p: any) => p.status === "active").length >= t.maxPlayers)
          err("Table full", 409);
        const old = ps.find((p: any) => p.telegramId === user),
          seat =
            old?.seat ??
            (ps.length ? Math.max(...ps.map((p: any) => p.seat)) + 1 : 0),
          vals = {
            status: "active",
            ready: false,
            firstName: identity.firstName,
            lastName: identity.lastName ?? null,
            username: identity.username ?? null,
            avatarUrl: identity.avatarUrl ?? null,
          };
        if (old)
          await tx
            .update(gameTablePlayers)
            .set(vals)
            .where(eq(gameTablePlayers.id, old.id));
        else
          await tx.insert(gameTablePlayers).values({
            tableId: id,
            telegramId: user,
            ...vals,
            seat,
            contribution: 0,
          });
      }
      await setActiveRoomTx(tx, user, id);
    } else {
      if (!me) err("Not participant", 403);
      if (action === "reaction") {
        const allowed = ["😂", "🤦", "🤬", "😏", "😭", "🤩", "😉"];
        if (t.gameId !== "durak" || t.status !== "playing" || typeof b.emoji !== "string" || !allowed.includes(b.emoji)) err("Недоступна ця реакція.", 409);
        const seq = (await tx.select({ n: sql<number>`coalesce(max(${gameTableEvents.sequence}),0)` }).from(gameTableEvents).where(eq(gameTableEvents.tableId, id)))[0].n;
        await tx.insert(gameTableEvents).values({ tableId: id, sequence: seq + 1, actionId: `reaction:${randomUUID()}`, actorId: user, eventType: "reaction", publicPayload: { actorId: user, emoji: b.emoji } });
        await tx.update(gameTablePlayers).set({ lastSeenAt: new Date() }).where(eq(gameTablePlayers.id, me.id));
      } else if (action === "heartbeat") {
        const now = new Date();
        const nowMs = now.getTime();
        if (t.status === "playing") {
          const engine = arcadeEngines.get(t.gameId);
          const state = t.state as any;
          const deadline = engine?.getDeadline(state) ?? null;
          const currentId = stateCurrentPlayerId(state);
          const graceMs =
            Math.max(0, Number(cfg.reconnectGraceSeconds) || 0) * 1000;
          const marker = `${currentId}:${deadline}`;
          const canResume = shouldExtendTurnForReconnect({
            isCurrentPlayer: currentId === user,
            lastSeenAt: me.lastSeenAt,
            turnDeadline: deadline,
            now: nowMs,
            graceMs,
            graceAlreadyUsed: state.__gameCenterReconnectGraceFor === marker,
            heartbeatStaleMs: RECONNECT_HEARTBEAT_STALE_MS,
          });
          if (canResume && engine) {
            const turnMs =
              Number.isSafeInteger(state.turnMs) && state.turnMs > 0
                ? state.turnMs
                : Number(cfg.turnTimeoutSeconds) * 1000;
            const resumedState = {
              ...state,
              deadline: nowMs + turnMs,
              __gameCenterReconnectGraceFor: marker,
            };
            await tx
              .update(gameTables)
              .set({ state: resumedState, version: t.version + 1 })
              .where(eq(gameTables.id, id));
            t = { ...t, state: resumedState, version: t.version + 1 };
          }
        }
        await tx
          .update(gameTablePlayers)
          .set({ lastSeenAt: now })
          .where(eq(gameTablePlayers.id, me.id));
      } else if (action === "ready") {
        if (t.status !== "lobby" || typeof b.ready !== "boolean")
          err("Invalid ready", 409);
        await tx
          .update(gameTablePlayers)
          .set({ ready: b.ready, lastSeenAt: new Date() })
          .where(eq(gameTablePlayers.id, me.id));
      } else if (action === "leave") {
        if (!(["lobby", "playing"].includes(t.status)) || (t.status === "lobby" && user === t.ownerId))
          err("Cannot leave this table", 409);
        await tx
          .update(gameTablePlayers)
          .set({ status: "left", ready: false })
          .where(eq(gameTablePlayers.id, me.id));
        await clearActiveRoomTx(tx, user, id);
      } else if (action === "kick") {
        if (user !== t.ownerId || t.status !== "lobby") err("Owner only", 403);
        const p = ps.find(
          (x: any) =>
            x.telegramId === b.playerId &&
            x.status === "active" &&
            x.telegramId !== user
        );
        if (!p) err("Player not found");
        await tx
          .update(gameTablePlayers)
          .set({ status: "left", ready: false })
          .where(eq(gameTablePlayers.id, p.id));
        await clearActiveRoomTx(tx, p.telegramId, id);
      } else if (action === "cancel") {
        if (user !== t.ownerId || t.status !== "lobby") err("Owner only", 403);
        await tx.update(gameTablePlayers).set({ status: "left", ready: false }).where(and(
          eq(gameTablePlayers.tableId, id), eq(gameTablePlayers.status, "active")
        ));
        await clearActiveRoomForTableTx(tx, id);
        await tx
          .update(gameTables)
          .set({
            status: "cancelled",
            endedAt: new Date(),
            version: t.version + 1,
          })
          .where(eq(gameTables.id, id));
      } else if (action === "start") {
        if (user !== t.ownerId || t.status !== "lobby") err("Owner only", 403);
        if (cfg.enabledGames[t.gameId] === false) err("Game disabled", 403);
        const active = ps
          .filter((p: any) => p.status === "active")
          .sort((a: any, b: any) => a.id - b.id);
        if (active.length < t.minPlayers || active.some((p: any) => !p.ready))
          err("Players not ready", 409);
        for (const p of active) {
          const w = (
            await tx
              .select()
              .from(spyWallets)
              .where(eq(spyWallets.telegramId, p.telegramId))
              .limit(1)
              .for("update")
          )[0];
          if (!w || w.balance < t.stake) err("Insufficient balance", 409);
          const key = `arcade:${id}:stake:${p.telegramId}`;
          await tx
            .update(spyWallets)
            .set({ balance: w.balance - t.stake })
            .where(eq(spyWallets.telegramId, p.telegramId));
          await syncEconomyUserTx(tx, p.telegramId);
          await tx.insert(spyEconomyLedger).values({
            telegramId: p.telegramId,
            kind: "arcade_stake",
            amount: -t.stake,
            balanceAfter: w.balance - t.stake,
            idempotencyKey: key,
            referenceId: id,
            note: "Arcade stake",
          });
          await tx
            .update(gameTablePlayers)
            .set({ contribution: t.stake, lastSeenAt: new Date() })
            .where(eq(gameTablePlayers.id, p.id));
        }
        const state = arcadeEngines.get(t.gameId)!.create(
          active.map((p: any) => ({
            id: p.telegramId,
            name: p.firstName,
            seat: p.seat,
          })),
          {
            ...t.options,
            stake: t.stake,
            turnMs: cfg.turnTimeoutSeconds * 1000,
          },
          { now: Date.now(), randomInt: secureRandomInt }
        );
        await tx
          .update(gameTables)
          .set({
            status: "playing",
            state,
            startedAt: new Date(),
            lobbyExpiresAt: null,
            version: t.version + 1,
          })
          .where(eq(gameTables.id, id));
        if ((state as any)?.outcome) {
          const started = {
            ...t,
            status: "playing",
            state,
            version: t.version + 1,
          };
          await settleTx(
            tx,
            started,
            await players(tx, id, true),
            (state as any).outcome
          );
        }
      } else if (action === "action") {
        if (
          t.status !== "playing" ||
          typeof b.actionId !== "string" ||
          !/^[\w-]{8,80}$/.test(b.actionId) ||
          !b.action ||
          typeof b.action !== "object"
        )
          err("Invalid action", 400);
        const dupe = await tx
          .select()
          .from(gameTableEvents)
          .where(
            and(
              eq(gameTableEvents.tableId, id),
              eq(gameTableEvents.actionId, b.actionId)
            )
          )
          .limit(1);
        if (!dupe.length) {
          const engine = arcadeEngines.get(t.gameId)!;
          const deadline = engine.getDeadline(t.state);
          if (deadline !== null && deadline <= Date.now())
            err("Час ходу завершився", 409);
          let step: any;
          try {
            step = engine.applyAction(t.state, user, b.action, {
              now: Date.now(),
              randomInt: secureRandomInt,
            });
          } catch (e: any) {
            err(e.message || "Illegal action", 400);
          }
          await tx
            .update(gameTablePlayers)
            .set({ lastSeenAt: new Date() })
            .where(eq(gameTablePlayers.id, me.id));
          if (step.additionalStake) {
            const p = ps.find(
                (x: any) => x.telegramId === step.additionalStake.playerId
              ),
              w =
                p &&
                (
                  await tx
                    .select()
                    .from(spyWallets)
                    .where(eq(spyWallets.telegramId, p.telegramId))
                    .limit(1)
                    .for("update")
                )[0];
            if (!p || !w || w.balance < step.additionalStake.amount)
              err("Insufficient balance", 409);
            const key = `arcade:${id}:extra:${b.actionId}:${p.telegramId}`;
            await tx
              .update(spyWallets)
              .set({ balance: w.balance - step.additionalStake.amount })
              .where(eq(spyWallets.telegramId, p.telegramId));
            await syncEconomyUserTx(tx, p.telegramId);
            await tx.insert(spyEconomyLedger).values({
              telegramId: p.telegramId,
              kind: "arcade_stake",
              amount: -step.additionalStake.amount,
              balanceAfter: w.balance - step.additionalStake.amount,
              idempotencyKey: key,
              referenceId: id,
              note: "Extra stake",
            });
            await tx
              .update(gameTablePlayers)
              .set({
                contribution: p.contribution + step.additionalStake.amount,
              })
              .where(eq(gameTablePlayers.id, p.id));
            ps = await players(tx, id, true);
          }
          const seq = (
            await tx
              .select({
                n: sql<number>`coalesce(max(${gameTableEvents.sequence}),0)`,
              })
              .from(gameTableEvents)
              .where(eq(gameTableEvents.tableId, id))
          )[0].n;
          for (let i = 0; i < step.events.length; i++) {
            const v = step.events[i];
            await tx.insert(gameTableEvents).values({
              tableId: id,
              sequence: seq + i + 1,
              actionId: i ? `${b.actionId}:${i}` : b.actionId,
              actorId: user,
              eventType: v.type.slice(0, 40),
              publicPayload: { actorId: v.actorId, publicText: v.publicText },
            });
          }
          await tx
            .update(gameTables)
            .set({ state: step.state, version: t.version + 1 })
            .where(eq(gameTables.id, id));
          t = { ...t, state: step.state, version: t.version + 1 };
          if (step.outcome) await settleTx(tx, t, ps, step.outcome);
        }
      } else err("Unsupported transition");
    }
    const latest = (
      await tx.select().from(gameTables).where(eq(gameTables.id, id)).limit(1)
    )[0];
    if (latest && ["lobby", "playing"].includes(latest.status) && !["leave", "cancel", "kick"].includes(action)) {
      const stillActive = (await tx.select().from(gameTablePlayers).where(and(
        eq(gameTablePlayers.tableId, id), eq(gameTablePlayers.telegramId, user), eq(gameTablePlayers.status, "active")
      )).limit(1))[0];
      if (stillActive) await setActiveRoomTx(tx, user, id);
    }
    return { table: await projectTable(latest, user, tx) };
  });
  if (action === "reaction") {
    const reaction = [...(((result as any)?.table?.events || []) as any[])]
      .reverse()
      .find(event => event.type === "reaction" && event.playerId === user);
    if (reaction && typeof reaction.emoji === "string") {
      const at = reaction.at instanceof Date ? reaction.at.toISOString() : String(reaction.at || new Date().toISOString());
      broadcastDurakReaction(id, { playerId: user, emoji: reaction.emoji, at });
    }
  }
  return result;
}
export async function timeoutTable(id: string, now = Date.now()) {
  const db = await getDb();
  if (!db) return;
  await db.transaction(async (tx: any) => {
    const t = await lockTable(tx, id);
    if (t.status !== "playing") return;
    const e = arcadeEngines.get(t.gameId),
      d = e?.getDeadline(t.state);
    if (!e || d == null || d > now) return;
    const ps = await players(tx, id, true);
    const cfg = await readConfig();
    const activeId = stateCurrentPlayerId(t.state);
    const current = ps.find((p: any) => p.telegramId === activeId);
    const graceMs = Math.max(0, Number(cfg.reconnectGraceSeconds) || 0) * 1000;
    if (current && shouldWaitForReconnect(current.lastSeenAt, d, now, graceMs))
      return;
    let step: any;
    try {
      step = e.onTimeout?.(t.state, { now, randomInt: secureRandomInt });
    } catch {}
    if (!step?.outcome) {
      const ids = ps
        .filter((p: any) => p.status !== "left")
        .map((p: any) => p.telegramId);
      step = {
        state: t.state,
        events: [
          { type: "timeout_refund", publicText: "Технічний timeout — refund." },
        ],
        outcome: {
          winnerIds: [],
          draw: true,
          refundIds: ids,
          reason: "timeout_refund",
        },
      };
    }
    const seq = (
      await tx
        .select({
          n: sql<number>`coalesce(max(${gameTableEvents.sequence}),0)`,
        })
        .from(gameTableEvents)
        .where(eq(gameTableEvents.tableId, id))
    )[0].n;
    for (let i = 0; i < step.events.length; i++) {
      const v = step.events[i];
      await tx.insert(gameTableEvents).values({
        tableId: id,
        sequence: seq + i + 1,
        actionId: `timeout:${t.version}:${i}`,
        actorId: v.actorId || "system",
        eventType: v.type.slice(0, 40),
        publicPayload: { publicText: v.publicText },
      });
    }
    await tx
      .update(gameTables)
      .set({ state: step.state, version: t.version + 1 })
      .where(eq(gameTables.id, id));
    await settleTx(
      tx,
      { ...t, state: step.state, version: t.version + 1 },
      ps,
      step.outcome
    );
  });
}
