import { randomInt } from "node:crypto";
import type { GroupGameStatus } from "../../drizzle/schema";

export type GroupMode = "spyfall" | "secret_word";
export type GroupRole = "spy" | "civilian";
export type GroupPhase =
  | "lobby"
  | "choose_target"
  | "await_question"
  | "await_answer"
  | "voting"
  | "execution_vote"
  | "spy_guess"
  | "finished"
  | "cancelled";
export type GroupVoteStage = "accusation" | "execution";

export type GroupPlayer = {
  id: string;
  firstName: string;
  lastName?: string;
  username?: string;
  role?: GroupRole;
};

export type GroupQuestion = {
  fromId: string;
  toId: string;
  question: string;
  answer?: string;
  askedAt: number;
  answeredAt?: number;
};

export type GroupGameState = {
  roundId: string;
  hostId: string;
  status: GroupGameStatus;
  phase: GroupPhase;
  mode: GroupMode;
  spyCount: number;
  maxPlayers: number;
  durationMinutes: number;
  players: GroupPlayer[];
  eliminatedPlayerIds: string[];
  secret: string | null;
  category: string | null;
  secretCandidates: string[];
  spectatorNoticeSent?: boolean;
  guessPromptSent?: boolean;
  guessAnnounced?: boolean;
  resultAnnounced?: boolean;
  activeAskerId: string | null;
  targetId: string | null;
  pendingQuestionIndex: number | null;
  questions: GroupQuestion[];
  votes: Record<string, string>;
  voteStage?: GroupVoteStage | null;
  accusedId?: string | null;
  executionVotes?: Record<string, boolean>;
  voteMessageId?: number | null;
  accusationVoteHistory?: Array<{ voterId: string; targetId: string }>;
  voteEndsAt: number | null;
  roundStartedAt: number | null;
  roundEndsAt: number | null;
  guesserId: string | null;
  guessEndsAt?: number | null;
  winner: "spies" | "civilians" | null;
  resultText: string | null;
  resultAnnouncementToken?: string | null;
  resultAnnouncementLeaseUntil?: number | null;
};

export type GroupActor = Pick<
  GroupPlayer,
  "id" | "firstName" | "lastName" | "username"
>;

export function newGroupLobby(
  roundId: string,
  host: GroupActor,
  options?: { spyCount?: number; mode?: GroupMode }
): GroupGameState {
  const hostPlayer: GroupPlayer = { ...host };
  return {
    roundId,
    hostId: host.id,
    status: "lobby",
    phase: "lobby",
    mode: options?.mode || "spyfall",
    spyCount: options?.spyCount || 1,
    maxPlayers: 12,
    durationMinutes: 7,
    players: [hostPlayer],
    eliminatedPlayerIds: [],
    secret: null,
    category: null,
    secretCandidates: [],
    spectatorNoticeSent: false,
    activeAskerId: null,
    targetId: null,
    pendingQuestionIndex: null,
    questions: [],
    votes: {},
    voteStage: null,
    accusedId: null,
    executionVotes: {},
    voteMessageId: null,
    accusationVoteHistory: [],
    voteEndsAt: null,
    roundStartedAt: null,
    roundEndsAt: null,
    guesserId: null,
    guessEndsAt: null,
    winner: null,
    resultText: null,
  };
}

export function isGroupPlayer(state: GroupGameState, userId: string) {
  return state.players.some(player => player.id === userId);
}

export function activeGroupPlayers(state: GroupGameState) {
  const eliminated = new Set(state.eliminatedPlayerIds || []);
  return state.players.filter(player => !eliminated.has(player.id));
}

export function isActiveGroupPlayer(state: GroupGameState, userId: string) {
  return (
    isGroupPlayer(state, userId) &&
    !(state.eliminatedPlayerIds || []).includes(userId)
  );
}

export function joinGroupLobby(
  state: GroupGameState,
  player: GroupActor
): GroupGameState {
  if (state.status !== "lobby") throw new Error("Гра вже почалася.");
  if (isGroupPlayer(state, player.id)) return state;
  if (state.players.length >= state.maxPlayers)
    throw new Error("У кімнаті вже 12 гравців.");
  if (state.players.some(existing => existing.id === player.id)) return state;
  return {
    ...state,
    hostId: state.hostId || player.id,
    players: [...state.players, { ...player }],
  };
}

export function leaveGroupLobby(
  state: GroupGameState,
  userId: string
): GroupGameState {
  if (state.status !== "lobby")
    throw new Error("Під час гри вийти з лобі вже не можна.");
  const players = state.players.filter(player => player.id !== userId);
  const hostId = userId === state.hostId ? players[0]?.id || "" : state.hostId;
  return { ...state, hostId, players };
}

export function setGroupOptions(
  state: GroupGameState,
  options: { spyCount?: number; mode?: GroupMode; durationMinutes?: number }
): GroupGameState {
  if (state.status !== "lobby")
    throw new Error("Налаштування можна змінювати лише в лобі.");
  const spyCount = options.spyCount ?? state.spyCount;
  const durationMinutes = options.durationMinutes ?? state.durationMinutes;
  const mode = options.mode ?? state.mode;
  if (!Number.isInteger(spyCount) || spyCount < 1 || spyCount > 3)
    throw new Error("Кількість шпигунів має бути від 1 до 3.");
  if (
    !Number.isInteger(durationMinutes) ||
    ![5, 7, 10, 15].includes(durationMinutes)
  )
    throw new Error("Тривалість має бути 5, 7, 10 або 15 хвилин.");
  if (spyCount >= state.players.length && state.players.length >= 3)
    throw new Error("Шпигунів має бути менше, ніж гравців.");
  return { ...state, spyCount, mode, durationMinutes };
}

export function startGroupRound(
  state: GroupGameState,
  input: {
    spyIds: string[];
    secret: string;
    category?: string;
    secretCandidates?: string[];
    now?: number;
  }
): GroupGameState {
  if (state.status !== "lobby") throw new Error("Лобі вже закрите.");
  if (state.players.length < 3)
    throw new Error("Для початку потрібно щонайменше 3 гравці.");
  if (state.spyCount >= state.players.length)
    throw new Error("Шпигунів має бути менше, ніж гравців.");
  if (
    input.spyIds.length !== state.spyCount ||
    input.spyIds.some(id => !isGroupPlayer(state, id))
  )
    throw new Error("Некоректний розподіл ролей.");
  const spyIds = new Set(input.spyIds);
  const players = state.players.map(player => ({
    ...player,
    role: spyIds.has(player.id) ? ("spy" as const) : ("civilian" as const),
  }));
  const now = input.now ?? Date.now();
  return {
    ...state,
    status: "playing",
    phase: "choose_target",
    players,
    eliminatedPlayerIds: [],
    secret: input.secret,
    category: input.category || null,
    secretCandidates: input.secretCandidates || [],
    spectatorNoticeSent: false,
    guessPromptSent: false,
    guessAnnounced: false,
    resultAnnounced: false,
    activeAskerId: players[randomInt(players.length)]!.id,
    targetId: null,
    pendingQuestionIndex: null,
    votes: {},
    voteStage: null,
    accusedId: null,
    executionVotes: {},
    voteMessageId: null,
    accusationVoteHistory: [],
    voteEndsAt: null,
    roundStartedAt: now,
    roundEndsAt: now + state.durationMinutes * 60_000,
    guesserId: null,
    guessEndsAt: null,
    winner: null,
    resultText: null,
  };
}

export function chooseQuestionTarget(
  state: GroupGameState,
  askerId: string,
  targetId: string
): GroupGameState {
  if (state.status !== "playing" || state.phase !== "choose_target")
    throw new Error("Зараз не час обирати адресата запитання.");
  if (state.activeAskerId !== askerId)
    throw new Error("Зараз черга іншого гравця.");
  if (
    !isActiveGroupPlayer(state, askerId) ||
    targetId === askerId ||
    !isActiveGroupPlayer(state, targetId)
  )
    throw new Error("Оберіть іншого активного учасника гри.");
  return { ...state, phase: "await_question", targetId };
}

export function recordGroupQuestion(
  state: GroupGameState,
  userId: string,
  text: string,
  now = Date.now()
): GroupGameState {
  if (state.status !== "playing" || state.phase !== "await_question")
    throw new Error("Зараз не очікується запитання.");
  if (
    state.activeAskerId !== userId ||
    !isActiveGroupPlayer(state, userId) ||
    !state.targetId ||
    !isActiveGroupPlayer(state, state.targetId)
  )
    throw new Error(
      "Запитання має надіслати активний гравець обраному активному адресату."
    );
  const question = text.trim().slice(0, 350);
  if (!question) throw new Error("Запитання не може бути порожнім.");
  const questions = [
    ...state.questions,
    { fromId: userId, toId: state.targetId, question, askedAt: now },
  ];
  return {
    ...state,
    questions,
    pendingQuestionIndex: questions.length - 1,
    phase: "await_answer",
  };
}

export function recordGroupAnswer(
  state: GroupGameState,
  userId: string,
  text: string,
  now = Date.now()
): GroupGameState {
  if (
    state.status !== "playing" ||
    state.phase !== "await_answer" ||
    state.pendingQuestionIndex === null
  )
    throw new Error("Зараз не очікується відповідь.");
  const pending = state.questions[state.pendingQuestionIndex];
  if (
    !pending ||
    pending.toId !== userId ||
    !isActiveGroupPlayer(state, userId) ||
    !isActiveGroupPlayer(state, pending.fromId)
  )
    throw new Error("На запитання має відповісти обраний активний гравець.");
  const answer = text.trim().slice(0, 350);
  if (!answer) throw new Error("Відповідь не може бути порожньою.");
  const questions = state.questions.map((item, index) =>
    index === state.pendingQuestionIndex
      ? { ...item, answer, answeredAt: now }
      : item
  );
  return {
    ...state,
    questions,
    activeAskerId: userId,
    targetId: null,
    pendingQuestionIndex: null,
    phase: "choose_target",
  };
}

export function beginGroupVote(
  state: GroupGameState,
  userId: string,
  now = Date.now()
): GroupGameState {
  if (state.status !== "playing")
    throw new Error("Голосування зараз недоступне.");
  if (!isActiveGroupPlayer(state, userId))
    throw new Error("Голосувати можуть лише активні учасники.");
  return {
    ...state,
    status: "voting",
    phase: "voting",
    votes: {},
    voteStage: "accusation",
    accusedId: null,
    executionVotes: {},
    voteMessageId: null,
    voteEndsAt: now + 60_000,
    targetId: null,
    pendingQuestionIndex: null,
  };
}

export type VoteResolution = {
  state: GroupGameState;
  resolved: boolean;
  accusedId?: string;
  result?: "civilians_win" | "continue" | "spies_win" | "execution_vote";
};

function voteStage(state: GroupGameState): GroupVoteStage {
  // Existing JSON rows predate voteStage and represent the accusation ballot.
  return state.voteStage || "accusation";
}

function continueAfterVote(
  state: GroupGameState,
  accusedId: string,
  now: number,
  eliminatedId?: string
): VoteResolution {
  const eliminatedPlayerIds = eliminatedId
    ? [...new Set([...(state.eliminatedPlayerIds || []), eliminatedId])]
    : [...(state.eliminatedPlayerIds || [])];
  const nextState: GroupGameState = {
    ...state,
    status: "playing",
    phase: "choose_target",
    eliminatedPlayerIds,
    votes: {},
    voteStage: null,
    accusedId: null,
    executionVotes: {},
    voteEndsAt: null,
    activeAskerId: null,
    targetId: null,
    pendingQuestionIndex: null,
  };
  const active = activeGroupPlayers(nextState);
  const spies = active.filter(player => player.role === "spy").length;
  const agents = active.length - spies;
  if (spies === 0) {
    return {
      state: finishGroupRound(
        nextState,
        "civilians",
        "Усіх шпигунів викрито. Агенти перемогли."
      ),
      resolved: true,
      accusedId,
      result: "civilians_win",
    };
  }
  if (agents === 0 || (spies === 1 && agents === 1)) {
    return {
      state: finishGroupRound(
        nextState,
        "spies",
        "Залишилися один шпигун і один агент. Шпигун переміг."
      ),
      resolved: true,
      accusedId,
      result: "spies_win",
    };
  }
  if (state.roundEndsAt !== null && now >= state.roundEndsAt) {
    return {
      state: finishGroupRound(
        nextState,
        "spies",
        "Час раунду сплив. Перемогли шпигуни."
      ),
      resolved: true,
      accusedId,
      result: "spies_win",
    };
  }
  const nextAsker = active[randomInt(active.length)];
  return {
    state: { ...nextState, activeAskerId: nextAsker?.id || null },
    resolved: true,
    accusedId,
    result: "continue",
  };
}

function resolveExecutionVote(
  state: GroupGameState,
  now: number
): VoteResolution {
  const accusedId = state.accusedId || undefined;
  if (!accusedId) return { state, resolved: false };
  const votes = Object.entries(state.executionVotes || {}).filter(([voterId]) =>
    isActiveGroupPlayer(state, voterId)
  );
  const yesCount = votes.filter(([, approve]) => approve).length;
  const activeCount = activeGroupPlayers(state).length;
  const required = Math.floor(activeCount / 2) + 1;
  const timedOut = state.voteEndsAt !== null && now >= state.voteEndsAt;
  if (!timedOut) return { state, resolved: false, accusedId };
  if (yesCount >= required) {
    const accused = state.players.find(player => player.id === accusedId);
    if (!accused || !isActiveGroupPlayer(state, accusedId))
      return continueAfterVote(state, accusedId, now);
    if (accused.role === "spy") {
      const eliminatedPlayerIds = [
        ...new Set([...(state.eliminatedPlayerIds || []), accused.id]),
      ];
      return {
        state: finishGroupRound(
          { ...state, eliminatedPlayerIds },
          "civilians",
          `Шпигуна ${accused.username ? `@${accused.username}` : accused.firstName} страчено. Гра завершена негайно.`
        ),
        resolved: true,
        accusedId,
        result: "civilians_win",
      };
    }
    return continueAfterVote(state, accusedId, now, accusedId);
  }
  return continueAfterVote(state, accusedId, now);
}

export function resolveGroupVote(
  state: GroupGameState,
  now = Date.now()
): VoteResolution {
  if (state.status !== "voting") return { state, resolved: false };
  if (voteStage(state) === "execution") return resolveExecutionVote(state, now);

  const votes = Object.fromEntries(
    Object.entries(state.votes || {}).filter(
      ([voterId, targetId]) =>
        isActiveGroupPlayer(state, voterId) &&
        isActiveGroupPlayer(state, targetId)
    )
  );
  const timedOut = state.voteEndsAt !== null && now >= state.voteEndsAt;
  const counts = new Map<string, number>();
  for (const targetId of Object.values(votes))
    counts.set(targetId, (counts.get(targetId) || 0) + 1);
  let accusedId: string | undefined;
  let maxVotes = 0;
  for (const [targetId, count] of counts) {
    if (count > maxVotes) {
      maxVotes = count;
      accusedId = targetId;
    }
  }
  const hasMajority = Boolean(
    accusedId && maxVotes > activeGroupPlayers(state).length / 2
  );
  if (!timedOut) return { state, resolved: false };
  if (hasMajority && accusedId) {
    return {
      state: {
        ...state,
        phase: "execution_vote",
        voteStage: "execution",
        accusedId,
        executionVotes: {},
        voteEndsAt: now + 60_000,
      },
      resolved: true,
      accusedId,
      result: "execution_vote",
    };
  }
  const roundExpired = state.roundEndsAt !== null && now >= state.roundEndsAt;
  if (roundExpired) {
    return {
      state: finishGroupRound(
        state,
        "spies",
        "Час сплив, і голосування не виявило підозрюваного більшістю."
      ),
      resolved: true,
      result: "spies_win",
    };
  }
  return {
    state: {
      ...state,
      status: "playing",
      phase: "choose_target",
      votes: {},
      voteStage: null,
      accusedId: null,
      executionVotes: {},
      voteEndsAt: null,
      activeAskerId:
        activeGroupPlayers(state)[randomInt(activeGroupPlayers(state).length)]
          ?.id || null,
      targetId: null,
      pendingQuestionIndex: null,
    },
    resolved: true,
    result: "continue",
  };
}

export function castGroupVote(
  state: GroupGameState,
  voterId: string,
  targetId: string,
  now = Date.now()
): VoteResolution {
  if (state.status !== "voting" || voteStage(state) !== "accusation")
    throw new Error("Зараз не триває голосування за підозрюваного.");
  if (!isActiveGroupPlayer(state, voterId))
    throw new Error("Голосувати можуть лише активні учасники.");
  if (state.voteEndsAt !== null && now >= state.voteEndsAt)
    throw new Error("Час голосування за підозрюваного завершився.");
  if (voterId === targetId) throw new Error("Не можна голосувати за себе.");
  if (!isActiveGroupPlayer(state, targetId))
    throw new Error("Оберіть активного учасника цієї партії.");
  const votes = state.votes || {};
  if (Object.hasOwn(votes, voterId)) throw new Error("Ви вже проголосували.");
  const updated = {
    ...state,
    votes: { ...votes, [voterId]: targetId },
    accusationVoteHistory: [
      ...(state.accusationVoteHistory || []),
      { voterId, targetId },
    ],
  };
  return resolveGroupVote(updated, now);
}

export function castExecutionVote(
  state: GroupGameState,
  voterId: string,
  approveExecution: boolean,
  now = Date.now()
): VoteResolution {
  if (state.status !== "voting" || voteStage(state) !== "execution")
    throw new Error("Зараз не триває голосування про страту.");
  if (!isActiveGroupPlayer(state, voterId))
    throw new Error("Голосувати можуть лише активні учасники.");
  if (state.voteEndsAt !== null && now >= state.voteEndsAt)
    throw new Error("Час голосування за вирок завершився.");
  const votes = state.executionVotes || {};
  if (Object.hasOwn(votes, voterId)) throw new Error("Ви вже проголосували.");
  return resolveGroupVote(
    { ...state, executionVotes: { ...votes, [voterId]: approveExecution } },
    now
  );
}

export function cancelGroupRound(
  state: GroupGameState,
  reason: string
): GroupGameState {
  return {
    ...state,
    status: "cancelled",
    phase: "cancelled",
    voteEndsAt: null,
    guessEndsAt: null,
    resultText: reason,
  };
}

export function finishGroupRound(
  state: GroupGameState,
  winner: "spies" | "civilians",
  resultText: string
): GroupGameState {
  return {
    ...state,
    status: "finished",
    phase: "finished",
    winner,
    resultText,
    voteEndsAt: null,
    guessEndsAt: null,
  };
}

export function claimGroupResultAnnouncement(
  state: GroupGameState,
  token: string,
  now = Date.now(),
  leaseMs = 60_000
) {
  if (
    state.status !== "finished" ||
    state.resultAnnounced ||
    (state.resultAnnouncementLeaseUntil ?? 0) > now
  ) {
    return { state, claimed: false };
  }
  return {
    state: {
      ...state,
      resultAnnouncementToken: token,
      resultAnnouncementLeaseUntil: now + leaseMs,
    },
    claimed: true,
  };
}

export function completeGroupResultAnnouncement(
  state: GroupGameState,
  token: string
) {
  if (state.resultAnnouncementToken !== token) return state;
  return {
    ...state,
    resultAnnounced: true,
    resultAnnouncementToken: null,
    resultAnnouncementLeaseUntil: null,
  };
}

export function formatGroupWinnerAnnouncement(
  state: Pick<GroupGameState, "winner" | "players" | "spyCount">
) {
  const spyCount =
    state.players.filter(player => player.role === "spy").length ||
    state.spyCount;
  if (state.winner === "spies") {
    return spyCount === 1
      ? "Переміг шпигун 🕵️‍♂️ — агенти програли."
      : "Перемогли шпигуни 🕵️‍♂️ — агенти програли.";
  }
  return state.winner === "civilians"
    ? `Перемогли агенти 🕴️ — ${spyCount === 1 ? "шпигун програв." : "шпигуни програли."}`
    : "Партію завершено.";
}

export function tickGroupRound(
  state: GroupGameState,
  now = Date.now()
): VoteResolution {
  if (state.status === "spy_guess") {
    const spy = state.players.find(player => player.id === state.guesserId);
    const name = spy
      ? spy.username
        ? `@${spy.username}`
        : spy.firstName
      : "Шпигун";
    return {
      state: finishGroupRound(
        state,
        "civilians",
        `Шпигуна ${name} страчено. Гра завершена негайно.`
      ),
      resolved: true,
      result: "civilians_win",
    };
  }
  if (
    state.status === "playing" &&
    state.roundEndsAt !== null &&
    now >= state.roundEndsAt
  ) {
    const voting: GroupGameState = {
      ...state,
      status: "voting",
      phase: "voting",
      votes: {},
      voteStage: "accusation",
      accusedId: null,
      executionVotes: {},
      voteMessageId: null,
      voteEndsAt: now + 60_000,
      targetId: null,
      pendingQuestionIndex: null,
    };
    return { state: voting, resolved: false, result: "continue" };
  }
  if (state.status === "voting") return resolveGroupVote(state, now);
  return { state, resolved: false };
}
