import { describe, expect, it } from "vitest";
import { PLAYABLE_ARCADE_GAME_IDS } from "./tableService";

describe("active Mini App game catalog", () => {
  it("exposes only the three games in the latest owner specification", () => {
    expect([...PLAYABLE_ARCADE_GAME_IDS]).toEqual([
      "battleship",
      "durak",
      "tic_tac_toe",
    ]);
    expect(PLAYABLE_ARCADE_GAME_IDS).not.toContain("blackjack");
  });
});
