import { randomInt, randomUUID } from "node:crypto";
import { and, asc, eq, inArray } from "drizzle-orm";
import { getDb } from "../db";
import {
  spyGameConfig,
  spyGames,
  spyGroupGames,
  spyLocations,
  spyProfiles,
  type GroupGameStatus,
} from "../../drizzle/schema";
import { LOCATION_CATALOG } from "./catalog";
import { SECRET_WORDS } from "./secretWords";
import {
  beginGroupVote,
  claimGroupResultAnnouncement,
  cancelGroupRound,
  castExecutionVote,
  castGroupVote,
  chooseQuestionTarget,
  completeGroupResultAnnouncement,
  formatGroupWinnerAnnouncement,
  activeGroupPlayers,
  finishGroupRound,
  isActiveGroupPlayer,
  joinGroupLobby,
  leaveGroupLobby,
  newGroupLobby,
  recordGroupAnswer,
  recordGroupQuestion,
  resolveGroupVote,
  setGroupOptions,
  startGroupRound,
  tickGroupRound,
  type GroupActor,
  type GroupGameState,
  type GroupMode,
  type GroupPlayer,
} from "./groupGameRules";
import { parseGroupCallback } from "./groupGameCallbacks";
import { EconomyError, getBalance } from "./economy";
import {
  protectSpectatorMessage,
  restoreGroupPermissionSnapshots,
} from "./groupPermissions";
import { updateProfilesForResult } from "./resultService";
import {
  isTelegramAdmin,
  telegramBotUsername,
  telegramCall,
  type TelegramButton,
  type TelegramChatMember,
  type TelegramMessage,
  type TelegramMarkup,
  type TelegramUser,
} from "./telegramApi";

const DEFAULT_XP = { participation: 25, win: 35 };
const ACTIVE_STATUSES = ["playing", "voting", "spy_guess"] as const;
let groupWorker: ReturnType<typeof setInterval> | undefined;
let groupWorkerRunning = false;
let lastSettledSweepAt = 0;
let botIdPromise: Promise<number> | undefined;
const voteMessageQueues = new Map<string, Promise<void>>();

function dbOrThrow() {
  return getDb().then(db => {
    if (!db) throw new Error("База даних групової гри тимчасово недоступна.");
    return db;
  });
}

function actorFromUser(user: TelegramUser): GroupActor {
  return {
    id: String(user.id),
    firstName: user.first_name?.trim() || "Агент",
    lastName: user.last_name?.trim() || undefined,
    username: user.username || undefined,
  };
}

function identityFromUser(user: TelegramUser) {
  return {
    id: String(user.id),
    firstName: user.first_name?.trim() || "Агент",
    lastName: user.last_name?.trim() || null,
    username: user.username || null,
  };
}

function displayName(
  player?: Pick<GroupPlayer, "firstName" | "lastName" | "username">
) {
  if (!player) return "Гравець";
  if (player.username) return `@${player.username}`;
  return (
    [player.firstName, player.lastName].filter(Boolean).join(" ") ||
    player.firstName
  );
}

function stateFromRow(row: { state: unknown }): GroupGameState {
  const state = row.state as Partial<GroupGameState>;
  return {
    ...state,
    votes: state.votes || {},
    eliminatedPlayerIds: state.eliminatedPlayerIds || [],
    executionVotes: state.executionVotes || {},
    accusationVoteHistory: state.accusationVoteHistory || [],
    voteEndsAt: state.voteEndsAt ?? null,
    voteStage: state.voteStage || null,
    accusedId: state.accusedId || null,
    voteMessageId: state.voteMessageId || null,
    guessEndsAt: state.guessEndsAt ?? null,
    resultAnnouncementToken: state.resultAnnouncementToken || null,
    resultAnnouncementLeaseUntil: state.resultAnnouncementLeaseUntil ?? null,
  } as GroupGameState;
}

function statusIsActive(status: GroupGameStatus) {
  return (
    status === "lobby" ||
    status === "playing" ||
    status === "voting" ||
    status === "spy_guess"
  );
}

async function getGame(chatId: string) {
  const db = await dbOrThrow();
  const rows = await db
    .select()
    .from(spyGroupGames)
    .where(eq(spyGroupGames.chatId, chatId))
    .limit(1);
  return rows[0] || null;
}

async function mutateGame(
  chatId: string,
  roundId: string | undefined,
  mutate: (state: GroupGameState) => GroupGameState
) {
  const db = await dbOrThrow();
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyGroupGames)
      .where(eq(spyGroupGames.chatId, chatId))
      .limit(1)
      .for("update");
    const row = rows[0];
    if (!row)
      throw new Error(
        "У цій групі ще немає активного лобі. Будь-який учасник може створити його командою /game."
      );
    const state = stateFromRow(row);
    if (roundId && state.roundId !== roundId)
      throw new Error(
        "Ця кнопка вже неактуальна. Скористайтеся повідомленням поточної партії."
      );
    const next = mutate(state);
    if (next === state) return { row, previous: state, state, changed: false };
    await tx
      .update(spyGroupGames)
      .set({
        status: next.status,
        hostId: next.hostId,
        state: next,
        roundStartedAt: next.roundStartedAt
          ? new Date(next.roundStartedAt)
          : null,
        roundEndsAt: next.roundEndsAt ? new Date(next.roundEndsAt) : null,
        version: row.version + 1,
      })
      .where(eq(spyGroupGames.chatId, chatId));
    return {
      row: {
        ...row,
        status: next.status,
        state: next,
        version: row.version + 1,
      },
      previous: state,
      state: next,
      changed: true,
    };
  });
}

async function createLobby(
  message: TelegramMessage,
  mode?: GroupMode,
  spyCount?: number
) {
  const chat = message.chat;
  const chatId = String(chat.id);
  const actor = message.from;
  if (!actor)
    throw new Error(
      "Telegram приховав автора повідомлення. Для створення гри скористайтеся особистим акаунтом учасника."
    );
  if (actor.is_bot) throw new Error("Створити гру може лише учасник чату.");
  await assertBotPermissions(chatId, chat.type);
  const identity = identityFromUser(actor);
  await getBalance(identity);
  const db = await dbOrThrow();
  const createdRoundId = randomUUID();
  const createdState = newGroupLobby(createdRoundId, actorFromUser(actor), {
    mode,
    spyCount,
  });
  const result = await db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyGroupGames)
      .where(eq(spyGroupGames.chatId, chatId))
      .limit(1)
      .for("update");
    const existing = rows[0];
    if (existing && statusIsActive(existing.status))
      return { row: existing, created: false };
    const values = {
      chatId,
      chatType: chat.type as "group" | "supergroup",
      chatTitle: (chat.title || "Груповий чат").slice(0, 160),
      hostId: String(actor.id),
      status: "lobby" as const,
      roundId: createdRoundId,
      lobbyMessageId: null,
      roundStartedAt: null,
      roundEndsAt: null,
      state: createdState,
      version: (existing?.version || 0) + 1,
    };
    if (existing) {
      await tx
        .update(spyGroupGames)
        .set(values)
        .where(eq(spyGroupGames.chatId, chatId));
      return { row: { ...existing, ...values }, created: true };
    }
    await tx.insert(spyGroupGames).values(values);
    return { row: values, created: true };
  });
  const row = result.row as typeof spyGroupGames.$inferSelect;
  const state = stateFromRow(row);
  if (!result.created && state.status !== "lobby") {
    await sendGroupText(
      chatId,
      "У цій групі вже триває партія. Завершіть її командою /stopgame перед створенням нового лобі."
    );
    return;
  }
  await refreshLobbyMessage(
    chatId,
    row.chatType,
    row.chatTitle,
    state,
    row.lobbyMessageId
  );
}

async function assertGroupAdmin(chatId: string, userId: number) {
  const member = await telegramCall<TelegramChatMember>("getChatMember", {
    chat_id: Number(chatId),
    user_id: userId,
  });
  if (!isTelegramAdmin(member))
    throw new Error("Ця дія доступна лише адміністратору групи.");
}

async function getBotId() {
  botIdPromise ||= telegramCall<TelegramUser>("getMe", {})
    .then(user => user.id)
    .catch(error => {
      botIdPromise = undefined;
      throw error;
    });
  return botIdPromise;
}

async function assertBotPermissions(chatId: string, chatType: string) {
  const botId = await getBotId();
  const member = await telegramCall<TelegramChatMember>("getChatMember", {
    chat_id: Number(chatId),
    user_id: botId,
  });
  if (!isTelegramAdmin(member))
    throw new Error("Додайте бота до групи як адміністратора.");
  if (chatType === "supergroup" && !member.can_delete_messages)
    throw new Error(
      "Боту потрібне право «Delete Messages», щоб прибирати повідомлення неучасників."
    );
  if (chatType === "supergroup" && !member.can_restrict_members)
    throw new Error(
      "Боту потрібне право «Restrict Members» для м’якого обмеження глядачів у супергрупі."
    );
}

function lobbyMarkup(state: GroupGameState): TelegramMarkup {
  const modeLabel = state.mode === "secret_word" ? "Таємне слово" : "Локації";
  return {
    inline_keyboard: [
      [
        { text: "Приєднатися", callback_data: `g:j:${state.roundId}` },
        { text: "Вийти", callback_data: `g:l:${state.roundId}` },
      ],
      [
        {
          text: `Шпигунів: ${state.spyCount}`,
          callback_data: `g:s:${state.roundId}`,
        },
        { text: `Режим: ${modeLabel}`, callback_data: `g:m:${state.roundId}` },
        {
          text: `${state.durationMinutes} хв`,
          callback_data: `g:d:${state.roundId}`,
        },
      ],
      [{ text: "🚀 Запустити гру", callback_data: `g:start:${state.roundId}` }],
    ],
  };
}

function lobbyText(chatTitle: string, state: GroupGameState) {
  const players =
    state.players
      .map(
        (player, index) =>
          `${index + 1}. ${displayName(player)}${player.id === state.hostId ? " · організатор" : ""}`
      )
      .join("\n") || "Поки що нікого.";
  const mode = state.mode === "secret_word" ? "Таємне слово" : "Шпигун";
  return `🕵️ НОВА ГРА — ШПИГУН\n\nНабираємо учасників!\n\nГравці: ${state.players.length}/${state.maxPlayers}\n\nУчасники:\n${players}\n\nПісля набору щонайменше 3 гравців будь-який учасник чату може розпочати гру кнопкою або командою /startgame.\n\nРежим: ${mode} · шпигунів: ${state.spyCount} · раунд: ${state.durationMinutes} хв\nГрупа: ${chatTitle}`;
}

async function refreshLobbyMessage(
  chatId: string,
  chatType: "group" | "supergroup",
  chatTitle: string,
  state: GroupGameState,
  messageId?: number | null
) {
  if (messageId) {
    try {
      await telegramCall("editMessageText", {
        chat_id: Number(chatId),
        message_id: messageId,
        text: lobbyText(chatTitle, state),
        reply_markup: lobbyMarkup(state),
      });
      return;
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.toLowerCase().includes("message is not modified")
      )
        return;
      /* The old lobby message may no longer be editable. Send a fresh one below. */
    }
  }
  const sent = await telegramCall<TelegramMessage>("sendMessage", {
    chat_id: Number(chatId),
    text: lobbyText(chatTitle, state),
    reply_markup: lobbyMarkup(state),
    disable_web_page_preview: true,
  });
  const db = await dbOrThrow();
  await db
    .update(spyGroupGames)
    .set({ lobbyMessageId: sent.message_id })
    .where(
      and(
        eq(spyGroupGames.chatId, chatId),
        eq(spyGroupGames.roundId, state.roundId)
      )
    );
  void chatType;
}

async function sendGroupText(
  chatId: string,
  text: string,
  replyMarkup?: TelegramMarkup
) {
  return telegramCall<TelegramMessage>("sendMessage", {
    chat_id: Number(chatId),
    text,
    ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
    disable_web_page_preview: true,
  });
}

function voteMarkup(state: GroupGameState): TelegramMarkup {
  const players = activeGroupPlayers(state);
  const rows: TelegramButton[][] = [];
  for (let index = 0; index < players.length; index += 2) {
    rows.push(
      players.slice(index, index + 2).map(player => ({
        text: displayName(player).slice(0, 60),
        callback_data: `g:v:${state.roundId}:${player.id}`,
      }))
    );
  }
  return { inline_keyboard: rows };
}

function executionVoteMarkup(state: GroupGameState): TelegramMarkup {
  return {
    inline_keyboard: [
      [
        { text: "👍 Стратити", callback_data: `g:y:${state.roundId}` },
        { text: "👎 Помилувати", callback_data: `g:n:${state.roundId}` },
      ],
    ],
  };
}

function turnMarkup(state: GroupGameState): TelegramMarkup {
  return {
    inline_keyboard: [
      [
        { text: "Поставити запитання", callback_data: `g:q:${state.roundId}` },
        {
          text: "Розпочати голосування",
          callback_data: `g:vote:${state.roundId}`,
        },
      ],
    ],
  };
}

async function announceTurn(chatId: string, state: GroupGameState) {
  if (!state.activeAskerId) return;
  if (!isActiveGroupPlayer(state, state.activeAskerId)) return;
  const active = state.players.find(
    player => player.id === state.activeAskerId
  );
  await sendGroupText(
    chatId,
    `Активний гравець: ${displayName(active)}. Можна поставити запитання або ініціювати голосування.`,
    turnMarkup(state)
  );
}

function voteMessageText(state: GroupGameState) {
  if (state.voteStage === "execution") {
    const votes = Object.values(state.executionVotes || {});
    const yes = votes.filter(Boolean).length;
    const no = votes.length - yes;
    const accused = state.players.find(player => player.id === state.accusedId);
    const activeCount = activeGroupPlayers(state).length;
    return `⚖️ Стратити підозрюваного ${displayName(accused)}?\n👍 За страту: ${yes}/${activeCount} · 👎 Проти: ${no}/${activeCount}. Для страти потрібна сувора більшість активних гравців.\n⏱ Голосування триває повні 60 секунд; більшість не закриває фазу достроково.`;
  }
  const votes = Object.keys(state.votes || {}).length;
  const activeCount = activeGroupPlayers(state).length;
  return `🗳 Голосування за підозрюваного.\nПроголосувало: ${votes}/${activeCount}. За себе голосувати не можна.\n⏱ Голосування триває повні 60 секунд; більшість не закриває фазу достроково.`;
}

function enqueueVoteMessageUpdate(chatId: string, task: () => Promise<void>) {
  const previous = voteMessageQueues.get(chatId) || Promise.resolve();
  const pending = previous.catch(() => undefined).then(task);
  voteMessageQueues.set(chatId, pending);
  return pending.finally(() => {
    if (voteMessageQueues.get(chatId) === pending)
      voteMessageQueues.delete(chatId);
  });
}

async function announceVoting(chatId: string, state: GroupGameState) {
  await enqueueVoteMessageUpdate(chatId, async () => {
    let row = await getGame(chatId);
    if (!row || row.roundId !== state.roundId) return;
    let latest = stateFromRow(row);
    if (latest.status !== "voting") return;
    if (!latest.voteMessageId) {
      const placeholder = await sendGroupText(
        chatId,
        "⏳ Голосування відкривається…"
      );
      const stored = await mutateGame(chatId, state.roundId, current =>
        current.status !== "voting" || current.voteMessageId
          ? current
          : { ...current, voteMessageId: placeholder.message_id }
      );
      row = await getGame(chatId);
      latest =
        row && row.roundId === state.roundId ? stateFromRow(row) : stored.state;
      if (
        latest.status !== "voting" ||
        latest.voteMessageId !== placeholder.message_id
      ) {
        try {
          await telegramCall("editMessageText", {
            chat_id: Number(chatId),
            message_id: placeholder.message_id,
            text: "Голосування вже оновлено в іншому повідомленні.",
            reply_markup: { inline_keyboard: [] },
          });
        } catch {
          /* Best effort cleanup of a concurrent placeholder. */
        }
        return;
      }
    }
    const keyboard =
      latest.voteStage === "execution"
        ? executionVoteMarkup(latest)
        : voteMarkup(latest);
    try {
      await telegramCall("editMessageText", {
        chat_id: Number(chatId),
        message_id: latest.voteMessageId,
        text: voteMessageText(latest),
        reply_markup: keyboard,
      });
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.toLowerCase().includes("message is not modified")
      )
        return;
      throw error;
    }
  });
}

async function closeVotingMessage(
  chatId: string,
  roundId: string,
  text: string
) {
  let closed = false;
  await enqueueVoteMessageUpdate(chatId, async () => {
    const row = await getGame(chatId);
    if (!row || row.roundId !== roundId) return;
    const state = stateFromRow(row);
    if (!state.voteMessageId) return;
    try {
      await telegramCall("editMessageText", {
        chat_id: Number(chatId),
        message_id: state.voteMessageId,
        text,
        reply_markup: { inline_keyboard: [] },
      });
      closed = true;
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.toLowerCase().includes("message is not modified")
      ) {
        closed = true;
        return;
      }
      try {
        await telegramCall("deleteMessage", {
          chat_id: Number(chatId),
          message_id: state.voteMessageId,
        });
      } catch (deleteError) {
        console.warn(
          "[Group game] Could not close vote message:",
          deleteError instanceof Error
            ? deleteError.message
            : String(deleteError)
        );
      }
    }
  });
  return closed;
}

async function retireOldVoteMessage(
  chatId: string,
  messageId: number,
  activeMessageId: number
) {
  if (messageId === activeMessageId) return;
  try {
    await telegramCall("editMessageText", {
      chat_id: Number(chatId),
      message_id: messageId,
      text: "Цей список застарів. Скористайтеся актуальним повідомленням голосування вище.",
      reply_markup: { inline_keyboard: [] },
    });
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.toLowerCase().includes("message is not modified")
    )
      return;
    try {
      await telegramCall("deleteMessage", {
        chat_id: Number(chatId),
        message_id: messageId,
      });
    } catch (deleteError) {
      console.warn(
        "[Group game] Could not retire an old vote message:",
        deleteError instanceof Error ? deleteError.message : String(deleteError)
      );
    }
  }
}

function shuffle<T>(values: T[]) {
  const result = [...values];
  for (let i = result.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [result[i], result[j]] = [result[j]!, result[i]!];
  }
  return result;
}

async function secretForRound(mode: GroupMode) {
  if (mode === "secret_word") {
    const words = [...SECRET_WORDS];
    return {
      secret: words[randomInt(words.length)]!,
      category: undefined,
      candidates: words,
    };
  }
  const db = await dbOrThrow();
  const active = await db
    .select({ name: spyLocations.name, category: spyLocations.category })
    .from(spyLocations)
    .where(eq(spyLocations.active, true));
  const catalog = active.length ? active : LOCATION_CATALOG;
  const item = catalog[randomInt(catalog.length)]!;
  return {
    secret: item.name,
    category: item.category,
    candidates: [...new Set(catalog.map(location => location.name))],
  };
}

async function checkPrivateMessages(players: GroupPlayer[]) {
  const failed: GroupPlayer[] = [];
  const outcomes = await Promise.all(
    players.map(async player => {
      try {
        await telegramCall("sendMessage", {
          chat_id: Number(player.id),
          text: "Зв’язок із ботом перевірено. Якщо гра почнеться, роль і секрет надійдуть сюди приватно.",
        });
        return null;
      } catch {
        return player;
      }
    })
  );
  failed.push(
    ...outcomes.filter((player): player is GroupPlayer => Boolean(player))
  );
  return failed;
}

async function startGame(message: TelegramMessage) {
  const chatId = String(message.chat.id);
  const actorId = message.from?.id;
  if (!actorId || message.from?.is_bot)
    throw new Error("Запустити гру можна лише з особистого акаунта.");
  await assertBotPermissions(chatId, message.chat.type);
  const row = await getGame(chatId);
  if (!row || row.status !== "lobby")
    throw new Error("Спочатку створіть нове лобі командою /game.");
  const state = stateFromRow(row);
  if (state.players.length < 3)
    throw new Error("Для запуску потрібно щонайменше 3 учасники.");
  const failedDms = await checkPrivateMessages(state.players);
  if (failedDms.length) {
    const names = failedDms.map(displayName).join(", ");
    const username = telegramBotUsername();
    const startLink = username
      ? `\nНехай вони відкриють https://t.me/${username} і натиснуть Start.`
      : "\nНехай вони відкриють бота й натиснуть Start.";
    await sendGroupText(
      chatId,
      `Не запускаю партію: не вдалося написати приватно ${names}.${startLink}`
    );
    return;
  }
  const secret = await secretForRound(state.mode);
  const spyIds = shuffle(state.players.map(player => player.id)).slice(
    0,
    state.spyCount
  );
  const started = await mutateGame(chatId, state.roundId, current =>
    startGroupRound(current, {
      spyIds,
      secret: secret.secret,
      category: secret.category,
      secretCandidates: secret.candidates,
    })
  );
  const roleResults = await Promise.all(
    started.state.players.map(async player => {
      const roleText =
        player.role === "spy"
          ? `🕵️‍♂️ ТИ — ШПИГУН\n\nНе видавай себе та спробуй вгадати ${started.state.mode === "secret_word" ? "секретне слово" : "локацію"}. Інші гравці не знають твою особу.`
          : `🕴️ ТИ — АГЕНТ\n\n${started.state.mode === "secret_word" ? "Секретне слово" : "Локація"}: ${started.state.secret}\n${started.state.category ? `Категорія: ${started.state.category}\n` : ""}Твоя задача — знайти шпигуна запитаннями.`;
      try {
        await telegramCall("sendMessage", {
          chat_id: Number(player.id),
          text: roleText,
        });
        return null;
      } catch {
        return player;
      }
    })
  );
  const roleFailures = roleResults.filter((player): player is GroupPlayer =>
    Boolean(player)
  );
  if (roleFailures.length) {
    const cancelled = await mutateGame(chatId, started.state.roundId, current =>
      cancelGroupRound(
        current,
        "Приватну роль не вдалося доставити всім гравцям."
      )
    );
    await restorePermissionsAndReport(chatId, cancelled.state.roundId);
    await sendGroupText(
      chatId,
      `Партію зупинено: не вдалося надіслати роль ${roleFailures.map(displayName).join(", ")}. Перевірте, чи вони не заблокували бота, і запустіть нову гру.`
    );
    return;
  }
  await sendGroupText(
    chatId,
    `🎮 Партія почалася! Ролі надіслано приватно. Час: ${started.state.durationMinutes} хв.`
  );
  await announceTurn(chatId, started.state);
}

async function callbackAnswer(callbackId: string, text: string, alert = false) {
  try {
    await telegramCall("answerCallbackQuery", {
      callback_query_id: callbackId,
      text: text.slice(0, 180),
      show_alert: alert,
    });
  } catch {
    /* The callback may have expired. */
  }
}

async function handleLegacyGuessCallback(callback: {
  id: string;
  from: TelegramUser;
  data: string;
  message?: TelegramMessage;
}) {
  const [, chatId, roundId] = callback.data.split(":");
  if (!chatId || !roundId) {
    await callbackAnswer(
      callback.id,
      "Ця кнопка останнього здогаду більше не діє.",
      true
    );
    return;
  }
  const row = await getGame(chatId);
  if (!row || row.roundId !== roundId) {
    await callbackAnswer(callback.id, "Ця партія вже завершилася.", true);
    return;
  }
  const state = stateFromRow(row);
  if (state.status !== "spy_guess") {
    await callbackAnswer(
      callback.id,
      "Останній здогад у груповій грі прибрано.",
      true
    );
    return;
  }
  const finished = await mutateGame(chatId, roundId, current => {
    if (current.status !== "spy_guess") return current;
    const spy = current.players.find(player => player.id === current.guesserId);
    const name = spy
      ? spy.username
        ? `@${spy.username}`
        : spy.firstName
      : "Шпигун";
    return finishGroupRound(
      current,
      "civilians",
      `Шпигуна ${name} страчено. Гра завершена негайно.`
    );
  });
  await callbackAnswer(
    callback.id,
    "Останній здогад скасовано: агенти перемогли.",
    true
  );
  await finishAndAnnounce(chatId, finished.state);
}

async function processVoteOutcome(
  chatId: string,
  previous: GroupGameState,
  next: GroupGameState,
  accusedId?: string
) {
  const suspectId =
    accusedId || next.accusedId || previous.accusedId || undefined;
  if (
    next.status === "voting" &&
    next.voteStage === "execution" &&
    (previous.status !== "voting" || previous.voteStage !== "execution")
  ) {
    await sendGroupText(
      chatId,
      `🔎 Більшість визначила підозрюваного: ${displayName(next.players.find(player => player.id === suspectId))}. Тепер голосуємо: стратити чи помилувати.`
    );
    await announceVoting(chatId, next);
    return;
  }
  if (next.status === "finished") {
    await finishAndAnnounce(chatId, next);
    return;
  }
  if (next.status === "playing" && previous.status === "voting") {
    const eliminatedId = previous.accusedId;
    const wasAgentExecuted =
      previous.voteStage === "execution" &&
      Boolean(eliminatedId && next.eliminatedPlayerIds.includes(eliminatedId));
    const message = wasAgentExecuted
      ? `🔨 ${displayName(next.players.find(player => player.id === eliminatedId))} страчений і вибув із гри. Раунд триває.`
      : previous.voteStage === "execution"
        ? "⚖️ Підозрюваного не страчено: більшість не підтримала вирок. Гра триває."
        : "🗳 Голосування не визначило більшості за підозрюваного. Гра триває.";
    await closeVotingMessage(chatId, next.roundId, message);
    await announceTurn(chatId, next);
  }
}

async function commitFinishedRound(chatId: string, state: GroupGameState) {
  if (state.status !== "finished" || !state.winner) return false;
  const db = await dbOrThrow();
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyGroupGames)
      .where(eq(spyGroupGames.chatId, chatId))
      .limit(1)
      .for("update");
    const row = rows[0];
    if (!row) return false;
    const current = stateFromRow(row);
    if (current.roundId !== state.roundId || current.status === "cancelled")
      return false;
    if (!current.winner) return false;
    const winner = current.winner;
    const prior = await tx
      .select({ roundId: spyGames.roundId })
      .from(spyGames)
      .where(eq(spyGames.roundId, state.roundId))
      .limit(1);
    if (prior.length) return false;
    const endedAt = Date.now();
    const durationSeconds = current.roundStartedAt
      ? Math.max(0, Math.floor((endedAt - current.roundStartedAt) / 1000))
      : 0;
    const spyIds = new Set(
      current.players
        .filter(player => player.role === "spy")
        .map(player => player.id)
    );
    const accusationHistory = current.accusationVoteHistory || [];
    const participants = current.players.map(player => ({
      id: player.id,
      name:
        [player.firstName, player.lastName].filter(Boolean).join(" ") ||
        player.firstName,
      role: player.role || ("civilian" as const),
      votedForSpy:
        player.role === "civilian" &&
        (accusationHistory.some(
          vote => vote.voterId === player.id && spyIds.has(vote.targetId)
        ) ||
          (current.votes[player.id] !== undefined &&
            spyIds.has(current.votes[player.id]))),
    }));
    const roomCode = `G${state.roundId.replace(/-/g, "").slice(0, 7).toUpperCase()}`;
    await tx
      .update(spyGroupGames)
      .set({
        status: "finished",
        state: current,
        roundEndsAt: new Date(endedAt),
        version: row.version + 1,
      })
      .where(eq(spyGroupGames.chatId, chatId));
    await tx.insert(spyGames).values({
      roundId: state.roundId,
      roomCode,
      roomName: `Telegram · ${(row.chatTitle || "група").slice(0, 88)}`,
      mode: current.mode,
      winner,
      location: (current.secret || "Невідомий секрет").slice(0, 140),
      participants,
      durationSeconds,
    });
    const configRows = await tx.select().from(spyGameConfig);
    const config = { ...DEFAULT_XP };
    for (const entry of configRows) {
      if (entry.key === "xpParticipation")
        config.participation = Number(entry.value) || config.participation;
      if (entry.key === "xpWin") config.win = Number(entry.value) || config.win;
    }
    await updateProfilesForResult(tx, {
      roundId: state.roundId,
      winner,
      players: current.players.map(player => ({
        id: player.id,
        firstName: player.firstName,
        lastName: player.lastName,
        role: player.role || "civilian",
      })),
      durationSeconds,
      xpParticipation: config.participation,
      xpWin: config.win,
      winnerRewardOverride: 10,
    });
    return true;
  });
}

async function finishAndAnnounce(chatId: string, state: GroupGameState) {
  await commitFinishedRound(chatId, state);
  const token = randomUUID();
  let claimed = false;
  const claim = await mutateGame(chatId, state.roundId, current => {
    const result = claimGroupResultAnnouncement(
      current,
      token,
      Date.now(),
      120_000
    );
    claimed = result.claimed;
    return result.state;
  });
  if (!claimed) return;
  state = claim.state;
  await restorePermissionsAndReport(chatId, state.roundId);
  const winner = formatGroupWinnerAnnouncement(state);
  const roles = state.players
    .map(
      player =>
        `• ${displayName(player)} — ${player.role === "spy" ? "🕵️‍♂️ шпигун" : "🕴️ агент"}`
    )
    .join("\n");
  const secretLabel =
    state.mode === "secret_word" ? "Секретне слово" : "Локація";
  const resultText = `🏁 ${winner}\n${secretLabel}: ${state.secret || "невідомо"}${state.category ? ` · ${state.category}` : ""}\n\n${state.resultText || ""}\n\nРолі:\n${roles}\n\nКожен гравець команди-переможця отримав 10 🪙. Статистика оновлена.`;
  const edited = state.voteMessageId
    ? await closeVotingMessage(chatId, state.roundId, resultText)
    : false;
  if (!edited) await sendGroupText(chatId, resultText);
  await mutateGame(chatId, state.roundId, current =>
    completeGroupResultAnnouncement(current, token)
  );
}

async function stopGame(message: TelegramMessage) {
  const chatId = String(message.chat.id);
  if (!message.from)
    throw new Error(
      "Команда має надійти від особистого акаунта адміністратора."
    );
  await assertGroupAdmin(chatId, message.from.id);
  const row = await getGame(chatId);
  if (!row || !statusIsActive(row.status))
    throw new Error("У цій групі немає активної партії.");
  const stopped = await mutateGame(chatId, stateFromRow(row).roundId, state =>
    cancelGroupRound(state, "Партію завершив адміністратор.")
  );
  await closeVotingMessage(
    chatId,
    stopped.state.roundId,
    "⛔ Голосування зупинено: партію скасовано адміністратором."
  );
  await restorePermissionsAndReport(chatId, stopped.state.roundId);
  await sendGroupText(
    chatId,
    "⛔ Партію зупинено адміністратором. Тимчасові обмеження учасників відновлюються."
  );
}

async function restorePermissionsAndReport(chatId: string, roundId: string) {
  const result = await restoreGroupPermissionSnapshots(chatId, roundId);
  if (result.conflicted > 0) {
    await sendGroupText(
      chatId,
      `⚠️ Не вдалося безпечно відновити права ${result.conflicted} учасника(ів): їхній стан змінився поза ботом. Адміністратору потрібно перевірити обмеження вручну; зовнішні зміни не перезаписано.`
    );
  }
  return result;
}

async function handleLobbyJoin(message: TelegramMessage, join: boolean) {
  const chatId = String(message.chat.id);
  if (!message.from)
    throw new Error("Вступити можна лише з особистого акаунта.");
  const identity = identityFromUser(message.from);
  await getBalance(identity);
  const row = await getGame(chatId);
  if (!row || row.status !== "lobby")
    throw new Error(
      "Зараз немає відкритого лобі. Будь-який учасник чату може створити його командою /game."
    );
  const updated = await mutateGame(chatId, stateFromRow(row).roundId, state =>
    join
      ? joinGroupLobby(state, actorFromUser(message.from!))
      : leaveGroupLobby(state, String(message.from!.id))
  );
  await refreshLobbyMessage(
    chatId,
    message.chat.type as "group" | "supergroup",
    row.chatTitle,
    updated.state,
    row.lobbyMessageId
  );
}

async function renderPlayers(chatId: string) {
  const row = await getGame(chatId);
  if (!row)
    throw new Error("У цій групі ще немає гри. Створіть лобі командою /game.");
  const state = stateFromRow(row);
  const players =
    state.players
      .map(
        (player, index) =>
          `${index + 1}. ${displayName(player)}${isActiveGroupPlayer(state, player.id) ? "" : " · вибув"}`
      )
      .join("\n") || "Поки що немає учасників.";
  const activeCount = activeGroupPlayers(state).length;
  await sendGroupText(
    chatId,
    `👥 Активні: ${activeCount} · гравців у партії: ${state.players.length}/${state.maxPlayers}\n${players}`
  );
}

async function showStats(message: TelegramMessage) {
  if (!message.from)
    throw new Error(
      "Статистика доступна після запуску бота у приватному чаті."
    );
  const identity = identityFromUser(message.from);
  const wallet = await getBalance(identity);
  const db = await dbOrThrow();
  const profiles = await db
    .select()
    .from(spyProfiles)
    .where(eq(spyProfiles.telegramId, identity.id))
    .limit(1);
  const profile = profiles[0];
  if (!profile)
    throw new Error(
      "Досьє ще не створено. Запустіть /start у приватному чаті."
    );
  await sendGroupText(
    String(message.chat.id),
    `📊 Досьє ${displayName(actorFromUser(message.from))}\nПартій: ${profile.gamesPlayed} · перемог: ${profile.wins} · рейтинг: ${profile.rating}\nБаланс: ${wallet.balance} монет · рівень: ${Math.floor(profile.xp / 100) + 1}`
  );
}

export async function handleGroupCommand(
  message: TelegramMessage,
  command: string,
  args: string[] = []
) {
  if (message.chat.type !== "group" && message.chat.type !== "supergroup")
    return false;
  const chatId = String(message.chat.id);
  try {
    if (command === "game") {
      const mode = args.some(arg => /^(word|secret_word|слово)$/i.test(arg))
        ? "secret_word"
        : "spyfall";
      const spyCountArg = args.find(arg => /^[1-3]$/.test(arg));
      await createLobby(message, mode, spyCountArg ? Number(spyCountArg) : 1);
    } else if (command === "join") await handleLobbyJoin(message, true);
    else if (command === "leave") await handleLobbyJoin(message, false);
    else if (command === "players") await renderPlayers(chatId);
    else if (command === "startgame") await startGame(message);
    else if (command === "stopgame") await stopGame(message);
    else if (command === "rules")
      await sendGroupText(
        chatId,
        "Шпигун не знає секрет. Спершу визначається підозрюваний, потім те саме повідомлення перемикається на 👍 стратити / 👎 помилувати; кожна фаза триває повні 60 секунд. Вибулі не голосують і не діють. Страта шпигуна одразу завершує гру перемогою агентів; страчений агент вибуває, гра триває до 1 активного агента й 1 шпигуна — тоді перемагає шпигун. Переможці отримують 10 🪙 кожен. Категорія й секрет відкриваються лише у фіналі."
      );
    else if (command === "stats") await showStats(message);
    else return false;
  } catch (error) {
    const text =
      error instanceof Error ? error.message : "Не вдалося виконати команду.";
    await sendGroupText(chatId, text);
  }
  return true;
}

export async function handleGroupMessage(message: TelegramMessage) {
  if (
    (message.chat.type !== "group" && message.chat.type !== "supergroup") ||
    !message.from ||
    !message.text
  )
    return false;
  const chatId = String(message.chat.id);
  const text = message.text.trim();
  const row = await getGame(chatId);
  if (
    !row ||
    !ACTIVE_STATUSES.includes(row.status as (typeof ACTIVE_STATUSES)[number])
  )
    return false;
  const state = stateFromRow(row);
  const userId = String(message.from.id);
  if (!isActiveGroupPlayer(state, userId)) {
    if (message.from.is_bot) return true;
    try {
      const member = await telegramCall<TelegramChatMember>("getChatMember", {
        chat_id: Number(chatId),
        user_id: message.from.id,
      });
      if (isTelegramAdmin(member)) return false;
    } catch {
      return false;
    }
    const result = await protectSpectatorMessage({
      chatId,
      roundId: state.roundId,
      chatType: message.chat.type,
      userId,
      messageId: message.message_id,
      roundEndsAt: state.roundEndsAt,
    });
    if (!state.spectatorNoticeSent) {
      const deletionNotice = result.deleted
        ? "Повідомлення видалено."
        : "Повідомлення не вдалося видалити; перевірте право Delete Messages.";
      const restrictionNotice = result.restricted
        ? "Тимчасове обмеження застосовано до завершення гри."
        : result.reason === "already_read_only"
          ? "Автор уже не має права надсилати повідомлення."
          : "Тимчасове обмеження не застосовано; перевірте право Restrict Members.";
      const notice =
        message.chat.type === "supergroup"
          ? `Під час партії пишуть лише учасники. ${deletionNotice} ${restrictionNotice}`
          : `Під час партії пишуть лише учасники. ${deletionNotice} У звичайній групі Telegram не дозволяє тимчасово обмежити автора; для цього потрібна супергрупа.`;
      await sendGroupText(chatId, notice);
      await mutateGame(
        chatId,
        state.roundId,
        current => ({ ...current, spectatorNoticeSent: true }) as GroupGameState
      );
    }
    if (!result.deleted && !result.restricted)
      console.warn(
        "[Group moderation] Spectator message could not be fully moderated:",
        result.reason
      );
    return true;
  }
  if (/^зп$/i.test(text)) return false;
  if (!text || text.startsWith("/")) return false;
  if (state.phase === "await_question" && state.activeAskerId === userId) {
    try {
      const updated = await mutateGame(chatId, state.roundId, current =>
        recordGroupQuestion(current, userId, text)
      );
      const target = updated.state.players.find(
        player => player.id === updated.state.targetId
      );
      await sendGroupText(
        chatId,
        `❓ Запитання від ${displayName(message.from ? actorFromUser(message.from) : undefined)} до ${displayName(target)} зафіксовано. ${displayName(target)}, надішліть відповідь наступним повідомленням.`
      );
    } catch (error) {
      await sendGroupText(
        chatId,
        error instanceof Error
          ? error.message
          : "Не вдалося зафіксувати запитання."
      );
    }
    return true;
  }
  if (state.phase === "await_answer" && state.targetId === userId) {
    try {
      const updated = await mutateGame(chatId, state.roundId, current =>
        recordGroupAnswer(current, userId, text)
      );
      await sendGroupText(
        chatId,
        `✅ Відповідь зафіксована. Тепер запитання ставить ${displayName(updated.state.players.find(player => player.id === updated.state.activeAskerId))}.`
      );
      await announceTurn(chatId, updated.state);
    } catch (error) {
      await sendGroupText(
        chatId,
        error instanceof Error
          ? error.message
          : "Не вдалося зафіксувати відповідь."
      );
    }
    return true;
  }
  return false;
}

export async function handleGroupCallback(callback: {
  id: string;
  from: TelegramUser;
  data?: string;
  message?: TelegramMessage;
}) {
  const data = callback.data || "";
  if (
    !data.startsWith("g:") &&
    !data.startsWith("gs:") &&
    !data.startsWith("gp:")
  )
    return false;
  try {
    if (data.startsWith("gs:") || data.startsWith("gp:")) {
      await handleLegacyGuessCallback(
        callback as {
          id: string;
          from: TelegramUser;
          data: string;
          message?: TelegramMessage;
        }
      );
      return true;
    }
    const message = callback.message;
    if (
      !message ||
      (message.chat.type !== "group" && message.chat.type !== "supergroup")
    )
      throw new Error("Ця кнопка працює лише в групі.");
    const chatId = String(message.chat.id);
    const parsed = parseGroupCallback(data);
    if (!parsed) throw new Error("Кнопка гри некоректна.");
    const { action, parts } = parsed;
    const roundId = parts[0];
    if (!action || !roundId) throw new Error("Кнопка гри некоректна.");
    const row = await getGame(chatId);
    if (!row) throw new Error("Лобі вже закрито.");
    const current = stateFromRow(row);
    if (current.roundId !== roundId)
      throw new Error("Кнопка від старої партії вже неактуальна.");
    const userId = String(callback.from.id);
    const sourceMessageId = message.message_id;
    if (
      (action === "v" || action === "y" || action === "n") &&
      current.voteMessageId &&
      sourceMessageId !== current.voteMessageId
    ) {
      await retireOldVoteMessage(
        chatId,
        sourceMessageId,
        current.voteMessageId
      );
      await callbackAnswer(
        callback.id,
        "Це старий список. Голосуйте в актуальному повідомленні.",
        true
      );
      return true;
    }
    if (action === "v" || action === "y" || action === "n") {
      const expectedStage = action === "v" ? "accusation" : "execution";
      if (
        current.status !== "voting" ||
        (current.voteStage || "accusation") !== expectedStage
      ) {
        await callbackAnswer(
          callback.id,
          "Ця фаза голосування вже завершилася. Дочекайтеся результату.",
          true
        );
        return true;
      }
      if (current.voteEndsAt !== null && Date.now() >= current.voteEndsAt) {
        await callbackAnswer(
          callback.id,
          "Час голосування вийшов. Бот завершує підрахунок.",
          true
        );
        return true;
      }
    }
    if (action === "start") {
      await startGame({ ...message, from: callback.from, text: "/startgame" });
      await callbackAnswer(callback.id, "Запит на запуск оброблено.");
      return true;
    }
    if (action === "j" || action === "l") {
      const identity = identityFromUser(callback.from);
      await getBalance(identity);
      const next = await mutateGame(chatId, roundId, state =>
        action === "j"
          ? joinGroupLobby(state, actorFromUser(callback.from))
          : leaveGroupLobby(state, userId)
      );
      const updatedRow = await getGame(chatId);
      await refreshLobbyMessage(
        chatId,
        message.chat.type,
        updatedRow?.chatTitle || message.chat.title || "Група",
        next.state,
        updatedRow?.lobbyMessageId
      );
      await callbackAnswer(
        callback.id,
        action === "j" ? "Ви приєдналися до лобі." : "Ви вийшли з лобі."
      );
      return true;
    }
    if (action === "s" || action === "m" || action === "d") {
      if (userId !== current.hostId)
        await assertGroupAdmin(chatId, callback.from.id);
      const next = await mutateGame(chatId, roundId, state => {
        if (action === "s") {
          const maxSpies = Math.min(3, Math.max(1, state.players.length - 1));
          return setGroupOptions(state, {
            spyCount: state.spyCount >= maxSpies ? 1 : state.spyCount + 1,
          });
        }
        if (action === "m")
          return setGroupOptions(state, {
            mode: state.mode === "spyfall" ? "secret_word" : "spyfall",
          });
        const values = [5, 7, 10, 15];
        const nextDuration =
          values[(values.indexOf(state.durationMinutes) + 1) % values.length]!;
        return setGroupOptions(state, { durationMinutes: nextDuration });
      });
      const updatedRow = await getGame(chatId);
      await refreshLobbyMessage(
        chatId,
        message.chat.type,
        updatedRow?.chatTitle || message.chat.title || "Група",
        next.state,
        updatedRow?.lobbyMessageId
      );
      await callbackAnswer(callback.id, "Налаштування оновлено.");
      return true;
    }
    if (action === "q") {
      if (!isActiveGroupPlayer(current, userId))
        throw new Error("Запитання можуть ставити лише активні учасники.");
      if (
        current.status !== "playing" ||
        current.phase !== "choose_target" ||
        current.activeAskerId !== userId
      )
        throw new Error("Зараз не ваша черга ставити запитання.");
      const buttons: TelegramButton[][] = [];
      const available = activeGroupPlayers(current).filter(
        player => player.id !== userId
      );
      for (let index = 0; index < available.length; index += 2)
        buttons.push(
          available.slice(index, index + 2).map(player => ({
            text: displayName(player).slice(0, 60),
            callback_data: `g:t:${roundId}:${player.id}`,
          }))
        );
      await sendGroupText(
        chatId,
        `${displayName(current.players.find(player => player.id === userId))}, оберіть, кому поставите запитання.`,
        { inline_keyboard: buttons }
      );
      await callbackAnswer(callback.id, "Оберіть учасника.");
      return true;
    }
    if (action === "t") {
      const targetId = parts[1];
      if (!targetId) throw new Error("Оберіть адресата запитання.");
      const next = await mutateGame(chatId, roundId, state =>
        chooseQuestionTarget(state, userId, targetId)
      );
      const target = next.state.players.find(player => player.id === targetId);
      await sendGroupText(
        chatId,
        `${displayName(next.state.players.find(player => player.id === userId))}, напишіть запитання до ${displayName(target)} одним повідомленням.`
      );
      await callbackAnswer(callback.id, "Тепер надішліть запитання в чат.");
      return true;
    }
    if (action === "vote") {
      const next = await mutateGame(chatId, roundId, state =>
        beginGroupVote(state, userId)
      );
      await announceVoting(chatId, next.state);
      await callbackAnswer(callback.id, "Голосування розпочалося.");
      return true;
    }
    if (action === "v") {
      const targetId = parts[1];
      if (!targetId) throw new Error("Оберіть підозрюваного.");
      let voteResolution: ReturnType<typeof castGroupVote> | undefined;
      const next = await mutateGame(chatId, roundId, state => {
        voteResolution = castGroupVote(state, userId, targetId);
        return voteResolution.state.voteMessageId
          ? voteResolution.state
          : { ...voteResolution.state, voteMessageId: sourceMessageId };
      });
      if (!voteResolution) throw new Error("Не вдалося зафіксувати голос.");
      const voter = next.state.players.find(player => player.id === userId);
      const target = next.state.players.find(player => player.id === targetId);
      await callbackAnswer(
        callback.id,
        next.state.voteStage === "execution"
          ? "Підозрюваного визначено; почалося голосування за вирок."
          : voteResolution.resolved
            ? "Голосування завершено."
            : "Голос прийнято."
      );
      await sendGroupText(
        chatId,
        `${displayName(voter)} проголосував за ${displayName(target)}.`
      );
      if (voteResolution.resolved)
        await processVoteOutcome(
          chatId,
          next.previous,
          next.state,
          voteResolution.accusedId
        );
      else await announceVoting(chatId, next.state);
      return true;
    }
    if (action === "y" || action === "n") {
      const approveExecution = action === "y";
      let voteResolution: ReturnType<typeof castExecutionVote> | undefined;
      const next = await mutateGame(chatId, roundId, state => {
        voteResolution = castExecutionVote(state, userId, approveExecution);
        return voteResolution.state.voteMessageId
          ? voteResolution.state
          : { ...voteResolution.state, voteMessageId: sourceMessageId };
      });
      if (!voteResolution)
        throw new Error("Не вдалося зафіксувати голос за вирок.");
      const voter = next.state.players.find(player => player.id === userId);
      const suspect = next.state.players.find(
        player => player.id === next.state.accusedId
      );
      await callbackAnswer(
        callback.id,
        voteResolution.resolved
          ? "Голосування за вирок завершено."
          : "Голос за вирок прийнято."
      );
      await sendGroupText(
        chatId,
        `${displayName(voter)} проголосував ${approveExecution ? `👍 за страту ${displayName(suspect)}` : `👎 проти страти ${displayName(suspect)}`}.`
      );
      if (voteResolution.resolved)
        await processVoteOutcome(
          chatId,
          next.previous,
          next.state,
          voteResolution.accusedId
        );
      else await announceVoting(chatId, next.state);
      return true;
    }
    await callbackAnswer(callback.id, "Невідома дія.");
    return true;
  } catch (error) {
    const text =
      error instanceof Error ? error.message : "Не вдалося виконати дію.";
    const callbackText = /Зараз не триває голосування|Час голосування/.test(
      text
    )
      ? "Ця фаза голосування вже завершилася або час вийшов. Дочекайтеся результату."
      : text;
    await callbackAnswer(callback.id, callbackText, true);
    return true;
  }
}

export async function tickGroupGames() {
  if (groupWorkerRunning) return;
  groupWorkerRunning = true;
  try {
    const db = await dbOrThrow();
    const activeRows = await db
      .select()
      .from(spyGroupGames)
      .where(inArray(spyGroupGames.status, ["playing", "voting", "spy_guess"]))
      .orderBy(asc(spyGroupGames.updatedAt))
      .limit(200);
    let settledRows: typeof activeRows = [];
    if (Date.now() - lastSettledSweepAt >= 15_000) {
      settledRows = await db
        .select()
        .from(spyGroupGames)
        .where(inArray(spyGroupGames.status, ["finished", "cancelled"]))
        .orderBy(asc(spyGroupGames.updatedAt))
        .limit(200);
      lastSettledSweepAt = Date.now();
    }
    const rows = [...activeRows, ...settledRows];
    for (const row of rows) {
      const chatId = row.chatId;
      const snapshot = stateFromRow(row);
      try {
        const transition = await mutateGame(
          chatId,
          snapshot.roundId,
          current => {
            const now = Date.now();
            return tickGroupRound(current, now).state;
          }
        );
        const previous = transition.previous;
        const state = transition.state;
        if (state.status === "voting" && previous.status !== "voting") {
          await announceVoting(chatId, state);
        } else if (
          state.status === "voting" &&
          previous.status === "voting" &&
          previous.voteStage !== state.voteStage
        ) {
          await processVoteOutcome(
            chatId,
            previous,
            state,
            state.accusedId || undefined
          );
        } else if (state.status === "playing" && previous.status === "voting") {
          await processVoteOutcome(chatId, previous, state);
        } else if (state.status === "finished" && !state.resultAnnounced) {
          await finishAndAnnounce(chatId, state);
        }
        if (state.status === "finished" || state.status === "cancelled") {
          await restorePermissionsAndReport(chatId, state.roundId);
        }
        await db
          .update(spyGroupGames)
          .set({ updatedAt: new Date() })
          .where(
            and(
              eq(spyGroupGames.chatId, chatId),
              eq(spyGroupGames.roundId, state.roundId)
            )
          );
      } catch (error) {
        console.error(
          "[Group game worker row]",
          error instanceof Error ? error.message : String(error)
        );
      }
    }
  } catch (error) {
    console.error(
      "[Group game worker]",
      error instanceof Error ? error.message : String(error)
    );
  } finally {
    groupWorkerRunning = false;
  }
}

export function startGroupGameWorker() {
  if (groupWorker) return;
  groupWorker = setInterval(() => {
    void tickGroupGames();
  }, 5_000);
  groupWorker.unref?.();
  void tickGroupGames();
}
