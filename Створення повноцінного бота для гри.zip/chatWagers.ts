import { randomInt, randomUUID } from "node:crypto";
import { and, eq, inArray, lt, sql } from "drizzle-orm";
import { getDb } from "../db";
import {
  spyChatWagerBank,
  spyChatWagerBankLedger,
  spyChatWagers,
  spyEconomyLedger,
  spyProfiles,
  spyWallets,
} from "../../drizzle/schema";
import { telegramCall } from "./telegramApi";
import { syncEconomyUserTx } from "./economy";

export type WagerGame = "coin" | "dice";
export const WAGER_TIMEOUT_MESSAGE = "⏳ Час виклику вийшов, гру скасовано";
export const MAX_ACTIVE_CHALLENGES_PER_CREATOR = 5;
export function wagerChallengeLimitReached(activeCount: number) {
  return activeCount >= MAX_ACTIVE_CHALLENGES_PER_CREATOR;
}

export function parseWager(
  text: string
): { game: WagerGame; stake: number; username?: string } | null {
  const match =
    /^зіграти\s+в\s+(монетку|кубики)\s+(\d+)(?:\s+@([a-z0-9_]{5,32}))?$/iu.exec(
      text.trim()
    );
  if (!match) return null;
  const stake = Number(match[2]);
  if (!Number.isSafeInteger(stake) || stake < 10 || stake > 100) return null;
  return {
    game: match[1]!.toLocaleLowerCase("uk") === "монетку" ? "coin" : "dice",
    stake,
    ...(match[3] ? { username: match[3].toLowerCase() } : {}),
  };
}

export function calculateWager(stake: number) {
  if (!Number.isSafeInteger(stake) || stake < 10 || stake > 100) {
    throw new RangeError("Stake must be an integer from 10 to 100 coins");
  }
  const pot = stake * 2;
  const fee = Math.round(pot * 0.05);
  return { pot, fee, payout: pot - fee };
}

export function tiePolicy(challenger: number, opponent: number) {
  return challenger === opponent
    ? ("reroll" as const)
    : challenger > opponent
      ? ("challenger" as const)
      : ("opponent" as const);
}

export const MAX_DICE_SEND_FAILURES = 3;
export function diceSendFailurePolicy(previousFailures: number) {
  const failures = Math.max(0, Math.floor(Number(previousFailures) || 0)) + 1;
  return { failureCount: failures, shouldRefund: failures >= MAX_DICE_SEND_FAILURES };
}

export function mayAccept(input: {
  actorId: string;
  challengerId: string;
  opponentId: string | null;
  status: string;
  now: number;
  expiresAt: number;
}) {
  return (
    input.status === "pending" &&
    input.now < input.expiresAt &&
    input.actorId !== input.challengerId &&
    (!input.opponentId || input.actorId === input.opponentId)
  );
}

export function mayDecline(input: {
  actorId: string;
  challengerId: string;
  opponentId: string | null;
  status: string;
  now: number;
  expiresAt: number;
}) {
  return (
    input.status === "pending" &&
    input.now < input.expiresAt &&
    input.actorId !== input.challengerId &&
    (!input.opponentId || input.actorId === input.opponentId)
  );
}

const recentChallenges = new Map<string, number>();

async function send(chatId: number, text: string, replyMarkup?: unknown) {
  await telegramCall("sendMessage", {
    chat_id: chatId,
    text,
    ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
    disable_web_page_preview: true,
  });
}

async function answerCallback(
  callbackId: string | undefined,
  text?: string,
  showAlert = false
) {
  if (!callbackId) return;
  try {
    await telegramCall("answerCallbackQuery", {
      callback_query_id: callbackId,
      ...(text ? { text: text.slice(0, 180) } : {}),
      ...(showAlert ? { show_alert: true } : {}),
    });
  } catch {
    // The Telegram callback may have expired while the server was processing.
  }
}

async function removeButtons(chatId: number, messageId: number) {
  try {
    await telegramCall("editMessageReplyMarkup", {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: { inline_keyboard: [] },
    });
  } catch {
    // A missing or already-edited challenge message must not block settlement.
  }
}

async function eligibleUser(id: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  const profiles = await db
    .select()
    .from(spyProfiles)
    .where(eq(spyProfiles.telegramId, id))
    .limit(1);
  const wallets = await db
    .select()
    .from(spyWallets)
    .where(eq(spyWallets.telegramId, id))
    .limit(1);
  return profiles[0] && !profiles[0].blocked && wallets[0]
    ? { profile: profiles[0], wallet: wallets[0] }
    : null;
}

async function userLabel(id: string) {
  const db = await getDb();
  if (!db) return "гравець";
  const rows = await db
    .select({ firstName: spyProfiles.firstName, lastName: spyProfiles.lastName, username: spyProfiles.username })
    .from(spyProfiles)
    .where(eq(spyProfiles.telegramId, id))
    .limit(1);
  const profile = rows[0];
  if (!profile) return "гравець";
  return (
    [profile.firstName, profile.lastName].filter(Boolean).join(" ").trim() ||
    (profile.username ? `@${profile.username.replace(/^@/, "")}` : "гравець")
  );
}

async function resolveUsername(username: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  const normalized = username.replace(/^@/, "").toLowerCase();
  return db
    .select()
    .from(spyProfiles)
    .where(sql`LOWER(REPLACE(${spyProfiles.username}, '@', '')) = ${normalized}`)
    .limit(2);
}

export async function createWager(
  message: any,
  parsed: NonNullable<ReturnType<typeof parseWager>>
) {
  if (!message.from || !message.chat) return;
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  const sourceMessageId = Number(message.message_id);
  if (!Number.isSafeInteger(sourceMessageId) || sourceMessageId < 1) return;
  const previous = await db
    .select({ id: spyChatWagers.id })
    .from(spyChatWagers)
    .where(
      and(
        eq(spyChatWagers.chatId, String(message.chat.id)),
        eq(spyChatWagers.sourceMessageId, sourceMessageId)
      )
    )
    .limit(1);
  if (previous.length) return;

  const challengerId = String(message.from.id);
  let opponentId: string | null = null;
  if (parsed.username) {
    const matches = await resolveUsername(parsed.username);
    if (matches.length !== 1) {
      await send(
        message.chat.id,
        matches.length
          ? "Цей @username неоднозначний у профілях. Відповідайте на повідомлення потрібного гравця."
          : "Гравця з таким @username не знайдено у профілях Mini App."
      );
      return;
    }
    opponentId = matches[0]!.telegramId;
  } else if (message.reply_to_message?.from?.id !== undefined) {
    opponentId = String(message.reply_to_message.from.id);
  }

  if (opponentId === challengerId) {
    await send(message.chat.id, "Не можна викликати самого себе.");
    return;
  }
  const challenger = await eligibleUser(challengerId);
  if (!challenger) {
    await send(
      message.chat.id,
      "Для гри на монети потрібні активний профіль і гаманець Mini App. Спершу відкрийте Mini App."
    );
    return;
  }
  if (challenger.wallet.balance < parsed.stake) {
    await send(
      message.chat.id,
      `Для ставки ${parsed.stake} 🪙 потрібно мати щонайменше стільки монет. Баланс: ${challenger.wallet.balance} 🪙.`
    );
    return;
  }
  if (opponentId && !(await eligibleUser(opponentId))) {
    await send(
      message.chat.id,
      "Суперник має спершу створити активний профіль і гаманець у Mini App."
    );
    return;
  }

  const rateKey = `${message.chat.id}:${challengerId}`;
  const now = Date.now();
  if ((recentChallenges.get(rateKey) ?? 0) + 2_000 > now) {
    await send(message.chat.id, "Зачекайте кілька секунд перед наступним викликом.");
    return;
  }
  recentChallenges.set(rateKey, now);
  if (recentChallenges.size > 1_000) {
    for (const [key, lastAt] of recentChallenges) {
      if (lastAt < now - 60_000) recentChallenges.delete(key);
    }
  }

  const active = await db
    .select({ id: spyChatWagers.id })
    .from(spyChatWagers)
    .where(
      and(
        eq(spyChatWagers.challengerId, challengerId),
        inArray(spyChatWagers.status, ["pending", "rolling"])
      )
    )
    .limit(MAX_ACTIVE_CHALLENGES_PER_CREATOR);
  if (wagerChallengeLimitReached(active.length)) {
    await send(message.chat.id, "У вас уже є п’ять активних викликів. Дочекайтеся їх завершення.");
    return;
  }

  const id = randomUUID();
  const { pot, fee, payout } = calculateWager(parsed.stake);
  const gameLabel = parsed.game === "coin" ? "монетку" : "кубики";
  const icon = parsed.game === "coin" ? "🪙" : "🎲";
  const challengerName =
    message.from.first_name || challenger.profile.firstName || "Гравець";
  const targetLine = opponentId
    ? `Виклик адресований ${parsed.username ? `@${parsed.username}` : "учаснику з повідомлення, на яке відповіли"}.`
    : "Відкритий виклик: прийняти може будь-який інший гравець цієї групи.";
  const keyboard = {
    inline_keyboard: [
      [
        { text: "Прийняти виклик", callback_data: `cw:accept:${id}` },
        { text: "Відхилити", callback_data: `cw:decline:${id}` },
      ],
    ],
  };
  const sent = await telegramCall<{ message_id: number }>("sendMessage", {
    chat_id: message.chat.id,
    text: `${icon} ${challengerName} запрошує зіграти в ${gameLabel}!\n\nСтавка кожного: ${parsed.stake} 🪙\nЗагальний банк: ${pot} 🪙\nКомісія: ${fee} 🪙 (5%, округлено до цілої монети)\nМожливий виграш: ${payout} 🪙\n\n${targetLine}\nВиклик діє 60 секунд.`,
    reply_markup: keyboard,
    disable_web_page_preview: true,
  });
  try {
    await db.transaction(async (tx: any) => {
      const walletRows = await tx.select().from(spyWallets).where(eq(spyWallets.telegramId, challengerId)).limit(1).for("update");
      const wallet = walletRows[0];
      if (!wallet || Number(wallet.balance) < parsed.stake) throw new Error("На балансі вже недостатньо монет для резервування ставки.");
      const currentActive = await tx.select({ id: spyChatWagers.id }).from(spyChatWagers).where(and(
        eq(spyChatWagers.challengerId, challengerId),
        inArray(spyChatWagers.status, ["pending", "rolling"]),
      )).limit(MAX_ACTIVE_CHALLENGES_PER_CREATOR);
      if (wagerChallengeLimitReached(currentActive.length)) throw new Error("Досягнуто ліміт: не більше п’яти активних викликів.");
      await postWalletLedger(tx, challengerId, -parsed.stake, `cw:${id}:reserve:${challengerId}`, id, "Груповий виклик: ставка зарезервована до прийняття", wallet);
      await tx.insert(spyChatWagers).values({
        id,
        chatId: String(message.chat.id),
        messageId: sent.message_id,
        sourceMessageId,
        game: parsed.game,
        status: "pending",
        challengerId,
        opponentId,
        stake: parsed.stake,
        escrowed: true,
        expiresAt: new Date(now + 60_000),
        round: 0,
      });
    });
  } catch (error) {
    const code = (error as any)?.code ?? (error as any)?.cause?.code;
    const duplicate =
      code === "ER_DUP_ENTRY" ||
      code === "1062" ||
      (error as any)?.errno === 1062 ||
      (error as any)?.cause?.errno === 1062;
    await removeButtons(message.chat.id, sent.message_id);
    try {
      await telegramCall("editMessageText", {
        chat_id: message.chat.id,
        message_id: sent.message_id,
        text: duplicate
          ? "Цей виклик уже зареєстровано; повторне повідомлення не створило другу гру."
          : (error instanceof Error ? error.message : "Виклик не створено: помилка збереження стану."),
      });
    } catch {
      // The primary database error is more actionable than a cleanup error.
    }
    if (!duplicate) throw error;
  }
}

async function postWalletLedger(
  tx: any,
  telegramId: string,
  amount: number,
  idempotencyKey: string,
  wagerId: string,
  note: string,
  wallet: any
) {
  const balance = Number(wallet.balance) + amount;
  if (balance < 0) throw new Error("Недостатньо монет для ставки.");
  await tx
    .update(spyWallets)
    .set({ balance })
    .where(eq(spyWallets.telegramId, telegramId));
  await syncEconomyUserTx(tx, telegramId);
  await tx.insert(spyEconomyLedger).values({
    telegramId,
    kind: amount < 0 ? "wager_stake" : "wager_settlement",
    amount,
    balanceAfter: balance,
    idempotencyKey,
    referenceId: wagerId,
    note,
  });
}

async function refundCreatorStakeTx(tx: any, wager: any, note: string) {
  if (!wager.escrowed) return;
  const rows = await tx.select().from(spyWallets).where(eq(spyWallets.telegramId, wager.challengerId)).limit(1).for("update");
  const wallet = rows[0];
  if (!wallet) throw new Error("Гаманець ініціатора не знайдено для повернення ставки.");
  await postWalletLedger(tx, wager.challengerId, Number(wager.stake), `cw:${wager.id}:refund:${wager.challengerId}`, wager.id, note, wallet);
  await tx.update(spyChatWagers).set({ escrowed: false }).where(eq(spyChatWagers.id, wager.id));
}

async function escrow(wagerId: string, opponentId: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyChatWagers)
      .where(eq(spyChatWagers.id, wagerId))
      .limit(1)
      .for("update");
    const wager = rows[0];
    if (!wager || wager.status !== "pending") {
      throw new Error("Цей виклик уже завершено або він недоступний.");
    }
    if (new Date(wager.expiresAt).getTime() <= Date.now()) {
      await refundCreatorStakeTx(tx, wager, "Неприйнятий виклик протерміновано; ставку повернуто");
      await tx
        .update(spyChatWagers)
        .set({ status: "expired" })
        .where(eq(spyChatWagers.id, wagerId));
      return null;
    }
    if (wager.opponentId && wager.opponentId !== opponentId) {
      throw new Error("Цей виклик адресований іншому гравцеві.");
    }

    const participants = [wager.challengerId, opponentId].sort();
    const profiles = await tx
      .select()
      .from(spyProfiles)
      .where(inArray(spyProfiles.telegramId, participants));
    const wallets = new Map<string, any>();
    for (const telegramId of participants) {
      const profile = profiles.find((item: any) => item.telegramId === telegramId);
      if (!profile || profile.blocked) {
        throw new Error("Обидва гравці мають активний профіль Mini App.");
      }
      const rows = await tx
        .select()
        .from(spyWallets)
        .where(eq(spyWallets.telegramId, telegramId))
        .limit(1)
        .for("update");
      const isCreatorWithReservedStake = telegramId === wager.challengerId && wager.escrowed;
      if (!rows[0] || (!isCreatorWithReservedStake && Number(rows[0].balance) < wager.stake)) {
        throw new Error("Обом гравцям потрібен гаманець із достатнім балансом.");
      }
      wallets.set(telegramId, rows[0]);
    }

    for (const telegramId of participants) {
      if (telegramId === wager.challengerId && wager.escrowed) continue;
      await postWalletLedger(tx, telegramId, -wager.stake, `cw:${wagerId}:stake:${telegramId}`, wagerId, "Групова гра: ставка переміщена в escrow", wallets.get(telegramId));
    }
    await tx
      .update(spyChatWagers)
      .set({
        status: "rolling",
        opponentId,
        escrowed: false,
        expiresAt: new Date(Date.now() + 120_000),
      })
      .where(eq(spyChatWagers.id, wagerId));
    return { ...wager, opponentId, status: "rolling" };
  });
}

async function settle(wagerId: string, winnerId: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyChatWagers)
      .where(eq(spyChatWagers.id, wagerId))
      .limit(1)
      .for("update");
    const wager = rows[0];
    if (!wager || wager.status !== "rolling" || !wager.opponentId) return false;
    const participants = [wager.challengerId, wager.opponentId].sort();
    if (!participants.includes(winnerId)) {
      throw new Error("Winner is not a participant in this wager.");
    }

    const wallets = new Map<string, any>();
    for (const telegramId of participants) {
      const result = await tx
        .select()
        .from(spyWallets)
        .where(eq(spyWallets.telegramId, telegramId))
        .limit(1)
        .for("update");
      if (!result[0]) throw new Error("Не вдалося безпечно розрахувати гаманець.");
      wallets.set(telegramId, result[0]);
    }

    const bankRows = await tx
      .select()
      .from(spyChatWagerBank)
      .where(eq(spyChatWagerBank.id, 1))
      .limit(1)
      .for("update");
    if (!bankRows[0]) throw new Error("Резерв комісій ще не ініціалізовано.");

    const { pot, fee, payout } = calculateWager(wager.stake);
    await postWalletLedger(
      tx,
      winnerId,
      payout,
      `cw:${wagerId}:payout`,
      wagerId,
      `Виграш: банк ${pot}, комісія ${fee} (5%, округлення до цілої монети); комісію зараховано до резерву`,
      wallets.get(winnerId)
    );
    const bankBalance = Number(bankRows[0].balance) + fee;
    await tx
      .update(spyChatWagerBank)
      .set({ balance: bankBalance })
      .where(eq(spyChatWagerBank.id, 1));
    await tx.insert(spyChatWagerBankLedger).values({
      wagerId,
      amount: fee,
      balanceAfter: bankBalance,
    });
    await tx
      .update(spyChatWagers)
      .set({ status: "resolved", winnerId })
      .where(eq(spyChatWagers.id, wagerId));
    return true;
  });
}

async function refund(wagerId: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyChatWagers)
      .where(eq(spyChatWagers.id, wagerId))
      .limit(1)
      .for("update");
    const wager = rows[0];
    if (!wager || wager.status !== "rolling" || !wager.opponentId) return false;
    const participants = [wager.challengerId, wager.opponentId].sort();
    for (const telegramId of participants) {
      const result = await tx
        .select()
        .from(spyWallets)
        .where(eq(spyWallets.telegramId, telegramId))
        .limit(1)
        .for("update");
      if (!result[0]) throw new Error("Wallet missing; refusing to mark a wager refunded.");
      await postWalletLedger(
        tx,
        telegramId,
        wager.stake,
        `cw:${wagerId}:refund:${telegramId}`,
        wagerId,
        "Повернення ставки: розіграш перервано, комісія не стягувалася",
        result[0]
      );
    }
    await tx
      .update(spyChatWagers)
      .set({ status: "refunded" })
      .where(eq(spyChatWagers.id, wagerId));
    return true;
  });
}

async function readWager(wagerId: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(spyChatWagers)
    .where(eq(spyChatWagers.id, wagerId))
    .limit(1);
  return rows[0] ?? null;
}

async function recordDiceRoll(
  wagerId: string,
  field: "challengerRoll" | "opponentRoll",
  value: number,
  round?: number
) {
  const db = await getDb();
  if (!db) return null;
  await db
    .update(spyChatWagers)
    .set({
      [field]: value,
      failureCount: 0,
      ...(round === undefined ? {} : { round }),
      expiresAt: new Date(Date.now() + 120_000),
    })
    .where(and(eq(spyChatWagers.id, wagerId), eq(spyChatWagers.status, "rolling")));
  return readWager(wagerId);
}

async function recordDiceSendFailure(wagerId: string, cause: unknown) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  const failure = await db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyChatWagers)
      .where(eq(spyChatWagers.id, wagerId))
      .limit(1)
      .for("update");
    const wager = rows[0];
    if (!wager || wager.status !== "rolling") return null;
    const policy = diceSendFailurePolicy(Number(wager.failureCount ?? 0));
    await tx
      .update(spyChatWagers)
      .set({
        failureCount: policy.failureCount,
        expiresAt: policy.shouldRefund ? new Date(0) : new Date(Date.now() + 15_000),
      })
      .where(eq(spyChatWagers.id, wagerId));
    return {
      ...policy,
      chatId: Number(wager.chatId),
      messageId: Number(wager.messageId),
    };
  });
  if (!failure) return;
  console.warn(
    `[chat wagers] Telegram Dice send failed (${failure.failureCount}/${MAX_DICE_SEND_FAILURES})`,
    cause instanceof Error ? cause.message : cause
  );

  if (failure.shouldRefund) {
    const refunded = await refund(wagerId);
    if (!refunded) return;
    await removeButtons(failure.chatId, failure.messageId);
    try {
      await send(
        failure.chatId,
        `Не вдалося отримати результат кубиків після ${MAX_DICE_SEND_FAILURES} спроб. Обидві ставки повернуто; комісію не стягнуто.`
      );
    } catch (error) {
      console.error("[chat wagers refund notice]", error instanceof Error ? error.message : error);
    }
  } else {
    try {
      await send(
        failure.chatId,
        `Telegram тимчасово не надіслав кубик. Повторюємо без зміни ставок (${failure.failureCount}/${MAX_DICE_SEND_FAILURES}).`
      );
    } catch {
      // A temporary Telegram outage must not prevent the durable retry deadline from being set.
    }
  }
}

async function getDieValue(chatId: number, wagerId: string): Promise<number | null> {
  try {
    const result = await telegramCall<{ dice?: { value?: number } }>("sendDice", {
      chat_id: chatId,
      emoji: "🎲",
    });
    const value = result?.dice?.value;
    if (!Number.isInteger(value) || value! < 1 || value! > 6) {
      throw new Error("Telegram повернув некоректне значення кубика.");
    }
    return value!;
  } catch (error) {
    await recordDiceSendFailure(wagerId, error);
    return null;
  }
}

async function rollDice(chatId: number, initial: any) {
  let wager = initial;
  while (wager?.status === "rolling" && wager.opponentId) {
    let challengerRoll: number | null =
      wager.challengerRoll == null ? null : Number(wager.challengerRoll);
    if (challengerRoll === null) {
      challengerRoll = await getDieValue(chatId, wager.id);
      if (challengerRoll === null) return;
      wager = await recordDiceRoll(wager.id, "challengerRoll", challengerRoll);
      if (!wager || wager.status !== "rolling") return;
    }

    let opponentRoll: number | null =
      wager.opponentRoll == null ? null : Number(wager.opponentRoll);
    if (opponentRoll === null) {
      opponentRoll = await getDieValue(chatId, wager.id);
      if (opponentRoll === null) return;
      wager = await recordDiceRoll(
        wager.id,
        "opponentRoll",
        opponentRoll,
        Number(wager.round) + 1
      );
      if (!wager || wager.status !== "rolling") return;
    }

    const result = tiePolicy(challengerRoll, opponentRoll);
    if (result === "reroll") {
      await send(
        chatId,
        `Рівність ${challengerRoll}:${opponentRoll}! Повторний кидок без додаткової ставки.`
      );
      const db = await getDb();
      if (!db) return;
      await db
        .update(spyChatWagers)
        .set({
          challengerRoll: null,
          opponentRoll: null,
          expiresAt: new Date(Date.now() + 120_000),
        })
        .where(and(eq(spyChatWagers.id, wager.id), eq(spyChatWagers.status, "rolling")));
      wager = await readWager(wager.id);
      continue;
    }

    const winnerId = result === "challenger" ? wager.challengerId : wager.opponentId;
    if (!winnerId) return;
    const settled = await settle(wager.id, winnerId);
    if (!settled) return;
    const { payout } = calculateWager(Number(wager.stake));
    const winner = await userLabel(winnerId);
    await send(
      chatId,
      `🎲 Результат: ${challengerRoll} проти ${opponentRoll}. Переможець: ${winner}! Виплата ${payout} 🪙; комісію зараховано до банку.`
    );
    return;
  }
}

async function declineWager(wagerId: string, actorId: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyChatWagers)
      .where(eq(spyChatWagers.id, wagerId))
      .limit(1)
      .for("update");
    const wager = rows[0];
    if (!wager || wager.status !== "pending") return "inactive" as const;
    const expiresAt = new Date(wager.expiresAt).getTime();
    if (expiresAt <= Date.now()) {
      await refundCreatorStakeTx(tx, wager, "Виклик протерміновано; ставку повернуто");
      await tx
        .update(spyChatWagers)
        .set({ status: "expired" })
        .where(eq(spyChatWagers.id, wagerId));
      return "expired" as const;
    }
    if (
      !mayDecline({
        actorId,
        challengerId: wager.challengerId,
        opponentId: wager.opponentId,
        status: wager.status,
        now: Date.now(),
        expiresAt,
      })
    )
      return "forbidden" as const;
    await refundCreatorStakeTx(tx, wager, "Виклик відхилено; ставку повернуто");
    await tx
      .update(spyChatWagers)
      .set({ status: "refunded" })
      .where(eq(spyChatWagers.id, wagerId));
    return "declined" as const;
  });
}

async function expirePendingWager(wagerId: string) {
  const db = await getDb();
  if (!db) throw new Error("База даних тимчасово недоступна.");
  return db.transaction(async (tx: any) => {
    const rows = await tx.select().from(spyChatWagers).where(eq(spyChatWagers.id, wagerId)).limit(1).for("update");
    const wager = rows[0];
    if (!wager || wager.status !== "pending" || new Date(wager.expiresAt).getTime() > Date.now()) return null;
    await refundCreatorStakeTx(tx, wager, "Виклик протерміновано; ставку повернуто");
    await tx.update(spyChatWagers).set({ status: "expired" }).where(eq(spyChatWagers.id, wagerId));
    return wager;
  });
}

async function markExpiredWagerMessage(chatId: number, messageId: number) {
  try {
    await telegramCall("editMessageText", { chat_id: chatId, message_id: messageId, text: WAGER_TIMEOUT_MESSAGE, reply_markup: { inline_keyboard: [] } });
  } catch {
    await removeButtons(chatId, messageId);
  }
}

export async function handleWagerCallback(query: any) {
  const match = /^cw:(accept|decline):([\w-]+)$/.exec(String(query.data || ""));
  if (!match) return false;
  // Telegram permits one acknowledgement per callback query; later errors are
  // sent as normal chat messages instead of attempting a second toast.
  await answerCallback(query.id, "Перевіряю виклик…");
  if (!query.message || !query.from?.id) return true;
  if (query.message.chat.type !== "group" && query.message.chat.type !== "supergroup") return true;

  const db = await getDb();
  if (!db) {
    await send(query.message.chat.id, "База даних тимчасово недоступна.");
    return true;
  }
  const rows = await db
    .select()
    .from(spyChatWagers)
    .where(eq(spyChatWagers.id, match[2]!))
    .limit(1);
  const wager = rows[0];
  if (!wager || String(query.message.chat.id) !== wager.chatId) {
    await send(query.message.chat.id, "Виклик недоступний.");
    return true;
  }

  const actorId = String(query.from.id);
  if (match[1] === "decline") {
    const result = await declineWager(wager.id, actorId);
    if (result === "forbidden") {
      await send(
        query.message.chat.id,
        wager.opponentId
          ? "Відхилити адресований виклик може лише запрошений гравець."
          : "Відхилити відкритий виклик може будь-який інший гравець групи."
      );
      return true;
    }
    if (result === "inactive") {
      await send(query.message.chat.id, "Виклик уже завершено або недоступний.");
      return true;
    }
    if (result === "expired") {
      await markExpiredWagerMessage(query.message.chat.id, query.message.message_id);
      return true;
    }
    await removeButtons(query.message.chat.id, query.message.message_id);
    await send(query.message.chat.id, "Виклик відхилено.");
    return true;
  }

  if (wager.status === "pending" && new Date(wager.expiresAt).getTime() <= Date.now()) {
    const expired = await expirePendingWager(wager.id);
    if (expired) await markExpiredWagerMessage(query.message.chat.id, query.message.message_id);
    return true;
  }

  if (
    !mayAccept({
      actorId,
      challengerId: wager.challengerId,
      opponentId: wager.opponentId,
      status: wager.status,
      now: Date.now(),
      expiresAt: new Date(wager.expiresAt).getTime(),
    })
  ) {
    await send(
      query.message.chat.id,
      wager.opponentId && actorId !== wager.opponentId
        ? "Цей виклик адресований іншому гравцеві."
        : "Виклик уже завершено або його час минув."
    );
    return true;
  }

  try {
    const accepted = await escrow(wager.id, actorId);
    if (!accepted) {
      await markExpiredWagerMessage(query.message.chat.id, query.message.message_id);
      return true;
    }
    await removeButtons(query.message.chat.id, query.message.message_id);
    if (wager.game === "coin") {
      const toss = randomInt(2);
      const winnerId = toss === 0 ? wager.challengerId : actorId;
      const settled = await settle(wager.id, winnerId);
      if (!settled) return true;
      const winner = await userLabel(winnerId);
      const { pot, fee, payout } = calculateWager(Number(wager.stake));
      await send(
        query.message.chat.id,
        `🪙 Монетка: ${toss === 0 ? "орел" : "решка"}. Переможець: ${winner}! Банк ${pot}, комісія ${fee}, виплата ${payout} 🪙. Комісію зараховано до резерву.`
      );
    } else {
      await rollDice(query.message.chat.id, accepted);
    }
  } catch (error) {
    await send(
      query.message.chat.id,
      error instanceof Error ? error.message : "Не вдалося прийняти ставку."
    );
  }
  return true;
}

export async function handleWagerMessage(message: any) {
  if (!message.from || !message.text) return false;
  const parsed = parseWager(message.text);
  if (!parsed) return false;
  await createWager(message, parsed);
  return true;
}

let workerStarted = false;
export function startWagerWorker() {
  if (workerStarted) return;
  workerStarted = true;

  const tick = async () => {
    try {
      const db = await getDb();
      if (db) {
        const now = new Date();
        const expiredPending = await db
          .select()
          .from(spyChatWagers)
          .where(and(eq(spyChatWagers.status, "pending"), lt(spyChatWagers.expiresAt, now)))
          .limit(50);
        for (const wager of expiredPending) {
          const expired = await expirePendingWager(wager.id);
          if (expired) await markExpiredWagerMessage(Number(wager.chatId), wager.messageId);
        }

        const staleRolls = await db
          .select()
          .from(spyChatWagers)
          .where(and(eq(spyChatWagers.status, "rolling"), lt(spyChatWagers.expiresAt, now)))
          .limit(20);
        for (const wager of staleRolls) {
          if (wager.game === "dice") {
            if (Number(wager.failureCount ?? 0) >= MAX_DICE_SEND_FAILURES) {
              const refunded = await refund(wager.id);
              if (refunded) {
                await removeButtons(Number(wager.chatId), wager.messageId);
                await send(
                  Number(wager.chatId),
                  `Кидок кубиків не вдалося відновити після ${MAX_DICE_SEND_FAILURES} спроб. Обидві ставки повернуто без комісії.`
                );
              }
              continue;
            }
            // Resume from any persisted roll. Telegram offers no sendDice idempotency key,
            // so a crash between Telegram's response and this DB write can still duplicate one die.
            await db
              .update(spyChatWagers)
              .set({ expiresAt: new Date(Date.now() + 120_000) })
              .where(and(eq(spyChatWagers.id, wager.id), eq(spyChatWagers.status, "rolling")));
            try {
              await rollDice(Number(wager.chatId), { ...wager, expiresAt: new Date() });
            } catch (error) {
              console.error(
                "[chat wagers dice recovery]",
                error instanceof Error ? error.message : error
              );
            }
          } else {
            const refunded = await refund(wager.id);
            if (refunded) {
              await send(
                Number(wager.chatId),
                "Розіграш перервано. Обидві ставки повернуто без комісії."
              );
            }
          }
        }
      }
    } catch (error) {
      console.error(
        "[chat wagers worker]",
        error instanceof Error ? error.message : error
      );
    } finally {
      setTimeout(tick, 15_000).unref();
    }
  };

  setTimeout(tick, 15_000).unref();
}
