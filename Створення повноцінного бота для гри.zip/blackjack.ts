import {
  GameRuleError,
  requirePlayer,
  secureRandomInt,
  shuffle,
  type ArcadeAction,
  type ArcadeEngine,
  type ArcadeEngineContext,
  type ArcadeEvent,
  type ArcadeOutcome,
  type ArcadePlayer,
  type ArcadeStep,
  type RandomInt,
} from "./engine";

export type BlackjackRank =
  | "A"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "7"
  | "8"
  | "9"
  | "10"
  | "J"
  | "Q"
  | "K";
export type BlackjackSuit = "clubs" | "diamonds" | "hearts" | "spades";
export type BlackjackCard = { rank: BlackjackRank; suit: BlackjackSuit };
export type BlackjackHand = {
  playerId: string;
  cards: BlackjackCard[];
  initialStake: number;
  stake: number;
  firstAction: boolean;
  status: "playing" | "stood" | "bust" | "natural";
};
export type BlackjackState = {
  players: ArcadePlayer[];
  hands: BlackjackHand[];
  dealer: BlackjackCard[];
  deck: BlackjackCard[];
  currentIndex: number;
  phase: "players" | "dealer" | "finished";
  createdAt: number;
  deadline: number;
  turnMs: number;
  doubleAllowed: boolean;
  outcome?: ArcadeOutcome;
};
export type BlackjackView = {
  phase: BlackjackState["phase"];
  players: Array<{
    id: string;
    name: string;
    seat: number;
    total: number | null;
    status: BlackjackHand["status"];
    cards: BlackjackCard[] | null;
    stake: number;
  }>;
  dealer: {
    cards: Array<BlackjackCard | { hidden: true }>;
    visibleTotal: number | null;
    total: number | null;
  };
  currentPlayerId: string | null;
  legalActions: Array<{ type: "hit" | "stand" | "double"; label: string }>;
  outcome?: ArcadeOutcome;
};

const SUITS: BlackjackSuit[] = ["clubs", "diamonds", "hearts", "spades"];
const RANKS: BlackjackRank[] = [
  "A",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "J",
  "Q",
  "K",
];
const ACTION_TIMEOUT_MS = 60_000;

export function blackjackTotal(cards: readonly BlackjackCard[]): {
  total: number;
  soft: boolean;
} {
  let total = 0;
  let aces = 0;
  for (const card of cards) {
    if (card.rank === "A") {
      total += 11;
      aces += 1;
    } else
      total += ["J", "Q", "K"].includes(card.rank) ? 10 : Number(card.rank);
  }
  while (total > 21 && aces > 0) {
    total -= 10;
    aces -= 1;
  }
  return { total, soft: aces > 0 };
}

const isNatural = (cards: readonly BlackjackCard[]) =>
  cards.length === 2 && blackjackTotal(cards).total === 21;
function event(
  type: string,
  at: number,
  publicText: string,
  actorId?: string
): ArcadeEvent {
  return { type, at, publicText, ...(actorId ? { actorId } : {}) };
}
function draw(state: BlackjackState): BlackjackCard {
  const card = state.deck.pop();
  if (!card)
    throw new GameRuleError("У колоді не залишилося карт.", "DECK_EMPTY");
  return card;
}
function resolveDealer(
  state: BlackjackState,
  now: number,
  events: ArcadeEvent[]
): BlackjackState {
  state.phase = "dealer";
  while (true) {
    const { total } = blackjackTotal(state.dealer);
    if (total >= 17) break; // S17: dealer stands on hard or soft 17.
    state.dealer.push(draw(state));
    events.push(event("dealer-hit", now, "Дилер бере карту."));
  }
  const dealerTotal = blackjackTotal(state.dealer).total;
  const active = state.hands.filter(
    hand => hand.status !== "bust" && hand.status !== "natural"
  );
  const dealerBust = dealerTotal > 21;
  const winners: BlackjackHand[] = [];
  const pushes: BlackjackHand[] = [];
  for (const hand of state.hands) {
    if (hand.status === "bust") continue;
    if (hand.status === "natural") {
      if (!isNatural(state.dealer)) winners.push(hand);
      else pushes.push(hand);
      continue;
    }
    const total = blackjackTotal(hand.cards).total;
    if (dealerBust || total > dealerTotal) winners.push(hand);
    else if (total === dealerTotal) pushes.push(hand);
  }
  // A natural beats an ordinary 21; only two-card 21 pushes against another natural.
  void active;
  let outcome: ArcadeOutcome;
  if (winners.length) {
    outcome = {
      winnerIds: winners.map(h => h.playerId),
      draw: false,
      reason: pushes.length
        ? "Переможці отримують виплату з банку; Push-гравцям повертається їхня ставка. Natural має цільовий прибуток 3:2, обмежений доступним банком."
        : "Результат визначено за руками проти дилера. Natural має цільовий прибуток 3:2, обмежений доступним банком.",
      ...(pushes.length ? { refundIds: pushes.map(h => h.playerId) } : {}),
      payoutMultipliers: Object.fromEntries(
        winners.map(h => [h.playerId, h.status === "natural" ? 2.5 : 2])
      ),
    };
  } else if (pushes.length) {
    outcome = {
      winnerIds: [],
      refundIds: pushes.map(h => h.playerId),
      draw: pushes.length === state.hands.length,
      reason:
        pushes.length < state.hands.length
          ? "Немає переможців: Push-гравцям повертається лише їхня ставка, решта внесків програвших переходить до спільного банку."
          : "Усі руки зіграли Push; повертаються всі ставки.",
    };
  } else {
    outcome = {
      winnerIds: [],
      refundIds: state.hands.map(h => h.playerId),
      draw: true,
      reason:
        "Усі гравці програли дилеру; ставки повертаються відповідно до правил столу.",
    };
  }
  state.phase = "finished";
  state.outcome = outcome;
  events.push(event("finished", now, outcome.reason));
  return state;
}
function advance(
  state: BlackjackState,
  now: number,
  events: ArcadeEvent[]
): BlackjackState {
  while (
    state.currentIndex < state.hands.length &&
    state.hands[state.currentIndex].status !== "playing"
  )
    state.currentIndex += 1;
  if (state.currentIndex >= state.hands.length)
    return resolveDealer(state, now, events);
  state.deadline = now + state.turnMs;
  return state;
}

export const blackjackEngine: ArcadeEngine<BlackjackState, BlackjackView> = {
  gameId: "blackjack",
  minPlayers: 2,
  maxPlayers: 6,
  create(
    players: ArcadePlayer[],
    settings: Record<string, unknown>,
    context: ArcadeEngineContext
  ) {
    if (players.length < 2 || players.length > 6)
      throw new GameRuleError(
        "Для Blackjack потрібні 2–6 гравців.",
        "INVALID_PLAYER_COUNT"
      );
    if (new Set(players.map(p => p.id)).size !== players.length)
      throw new GameRuleError(
        "Гравці мають бути унікальними.",
        "DUPLICATE_PLAYER"
      );
    const ordered = [...players].sort((a, b) => a.seat - b.seat);
    const deck = shuffle(
      SUITS.flatMap(suit => RANKS.map(rank => ({ rank, suit }))),
      context.randomInt
    );
    const configuredStake = settings.stake;
    const stake =
      typeof configuredStake === "number" &&
      Number.isSafeInteger(configuredStake) &&
      configuredStake > 0
        ? configuredStake
        : 1;
    const hands: BlackjackHand[] = ordered.map(p => {
      return {
        playerId: p.id,
        cards: [],
        initialStake: stake,
        stake,
        firstAction: true,
        status: "playing",
      };
    });
    const state: BlackjackState = {
      players: ordered,
      hands,
      dealer: [],
      deck,
      currentIndex: 0,
      phase: "players",
      createdAt: context.now,
      deadline:
        context.now +
        (Number.isSafeInteger(settings.turnMs) && Number(settings.turnMs) > 0
          ? Number(settings.turnMs)
          : ACTION_TIMEOUT_MS),
      turnMs:
        Number.isSafeInteger(settings.turnMs) && Number(settings.turnMs) > 0
          ? Number(settings.turnMs)
          : ACTION_TIMEOUT_MS,
      doubleAllowed: settings.doubleAllowed !== false,
    };
    // Deal clockwise by seat: each player gets one card per pass, then the dealer; repeat.
    for (let pass = 0; pass < 2; pass += 1) {
      for (const hand of hands) hand.cards.push(draw(state));
      state.dealer.push(draw(state));
    }
    hands.forEach(hand => {
      if (isNatural(hand.cards)) hand.status = "natural";
    });
    if (
      blackjackTotal(state.dealer).total === 21 &&
      state.dealer.length === 2
    ) {
      resolveDealer(state, context.now, []);
    } else {
      advance(state, context.now, []);
    }
    return state;
  },
  applyAction(
    state: BlackjackState,
    actorId: string,
    action: ArcadeAction,
    context: ArcadeEngineContext
  ): ArcadeStep<BlackjackState> {
    requirePlayer(state.players, actorId);
    if (state.phase !== "players")
      throw new GameRuleError("Раунд уже не приймає дій.", "ROUND_FINISHED");
    const hand = state.hands[state.currentIndex];
    if (!hand || hand.playerId !== actorId)
      throw new GameRuleError("Зараз не ваш хід.", "NOT_YOUR_TURN");
    const kind = action.type;
    if (kind !== "hit" && kind !== "stand" && kind !== "double")
      throw new GameRuleError("Доступні лише Hit, Stand і Double.");
    if (kind === "double" && (!state.doubleAllowed || !hand.firstAction))
      throw new GameRuleError(
        "Подвоєння доступне лише до першої дії.",
        "DOUBLE_NOT_ALLOWED"
      );
    const next: BlackjackState = {
      ...state,
      hands: state.hands.map(h => ({ ...h, cards: [...h.cards] })),
      dealer: [...state.dealer],
      deck: [...state.deck],
    };
    const current = next.hands[next.currentIndex];
    current.firstAction = false;
    const events: ArcadeEvent[] = [];
    let additionalStake: ArcadeStep<BlackjackState>["additionalStake"];
    if (kind === "hit" || kind === "double") {
      if (kind === "double") {
        current.stake += current.initialStake;
        additionalStake = { playerId: actorId, amount: current.initialStake };
      }
      current.cards.push(draw(next));
      const total = blackjackTotal(current.cards).total;
      if (total > 21) current.status = "bust";
      else if (kind === "double" || total === 21) current.status = "stood";
      events.push(
        event(
          kind,
          context.now,
          `${state.players.find(p => p.id === actorId)!.name} ${kind === "hit" ? "бере карту" : kind === "double" ? "подвоює ставку і бере карту" : "зупиняється"}.`,
          actorId
        )
      );
    } else {
      current.status = "stood";
      events.push(
        event(
          "stand",
          context.now,
          `${state.players.find(p => p.id === actorId)!.name} зупиняється.`,
          actorId
        )
      );
    }
    next.currentIndex += 1;
    advance(next, context.now, events);
    return {
      state: next,
      events,
      ...(additionalStake ? { additionalStake } : {}),
    };
  },
  toView(state: BlackjackState, viewerId: string): BlackjackView {
    const holeHidden = state.phase !== "finished";
    return {
      phase: state.phase,
      players: state.hands.map(hand => {
        const own = hand.playerId === viewerId;
        return {
          id: hand.playerId,
          name: state.players.find(p => p.id === hand.playerId)!.name,
          seat: state.players.find(p => p.id === hand.playerId)!.seat,
          total:
            own || state.phase === "finished"
              ? blackjackTotal(hand.cards).total
              : null,
          status: hand.status,
          cards: own || state.phase === "finished" ? [...hand.cards] : null,
          stake: hand.stake,
        };
      }),
      dealer: {
        cards: holeHidden
          ? [state.dealer[0], { hidden: true }]
          : [...state.dealer],
        visibleTotal: blackjackTotal([state.dealer[0]]).total,
        total: holeHidden ? null : blackjackTotal(state.dealer).total,
      },
      currentPlayerId:
        state.phase === "players"
          ? (state.hands[state.currentIndex]?.playerId ?? null)
          : null,
      legalActions:
        state.phase === "players" &&
        state.hands[state.currentIndex]?.playerId === viewerId
          ? [
              { type: "hit", label: "Hit" },
              { type: "stand", label: "Stand" },
              ...(state.doubleAllowed &&
              state.hands[state.currentIndex].firstAction
                ? [{ type: "double" as const, label: "Double" }]
                : []),
            ]
          : [],
      ...(state.outcome ? { outcome: state.outcome } : {}),
    };
  },
  getDeadline(state) {
    return state.phase === "players" ? state.deadline : null;
  },
  onTimeout(state, context) {
    if (state.phase !== "players" || context.now < state.deadline) return null;
    const next: BlackjackState = {
      ...state,
      hands: state.hands.map(h => ({
        ...h,
        cards: [...h.cards],
        status: h.status === "playing" ? "stood" : h.status,
      })),
      dealer: [...state.dealer],
      deck: [...state.deck],
      currentIndex: state.hands.length,
    };
    const events = [
      event(
        "timeout-stand",
        context.now,
        "Час ходу минув: незавершені руки автоматично зупинено."
      ),
    ];
    resolveDealer(next, context.now, events);
    return { state: next, events, outcome: next.outcome };
  },
};
