import { createHmac, timingSafeEqual } from "node:crypto";
import type { Request } from "express";

export type GameIdentity = {
  id: string;
  firstName: string;
  lastName?: string;
  username?: string;
  avatarUrl?: string;
  preview: boolean;
};

type TelegramWebAppUser = {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
};

function constantTimeHexEqual(left: string, right: string) {
  if (!/^[a-f0-9]{64}$/i.test(left) || !/^[a-f0-9]{64}$/i.test(right)) return false;
  return timingSafeEqual(Buffer.from(left, "hex"), Buffer.from(right, "hex"));
}

export function verifyTelegramInitData(initData: string, botToken: string, nowSeconds = Math.floor(Date.now() / 1000)) {
  if (!initData || initData.length > 8192 || !botToken) return null;
  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  const authDate = Number(params.get("auth_date"));
  const rawUser = params.get("user");
  if (!receivedHash || !Number.isFinite(authDate) || !rawUser) return null;
  if (authDate > nowSeconds + 30 || nowSeconds - authDate > 86400) return null;

  const checkString = [...params.entries()]
    .filter(([key]) => key !== "hash")
    .sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secretKey = createHmac("sha256", "WebAppData").update(botToken).digest();
  const calculatedHash = createHmac("sha256", secretKey).update(checkString).digest("hex");
  if (!constantTimeHexEqual(receivedHash, calculatedHash)) return null;

  try {
    const user = JSON.parse(rawUser) as TelegramWebAppUser;
    if (!Number.isSafeInteger(user.id) || user.id <= 0) return null;
    return {
      id: String(user.id),
      firstName: (user.first_name || "Агент").slice(0, 100),
      lastName: user.last_name?.slice(0, 100),
      username: user.username?.slice(0, 100),
      avatarUrl: user.photo_url?.slice(0, 2048),
      preview: false,
    } satisfies GameIdentity;
  } catch {
    return null;
  }
}

export function identityFromRequest(req: Request): GameIdentity | null {
  const initData = req.header("x-telegram-init-data") || "";
  const botToken = process.env.TELEGRAM_BOT_TOKEN || "";
  if (botToken) {
    const verified = verifyTelegramInitData(initData, botToken);
    if (verified) return verified;
    if (process.env.NODE_ENV !== "development") return null;
    // Development preview auth is deliberately isolated from production and never accepts Telegram ids.
  } else if (process.env.NODE_ENV !== "development") {
    return null;
  }

  if (process.env.NODE_ENV === "development") {
    const rawId = req.header("x-preview-player") || "preview-agent";
    const safeId = rawId.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 50) || "preview-agent";
    return {
      id: `preview:${safeId}`,
      firstName: (req.header("x-preview-name") || "Тестовий агент").slice(0, 40),
      preview: true,
    };
  }
  return null;
}
