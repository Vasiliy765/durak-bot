import {
  GameRuleError,
  requirePlayer,
  type ArcadeAction,
  type ArcadeEngine,
  type ArcadeEngineContext,
  type ArcadeEvent,
  type ArcadeOutcome,
  type ArcadePlayer,
  type ArcadeStep,
} from "./engine.js";

export const BOARD_SIZE = 10;
export const FLEET_LENGTHS = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1] as const;
const DEFAULT_TURN_MS = 60_000;
const AUTO_PLACE_ATTEMPTS = 100;
type Coord = { x: number; y: number };
export type ShipPlacement = {
  x: number;
  y: number;
  length: number;
  orientation: "horizontal" | "vertical";
};
type Ship = { id: number; cells: Coord[]; hits: Coord[] };
type Shot = Coord & { result: "miss" | "hit" | "sunk" };
type PlayerBoard = { ships: Ship[]; shotsReceived: Shot[] };
export type BattleshipState = {
  players: ArcadePlayer[];
  boards: Record<string, PlayerBoard>;
  phase: "placing" | "playing" | "finished";
  ready: string[];
  currentPlayerId: string | null;
  extraShotOnHit: boolean;
  deadline: number | null;
  turnMs: number;
  outcome?: ArcadeOutcome;
};
export type BattleshipView = {
  phase: BattleshipState["phase"];
  ownBoard: {
    ships: Array<{ id: number; cells: Coord[]; hits: Coord[] }>;
    shotsReceived: Shot[];
  };
  opponent: {
    id: string;
    name: string;
    seat: number;
    shots: Shot[];
    remainingSegments: number;
    ships?: Array<{ id: number; cells: Coord[]; hits: Coord[] }>;
  };
  ready: boolean;
  opponentReady: boolean;
  currentPlayerId: string | null;
  isYourTurn: boolean;
  deadline: number | null;
  legalActions: { type: "shoot"; x: number; y: number }[];
  outcome?: ArcadeOutcome;
};
function fail(message: string, code?: string): never {
  throw new GameRuleError(message, code);
}
function coordKey({ x, y }: Coord) {
  return `${x},${y}`;
}
function validCoord(c: Coord) {
  return (
    Number.isInteger(c?.x) &&
    Number.isInteger(c?.y) &&
    c.x >= 0 &&
    c.x < BOARD_SIZE &&
    c.y >= 0 &&
    c.y < BOARD_SIZE
  );
}
function event(
  type: string,
  actorId: string,
  at: number,
  publicText: string
): ArcadeEvent {
  return { type, actorId, at, publicText };
}
function assertActor(state: BattleshipState, id: string) {
  requirePlayer(state.players, id);
}
function opposing(state: BattleshipState, id: string) {
  return state.players.find(p => p.id !== id)!;
}
function buildShips(input: unknown): Ship[] {
  if (!Array.isArray(input) || input.length !== FLEET_LENGTHS.length)
    fail("Потрібно розмістити всі 10 кораблів.");
  const placements = input as ShipPlacement[];
  const lengths = placements.map(s => s?.length).sort((a, b) => a - b);
  if (
    JSON.stringify(lengths) !==
    JSON.stringify([...FLEET_LENGTHS].sort((a, b) => a - b))
  )
    fail("Неправильний склад флоту.");
  const occupied = new Set<string>();
  return placements.map((p, id) => {
    if (
      !Number.isInteger(p.x) ||
      !Number.isInteger(p.y) ||
      (p.orientation !== "horizontal" && p.orientation !== "vertical")
    )
      fail("Некоректне розміщення корабля.");
    const cells = Array.from({ length: p.length }, (_, i) => ({
      x: p.x + (p.orientation === "horizontal" ? i : 0),
      y: p.y + (p.orientation === "vertical" ? i : 0),
    }));
    for (const c of cells) {
      if (!validCoord(c))
        fail("Корабель виходить за межі поля.", "OUT_OF_BOUNDS");
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++)
          if (occupied.has(coordKey({ x: c.x + dx, y: c.y + dy })))
            fail(
              "Кораблі не можуть перекриватися або торкатися.",
              "INVALID_FLEET"
            );
    }
    for (const c of cells) occupied.add(coordKey(c));
    return { id, cells, hits: [] };
  });
}
function randomFleet(randomInt: (max: number) => number): ShipPlacement[] {
  for (let attempt = 0; attempt < AUTO_PLACE_ATTEMPTS; attempt++) {
    const occupied = new Set<string>();
    const placements: ShipPlacement[] = [];
    let failed = false;
    for (const length of FLEET_LENGTHS) {
      const candidates: ShipPlacement[] = [];
      for (const orientation of ["horizontal", "vertical"] as const)
        for (let y = 0; y < BOARD_SIZE; y++)
          for (let x = 0; x < BOARD_SIZE; x++) {
            const p = { x, y, length, orientation };
            const cells = Array.from({ length }, (_, i) => ({
              x: x + (orientation === "horizontal" ? i : 0),
              y: y + (orientation === "vertical" ? i : 0),
            }));
            if (
              cells.every(
                c =>
                  validCoord(c) &&
                  Array.from({ length: 3 }, (_, dy) => dy - 1).every(dy =>
                    Array.from({ length: 3 }, (_, dx) => dx - 1).every(
                      dx =>
                        !occupied.has(coordKey({ x: c.x + dx, y: c.y + dy }))
                    )
                  )
              )
            )
              candidates.push(p);
          }
      if (!candidates.length) {
        failed = true;
        break;
      }
      const chosen = candidates[randomInt(candidates.length)];
      placements.push(chosen);
      for (let i = 0; i < length; i++)
        occupied.add(
          coordKey({
            x: chosen.x + (chosen.orientation === "horizontal" ? i : 0),
            y: chosen.y + (chosen.orientation === "vertical" ? i : 0),
          })
        );
    }
    if (!failed) return placements;
  }
  fail(
    "Не вдалося автоматично розмістити флот; повторіть спробу.",
    "AUTO_PLACE_FAILED"
  );
}

export const battleshipEngine: ArcadeEngine<BattleshipState, BattleshipView> = {
  gameId: "battleship",
  minPlayers: 2,
  maxPlayers: 2,
  create(players, settings, context) {
    if (players.length !== 2 || new Set(players.map(p => p.id)).size !== 2)
      fail("Морський бій потребує двох різних гравців.", "INVALID_PLAYERS");
    const turnMs =
      Number.isSafeInteger(settings.turnMs) && Number(settings.turnMs) >= 1_000
        ? Number(settings.turnMs)
        : DEFAULT_TURN_MS;
    return {
      players: players.map(p => ({ ...p })),
      boards: Object.fromEntries(
        players.map(p => [p.id, { ships: [], shotsReceived: [] }])
      ),
      phase: "placing",
      ready: [],
      currentPlayerId: null,
      extraShotOnHit: settings.extraShotOnHit === true,
      turnMs,
      deadline: context.now + turnMs,
    };
  },
  applyAction(
    state,
    actorId,
    action: ArcadeAction,
    context
  ): ArcadeStep<BattleshipState> {
    assertActor(state, actorId);
    if (state.phase === "finished")
      fail("Партію вже завершено.", "GAME_FINISHED");
    if (state.phase === "placing") {
      if (action.type === "place" || action.type === "auto_place") {
        if (state.ready.includes(actorId)) fail("Розміщення вже підтверджено.");
        const ships = buildShips(
          action.type === "place"
            ? action.ships
            : randomFleet(context.randomInt)
        );
        const next = {
          ...state,
          boards: {
            ...state.boards,
            [actorId]: { ...state.boards[actorId], ships },
          },
        };
        return {
          state: next,
          events: [
            event(
              "fleet_placed",
              actorId,
              context.now,
              "Гравець розмістив флот."
            ),
          ],
        };
      }
      if (action.type === "ready") {
        if (state.boards[actorId].ships.length !== 10)
          fail("Спочатку розмістіть повний флот.");
        if (state.ready.includes(actorId)) fail("Ви вже готові.");
        const ready = [...state.ready, actorId];
        const bothReady = ready.length === 2;
        const first = bothReady ? state.players[context.randomInt(2)].id : null;
        return {
          state: {
            ...state,
            ready,
            phase: bothReady ? "playing" : "placing",
            currentPlayerId: first,
            deadline: bothReady ? context.now + state.turnMs : state.deadline,
          },
          events: [
            event(
              "player_ready",
              actorId,
              context.now,
              bothReady
                ? "Обидва гравці готові; партія почалася."
                : "Гравець готовий."
            ),
          ],
        };
      }
      fail("Під час розміщення доступні лише place, auto_place і ready.");
    }
    if (action.type !== "shoot") fail("Під час бою доступний лише постріл.");
    if (actorId !== state.currentPlayerId)
      fail("Зараз хід суперника.", "NOT_YOUR_TURN");
    const opponent = opposing(state, actorId);
    const { x, y } = action as unknown as Coord;
    if (!validCoord({ x, y })) fail("Координата поза полем.", "OUT_OF_BOUNDS");
    const board = state.boards[opponent.id];
    if (board.shotsReceived.some(s => s.x === x && s.y === y))
      fail("У цю клітинку вже стріляли.", "REPEAT_SHOT");
    const ship = board.ships.find(s =>
      s.cells.some(c => c.x === x && c.y === y)
    );
    const result: Shot["result"] = !ship
      ? "miss"
      : ship.hits.length + 1 === ship.cells.length
        ? "sunk"
        : "hit";
    const shot: Shot = { x, y, result };
    const updatedBoard = {
      ...board,
      shotsReceived: [...board.shotsReceived, shot],
      ships: ship
        ? board.ships.map(s =>
            s.id === ship.id ? { ...s, hits: [...s.hits, { x, y }] } : s
          )
        : board.ships,
    };
    const boards = { ...state.boards, [opponent.id]: updatedBoard };
    const destroyed = updatedBoard.ships.reduce((n, s) => n + s.hits.length, 0);
    const won = destroyed === 20;
    const keepTurn = result !== "miss" && state.extraShotOnHit;
    const nextState: BattleshipState = {
      ...state,
      boards,
      phase: won ? "finished" : "playing",
      currentPlayerId: won || keepTurn ? actorId : opponent.id,
      deadline: won ? null : context.now + state.turnMs,
    };
    if (won)
      nextState.outcome = {
        winnerIds: [actorId],
        draw: false,
        reason: "Усі кораблі суперника знищено.",
      };
    return {
      state: nextState,
      events: [
        event(
          result,
          actorId,
          context.now,
          result === "miss"
            ? "Постріл — промах."
            : result === "hit"
              ? "Влучання!"
              : `Корабель знищено (${ship!.cells.length} клітинок).`
        ),
      ],
      ...(won ? { outcome: nextState.outcome } : {}),
    };
  },
  toView(state, viewerId) {
    assertActor(state, viewerId);
    const opponent = opposing(state, viewerId);
    const own = state.boards[viewerId];
    const enemy = state.boards[opponent.id];
    const shots = enemy.shotsReceived.map(s => ({ ...s }));
    const ownBoard = {
      ships: own.ships.map(s => ({
        id: s.id,
        cells: s.cells.map(c => ({ ...c })),
        hits: s.hits.map(c => ({ ...c })),
      })),
      shotsReceived: own.shotsReceived.map(s => ({ ...s })),
    };
    const legalActions =
      state.phase === "playing" && state.currentPlayerId === viewerId
        ? Array.from({ length: BOARD_SIZE }, (_, y) =>
            Array.from({ length: BOARD_SIZE }, (_, x) => ({
              type: "shoot" as const,
              x,
              y,
            }))
          )
            .flat()
            .filter(
              c => !enemy.shotsReceived.some(s => s.x === c.x && s.y === c.y)
            )
        : [];
    return {
      phase: state.phase,
      ownBoard,
      opponent: {
        id: opponent.id,
        name: opponent.name,
        seat: opponent.seat,
        shots,
        remainingSegments:
          20 - enemy.ships.reduce((n, s) => n + s.hits.length, 0),
        ...(state.phase === "finished"
          ? {
              ships: enemy.ships.map(s => ({
                id: s.id,
                cells: s.cells.map(c => ({ ...c })),
                hits: s.hits.map(c => ({ ...c })),
              })),
            }
          : {}),
      },
      ready: state.ready.includes(viewerId),
      opponentReady: state.ready.includes(opponent.id),
      currentPlayerId: state.currentPlayerId,
      isYourTurn: state.currentPlayerId === viewerId,
      deadline: state.deadline,
      legalActions,
      ...(state.outcome ? { outcome: state.outcome } : {}),
    };
  },
  getDeadline(state) {
    return state.phase === "finished" ? null : state.deadline;
  },
  onTimeout(state, context) {
    if (
      state.phase === "finished" ||
      state.deadline === null ||
      context.now < state.deadline
    )
      return null;
    const forfeiter =
      state.phase === "playing"
        ? state.currentPlayerId
        : (state.players.find(p => !state.ready.includes(p.id))?.id ??
          state.players.find(p => state.boards[p.id].ships.length !== 10)?.id ??
          state.players[0].id);
    const winner = opposing(state, forfeiter!);
    const outcome = {
      winnerIds: [winner.id],
      draw: false,
      reason: "Тайм-аут: поразка за неявку.",
    };
    const next = {
      ...state,
      phase: "finished" as const,
      currentPlayerId: null,
      deadline: null,
      outcome,
    };
    return {
      state: next,
      events: [
        event(
          "timeout_forfeit",
          forfeiter!,
          context.now,
          "Гравець не виконав дію вчасно; перемогу присуджено супернику."
        ),
      ],
      outcome,
    };
  },
};
