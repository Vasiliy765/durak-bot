import type { ArcadeOutcome } from "./engine";

export type PayoutInput = {
  playerIds: readonly string[];
  contributions: Readonly<Record<string, number>>;
  outcome: ArcadeOutcome;
};

/** Distributes only real escrow. Refund claims are returned first; winners split remaining losses by weight. */
export function calculatePayouts({
  playerIds,
  contributions,
  outcome,
}: PayoutInput): Record<string, number> {
  const ids = [...new Set(playerIds)].sort();
  const amount = (id: string) => {
    const n = contributions[id] ?? 0;
    if (!Number.isSafeInteger(n) || n < 0) throw new RangeError(`Invalid contribution for ${id}`);
    return n;
  };
  const pot = ids.reduce((sum, id) => sum + amount(id), 0);
  const payouts: Record<string, number> = Object.fromEntries(ids.map(id => [id, 0]));
  const refundIds = new Set(outcome.draw ? ids : (outcome.refundIds ?? []));
  for (const id of refundIds) if (id in payouts) payouts[id] += amount(id);
  const winners = [...new Set(outcome.winnerIds)].filter(id => id in payouts && !refundIds.has(id)).sort();
  if (!winners.length) {
    for (const id of ids) payouts[id] = amount(id);
    return payouts;
  }
  const losingPool = ids.filter(id => !refundIds.has(id) && !winners.includes(id)).reduce((s, id) => s + amount(id), 0);
  const weights = winners.map(id => {
    const w = outcome.winnerWeights?.[id] ?? 1;
    if (!Number.isFinite(w) || w <= 0) throw new RangeError(`Invalid winner weight for ${id}`);
    return w;
  });
  const totalWeight = weights.reduce((s, w) => s + w, 0);
  let assigned = 0;
  winners.forEach((id, i) => { const share = Math.floor((losingPool * weights[i]) / totalWeight); payouts[id] += amount(id) + share; assigned += share; });
  let remainder = losingPool - assigned;
  for (const id of winners) { if (!remainder) break; payouts[id] += 1; remainder -= 1; }
  const sum = Object.values(payouts).reduce((s, n) => s + n, 0);
  if (sum !== pot || Object.values(payouts).some(n => n < 0)) throw new Error("Payout conservation invariant failed");
  return payouts;
}

export function applyArcadeVipCommission(
  grossPayouts: Readonly<Record<string, number>>,
  winnerIds: readonly string[],
  vipActiveByPlayer: Readonly<Record<string, boolean>>,
  rate = 0.1,
) {
  if (!Number.isFinite(rate) || rate < 0 || rate > 1) throw new RangeError("Invalid commission rate");
  const payouts = { ...grossPayouts };
  const commissions: Record<string, number> = {};
  for (const id of new Set(winnerIds)) {
    const gross = payouts[id] ?? 0;
    if (!Number.isSafeInteger(gross) || gross < 0) throw new RangeError(`Invalid payout for ${id}`);
    const fee = vipActiveByPlayer[id] ? 0 : Math.floor(gross * rate);
    commissions[id] = fee;
    payouts[id] = gross - fee;
  }
  const totalCommission = Object.values(commissions).reduce((sum, value) => sum + value, 0);
  return { payouts, commissions, totalCommission };
}

export type BlackjackBankSettlement = {
  payouts: Record<string, number>;
  targetPayouts: Record<string, number>;
  totalPot: number;
  bankBalanceBefore: number;
  availableBank: number;
  bankBalanceAfter: number;
  bankCapped: boolean;
};

/**
 * Settles Blackjack against a shared, persisted bank. Multipliers are total
 * returns including the player's stake (2.0 for a regular win, 2.5 for a
 * natural, i.e. 3:2 profit). Push/all-lose refunds are protected first; any
 * unclaimed escrow remains in the bank for future games. If claims exceed the
 * bank, winner claims are proportionally capped with deterministic remainders.
 */
export function calculateBlackjackBankPayouts({
  playerIds,
  contributions,
  outcome,
  bankBalance,
}: PayoutInput & { bankBalance: number }): BlackjackBankSettlement {
  const ids = [...new Set(playerIds)].sort();
  if (!Number.isSafeInteger(bankBalance) || bankBalance < 0) throw new RangeError("Invalid bank balance");
  const amount = (id: string) => {
    const value = contributions[id] ?? 0;
    if (!Number.isSafeInteger(value) || value < 0) throw new RangeError(`Invalid contribution for ${id}`);
    return value;
  };
  const totalPot = ids.reduce((sum, id) => sum + amount(id), 0);
  const availableBank = bankBalance + totalPot;
  if (!Number.isSafeInteger(availableBank)) throw new RangeError("Bank balance exceeds safe integer range");
  const payouts: Record<string, number> = Object.fromEntries(ids.map(id => [id, 0]));
  const targetPayouts: Record<string, number> = Object.fromEntries(ids.map(id => [id, 0]));
  const refundIds = new Set(outcome.draw ? ids : (outcome.refundIds ?? []));
  for (const id of refundIds) if (id in payouts) { payouts[id] = amount(id); targetPayouts[id] = amount(id); }
  const winners = [...new Set(outcome.winnerIds)].filter(id => id in payouts && !refundIds.has(id)).sort();
  if (!winners.length) {
    if (!outcome.draw && outcome.refundIds?.length) {
      const paid = Object.values(payouts).reduce((sum, value) => sum + value, 0);
      return { payouts, targetPayouts, totalPot, bankBalanceBefore: bankBalance, availableBank, bankBalanceAfter: availableBank - paid, bankCapped: false };
    }
    for (const id of ids) { payouts[id] = amount(id); targetPayouts[id] = amount(id); }
    return { payouts, targetPayouts, totalPot, bankBalanceBefore: bankBalance, availableBank, bankBalanceAfter: bankBalance, bankCapped: false };
  }
  const refundTotal = ids.reduce((sum, id) => sum + payouts[id], 0);
  const winnerBudget = availableBank - refundTotal;
  const claims = winners.map(id => {
    const multiplier = outcome.payoutMultipliers?.[id] ?? 2;
    if (!Number.isFinite(multiplier) || multiplier < 1) throw new RangeError(`Invalid payout multiplier for ${id}`);
    const target = Math.floor(amount(id) * multiplier);
    if (!Number.isSafeInteger(target)) throw new RangeError(`Invalid target payout for ${id}`);
    targetPayouts[id] = target;
    return { id, target };
  });
  const totalClaims = claims.reduce((sum, claim) => sum + claim.target, 0);
  const paidClaims = Math.min(totalClaims, winnerBudget);
  let assigned = 0;
  for (const claim of claims) { const share = totalClaims <= winnerBudget ? claim.target : Math.floor((winnerBudget * claim.target) / totalClaims); payouts[claim.id] = share; assigned += share; }
  let remainder = paidClaims - assigned;
  for (const claim of claims) { if (!remainder) break; if (payouts[claim.id] < claim.target) { payouts[claim.id] += 1; remainder -= 1; } }
  const paidTotal = Object.values(payouts).reduce((sum, value) => sum + value, 0);
  const bankBalanceAfter = availableBank - paidTotal;
  if (bankBalanceAfter < 0 || paidTotal > availableBank) throw new Error("Blackjack bank conservation invariant failed");
  return { payouts, targetPayouts, totalPot, bankBalanceBefore: bankBalance, availableBank, bankBalanceAfter, bankCapped: totalClaims > winnerBudget };
}
