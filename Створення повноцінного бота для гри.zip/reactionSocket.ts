import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import type { IncomingMessage, Server } from "node:http";
import { and, eq } from "drizzle-orm";
import { WebSocket, WebSocketServer } from "ws";
import { gameTablePlayers, gameTables } from "../../../drizzle/schema";
import { getDb } from "../../db";

const SOCKET_PATH = "/api/game-center/reactions";
const TICKET_TTL_MS = 30_000;
const allowedReactions = new Set(["😂", "🤦", "🤬", "😏", "😭", "🤩", "😉"]);
type TicketPayload = { userId: string; tableId: string; exp: number; nonce: string };
const subscribers = new Map<string, Set<WebSocket>>();
const usedTickets = new Map<string, number>();

function signingKey() {
  return process.env.TELEGRAM_BOT_TOKEN?.trim() || process.env.SESSION_SECRET?.trim() || "";
}

function sign(encoded: string) {
  const key = signingKey();
  if (!key) throw Object.assign(new Error("WebSocket signing key is unavailable"), { status: 503 });
  return createHmac("sha256", key).update(encoded).digest("base64url");
}

async function activeDurakParticipant(tableId: string, userId: string) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db
    .select({ id: gameTables.id })
    .from(gameTables)
    .innerJoin(gameTablePlayers, eq(gameTablePlayers.tableId, gameTables.id))
    .where(and(
      eq(gameTables.id, tableId),
      eq(gameTables.gameId, "durak"),
      eq(gameTables.status, "playing"),
      eq(gameTablePlayers.telegramId, userId),
      eq(gameTablePlayers.status, "active"),
    ))
    .limit(1);
  return rows.length > 0;
}

export async function issueDurakReactionSocketTicket(userId: string, tableId: string) {
  if (!/^[\w-]{8,64}$/.test(tableId) || !(await activeDurakParticipant(tableId, userId))) {
    throw Object.assign(new Error("Active Durak table membership required"), { status: 403 });
  }
  const payload: TicketPayload = {
    userId,
    tableId,
    exp: Date.now() + TICKET_TTL_MS,
    nonce: randomUUID(),
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${encoded}.${sign(encoded)}`;
}

function verifyTicket(value: string): TicketPayload | null {
  const [encoded, supplied, extra] = value.split(".");
  if (!encoded || !supplied || extra !== undefined) return null;
  let expected: string;
  try { expected = sign(encoded); } catch { return null; }
  const suppliedBytes = Buffer.from(supplied);
  const expectedBytes = Buffer.from(expected);
  if (suppliedBytes.length !== expectedBytes.length || !timingSafeEqual(suppliedBytes, expectedBytes)) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as TicketPayload;
    if (!payload.userId || !payload.tableId || !payload.nonce || !Number.isFinite(payload.exp) || payload.exp < Date.now()) return null;
    if (!/^[\w-]{8,64}$/.test(payload.tableId)) return null;
    return payload;
  } catch { return null; }
}

function rejectUpgrade(socket: import("node:stream").Duplex, status = 401) {
  const message = status === 403 ? "Forbidden" : "Unauthorized";
  socket.write(`HTTP/1.1 ${status} ${message}\r\nConnection: close\r\n\r\n`);
  socket.destroy();
}

export function registerDurakReactionSocket(server: Server) {
  const wss = new WebSocketServer({ noServer: true, maxPayload: 4096, perMessageDeflate: false });
  server.on("upgrade", (request: IncomingMessage, socket, head) => {
    let url: URL;
    try { url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`); }
    catch { return; }
    if (url.pathname !== SOCKET_PATH) return;
    const origin = request.headers.origin;
    if (origin) {
      try {
        const expectedHost = String(request.headers["x-forwarded-host"] || request.headers.host || "").split(",")[0].trim();
        if (new URL(origin).host !== expectedHost) return rejectUpgrade(socket, 403);
      } catch { return rejectUpgrade(socket, 403); }
    }
    const token = url.searchParams.get("ticket") || "";
    const ticket = verifyTicket(token);
    if (!ticket || usedTickets.has(ticket.nonce)) return rejectUpgrade(socket);
    usedTickets.set(ticket.nonce, ticket.exp);
    for (const [nonce, expiry] of usedTickets) if (expiry < Date.now()) usedTickets.delete(nonce);
    void activeDurakParticipant(ticket.tableId, ticket.userId).then(active => {
      if (!active) return rejectUpgrade(socket, 403);
      wss.handleUpgrade(request, socket, head, ws => {
        const room = subscribers.get(ticket.tableId) || new Set<WebSocket>();
        room.add(ws);
        subscribers.set(ticket.tableId, room);
        ws.on("close", () => {
          room.delete(ws);
          if (!room.size) subscribers.delete(ticket.tableId);
        });
        ws.on("error", () => {
          room.delete(ws);
          if (!room.size) subscribers.delete(ticket.tableId);
        });
        ws.on("message", () => ws.close(1008, "Server-push channel only"));
        ws.send(JSON.stringify({ type: "ready", tableId: ticket.tableId }));
      });
    }).catch(() => rejectUpgrade(socket, 403));
  });
}

export function broadcastDurakReaction(tableId: string, reaction: { playerId: string; emoji: string; at: string }) {
  if (!allowedReactions.has(reaction.emoji)) return;
  const payload = JSON.stringify({ type: "reaction", ...reaction });
  for (const ws of subscribers.get(tableId) || []) {
    if (ws.readyState === WebSocket.OPEN) ws.send(payload);
  }
}
