import { describe, expect, it } from "vitest";
import { calculatePayouts } from "./payouts";
import { calculateElo, limitValue } from "./stats";
import { inviteParam, isReconnectGraceExpired } from "./tableService";

describe("arcade backend safety primitives", () => {
  it("keeps payout sums exactly equal to escrow, including split remainders", () => {
    const result = calculatePayouts({ playerIds: ["a", "b", "c"], contributions: { a: 10, b: 10, c: 10 }, outcome: { winnerIds: ["a", "b"], draw: false, reason: "win" } });
    expect(Object.values(result).reduce((a, b) => a + b, 0)).toBe(30);
    expect(result).toEqual({ a: 15, b: 15, c: 0 });
  });
  it("computes symmetric Elo changes and clamps list limits", () => {
    expect(calculateElo(1000, 1000, 1)).toBe(1016);
    expect(calculateElo(1000, 1000, 0)).toBe(984);
    expect(calculateElo(1000, 1000, 0.5)).toBe(1000);
    expect(limitValue(999)).toBe(100);
  });
  it("applies grace only until the configured heartbeat window elapses", () => {
    expect(isReconnectGraceExpired(new Date(1000), 1000 + 119_000, 120)).toBe(false);
    expect(isReconnectGraceExpired(new Date(1000), 1000 + 120_000, 120)).toBe(true);
  });
  it("uses a distinct bearer parameter namespace", () => {
    expect(inviteParam("secret-token")).toBe("arcade_secret-token");
  });
});
