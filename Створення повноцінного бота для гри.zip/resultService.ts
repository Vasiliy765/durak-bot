import { eq } from "drizzle-orm";
import { spyProfiles } from "../../drizzle/schema";
import { awardGameRewardTx } from "./economy";
import type { GroupRole } from "./groupGameRules";

export type ResultPlayer = {
  id: string;
  firstName: string;
  lastName?: string | null;
  role?: GroupRole;
};

export async function updateProfilesForResult(
  tx: any,
  input: {
    roundId: string;
    winner: "spies" | "civilians";
    players: ResultPlayer[];
    durationSeconds: number;
    xpParticipation: number;
    xpWin: number;
    winnerRewardOverride?: number;
  }
) {
  const spyCount = input.players.filter(player => player.role === "spy").length;
  const orderedPlayers = [...input.players].sort((left, right) =>
    left.id < right.id ? -1 : left.id > right.id ? 1 : 0
  );
  for (const player of orderedPlayers) {
    const rows = await tx
      .select()
      .from(spyProfiles)
      .where(eq(spyProfiles.telegramId, player.id))
      .limit(1)
      .for("update");
    const profile = rows[0];
    const isSpy = player.role === "spy";
    const won = (input.winner === "spies") === isSpy;
    if (profile) {
      const nextStreak = won ? profile.winStreak + 1 : 0;
      const caught = !isSpy && input.winner === "civilians" ? spyCount : 0;
      const achievements = new Set<string>(profile.achievements ?? []);
      if (won && isSpy && profile.spyWins + 1 >= 1)
        achievements.add("first-spy-win");
      if (won && isSpy && profile.spyWins + 1 >= 10)
        achievements.add("master-of-disguise");
      if (profile.spiesCaught + caught >= 10) achievements.add("detective");
      if (won && profile.wins + 1 >= 100) achievements.add("legend");
      if (nextStreak >= 5) achievements.add("unstoppable");
      await tx
        .update(spyProfiles)
        .set({
          gamesPlayed: profile.gamesPlayed + 1,
          wins: profile.wins + (won ? 1 : 0),
          losses: profile.losses + (won ? 0 : 1),
          spyWins: profile.spyWins + (won && isSpy ? 1 : 0),
          civilianWins: profile.civilianWins + (won && !isSpy ? 1 : 0),
          spiesCaught: profile.spiesCaught + caught,
          rating: Math.max(0, profile.rating + (won ? 18 : -8)),
          xp: profile.xp + input.xpParticipation + (won ? input.xpWin : 0),
          winStreak: nextStreak,
          bestStreak: Math.max(profile.bestStreak, nextStreak),
          achievements: [...achievements],
        })
        .where(eq(spyProfiles.telegramId, player.id));
    }
    await awardGameRewardTx(tx, {
      identity: {
        id: player.id,
        firstName: player.firstName,
        lastName: player.lastName,
      },
      roundId: input.roundId,
      won,
      participantCount: input.players.length,
      durationSeconds: input.durationSeconds,
      winnerRewardOverride: input.winnerRewardOverride,
    });
  }
}
