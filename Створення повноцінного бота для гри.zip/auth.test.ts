import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { verifyTelegramInitData } from "./auth";
import { SECRET_WORDS } from "./secretWords";

const botToken = "unit-test-bot-token";

function makeInitData(authDate: number) {
  const values = new URLSearchParams();
  values.set("auth_date", String(authDate));
  values.set("query_id", "AAEAAAE");
  values.set("user", JSON.stringify({ id: 424242, first_name: "Тест", last_name: "Агент", username: "test_agent" }));
  const checkString = [...values.entries()]
    .sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secretKey = createHmac("sha256", "WebAppData").update(botToken).digest();
  values.set("hash", createHmac("sha256", secretKey).update(checkString).digest("hex"));
  return values.toString();
}

describe("verifyTelegramInitData", () => {
  const now = 1_900_000_000;

  it("accepts a correctly signed Telegram user and returns only normalized identity fields", () => {
    expect(verifyTelegramInitData(makeInitData(now), botToken, now)).toMatchObject({
      id: "424242",
      firstName: "Тест",
      lastName: "Агент",
      username: "test_agent",
      preview: false,
    });
  });

  it("rejects tampered user data and malformed hashes", () => {
    const tampered = new URLSearchParams(makeInitData(now));
    tampered.set("user", JSON.stringify({ id: 999, first_name: "Інший" }));
    expect(verifyTelegramInitData(tampered.toString(), botToken, now)).toBeNull();
    expect(verifyTelegramInitData("auth_date=1900000000&user=%7B%7D&hash=bad", botToken, now)).toBeNull();
  });

  it("rejects stale and implausibly future-dated sessions", () => {
    expect(verifyTelegramInitData(makeInitData(now - 86_401), botToken, now)).toBeNull();
    expect(verifyTelegramInitData(makeInitData(now + 31), botToken, now)).toBeNull();
  });

  it("rejects oversized initData and invalid Telegram user IDs", () => {
    expect(verifyTelegramInitData("x".repeat(8193), botToken, now)).toBeNull();
    const invalidUser = makeInitData(now).replace("424242", "0");
    expect(verifyTelegramInitData(invalidUser, botToken, now)).toBeNull();
  });
});

describe("secret-word catalog", () => {
  it("contains at least 100 distinct Ukrainian secret choices", () => {
    expect(SECRET_WORDS.length).toBeGreaterThanOrEqual(100);
    expect(new Set(SECRET_WORDS).size).toBe(SECRET_WORDS.length);
  });
});
