import { describe, expect, it } from "vitest";
import { calculateBlackjackBankPayouts, calculatePayouts } from "./payouts";

describe("calculatePayouts", () => {
  it("awards the full pot to a sole winner", () => expect(calculatePayouts({ playerIds:["a","b"], contributions:{a:50,b:50}, outcome:{winnerIds:["a"],draw:false,reason:"win"} })).toEqual({a:100,b:0}));
  it("splits multi-winner pool and deterministically assigns remainder", () => expect(calculatePayouts({ playerIds:["a","b","c"], contributions:{a:10,b:10,c:11}, outcome:{winnerIds:["a","b"],draw:false,reason:"win"} })).toEqual({a:16,b:15,c:0}));
  it("returns all stakes on draw", () => expect(calculatePayouts({ playerIds:["a","b"], contributions:{a:10,b:15}, outcome:{winnerIds:[],draw:true,reason:"draw"} })).toEqual({a:10,b:15}));
  it("refunds push ids before splitting remaining losing pool", () => expect(calculatePayouts({ playerIds:["a","b","c"], contributions:{a:10,b:20,c:30}, outcome:{winnerIds:["a"],refundIds:["b"],draw:false,reason:"push"} })).toEqual({a:40,b:20,c:0}));
  it("uses relative winner weights and conserves the whole peer pot", () => { const p=calculatePayouts({playerIds:["a","b","c"],contributions:{a:10,b:10,c:10},outcome:{winnerIds:["a","b"],winnerWeights:{a:1.5,b:1},draw:false,reason:"win"}}); expect(p).toEqual({a:16,b:14,c:0}); expect(Object.values(p).reduce((x,y)=>x+y,0)).toBe(30); });
  it("conserves exact pot with weights and odd remainders", () => { const p=calculatePayouts({playerIds:["z","b","a"],contributions:{a:2,b:2,z:1},outcome:{winnerIds:["a","b"],draw:false,reason:"win"}}); expect(p).toEqual({a:3,b:2,z:0}); expect(Object.values(p).reduce((x,y)=>x+y,0)).toBe(5); });
});

describe("calculateBlackjackBankPayouts", () => {
  it("pays a natural's exact 3:2 profit target and retains unclaimed real bank funds", () => {
    const result = calculateBlackjackBankPayouts({
      playerIds: ["a", "b", "c", "d"],
      contributions: { a: 10, b: 10, c: 10, d: 10 },
      bankBalance: 0,
      outcome: { winnerIds: ["a"], payoutMultipliers: { a: 2.5 }, draw: false, reason: "natural" },
    });
    expect(result.targetPayouts.a).toBe(25);
    expect(result.payouts).toEqual({ a: 25, b: 0, c: 0, d: 0 });
    expect(result.bankBalanceAfter).toBe(15);
    expect(result.bankCapped).toBe(false);
    expect(Object.values(result.payouts).reduce((s, n) => s + n, 0) + result.bankBalanceAfter).toBe(result.bankBalanceBefore + result.totalPot);
  });

  it("caps a natural to the actual available bank when it is too small", () => {
    const result = calculateBlackjackBankPayouts({
      playerIds: ["a", "b"],
      contributions: { a: 10, b: 10 },
      bankBalance: 0,
      outcome: { winnerIds: ["a"], payoutMultipliers: { a: 2.5 }, draw: false, reason: "natural" },
    });
    expect(result.targetPayouts.a).toBe(25);
    expect(result.payouts).toEqual({ a: 20, b: 0 });
    expect(result.bankBalanceAfter).toBe(0);
    expect(result.bankCapped).toBe(true);
  });

  it("proportionally caps multiple winner claims with deterministic rounding", () => {
    const result = calculateBlackjackBankPayouts({
      playerIds: ["a", "b", "c"],
      contributions: { a: 10, b: 10, c: 10 },
      bankBalance: 0,
      outcome: { winnerIds: ["a", "b"], payoutMultipliers: { a: 2.5, b: 2 }, draw: false, reason: "win" },
    });
    expect(result.targetPayouts).toEqual({ a: 25, b: 20, c: 0 });
    expect(result.payouts).toEqual({ a: 17, b: 13, c: 0 });
    expect(result.bankBalanceAfter).toBe(0);
    expect(result.bankCapped).toBe(true);
  });

  it("protects Push refunds before capping winner claims", () => {
    const result = calculateBlackjackBankPayouts({
      playerIds: ["a", "b", "c"],
      contributions: { a: 10, b: 10, c: 10 },
      bankBalance: 0,
      outcome: { winnerIds: ["a"], refundIds: ["b"], payoutMultipliers: { a: 2.5 }, draw: false, reason: "push" },
    });
    expect(result.payouts).toEqual({ a: 20, b: 10, c: 0 });
    expect(result.bankCapped).toBe(true);
    expect(result.bankBalanceAfter).toBe(0);
  });

  it("returns every stake on the explicit all-lose refund and does not consume the bank", () => {
    const result = calculateBlackjackBankPayouts({
      playerIds: ["a", "b"],
      contributions: { a: 10, b: 20 },
      bankBalance: 7,
      outcome: { winnerIds: [], refundIds: ["a", "b"], draw: true, reason: "all lose" },
    });
    expect(result.payouts).toEqual({ a: 10, b: 20 });
    expect(result.bankBalanceAfter).toBe(7);
    expect(result.bankCapped).toBe(false);
  });

  it("refunds only Push players when other hands lose and credits those losses to the bank", () => {
    const result = calculateBlackjackBankPayouts({
      playerIds: ["a", "b"],
      contributions: { a: 10, b: 10 },
      bankBalance: 0,
      outcome: { winnerIds: [], refundIds: ["a"], draw: false, reason: "push and loss" },
    });
    expect(result.payouts).toEqual({ a: 10, b: 0 });
    expect(result.bankBalanceAfter).toBe(10);
    expect(result.bankBalanceAfter + Object.values(result.payouts).reduce((s, n) => s + n, 0)).toBe(result.availableBank);
  });
});

describe("applyArcadeVipCommission", () => {
  it("deducts ten percent from non-VIP winner receipts and exempts active VIPs", async () => {
    const { applyArcadeVipCommission } = await import("./payouts");
    expect(applyArcadeVipCommission({ a: 100, b: 50, c: 0 }, ["a", "b"], { a: true, b: false })).toEqual({
      payouts: { a: 100, b: 45, c: 0 },
      commissions: { a: 0, b: 5 },
      totalCommission: 5,
    });
  });
});
