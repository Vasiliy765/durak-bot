import { and, count, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { randomInt, randomUUID } from "node:crypto";
import { Router, type Request, type Response, type NextFunction, type RequestHandler } from "express";
import { getDb } from "../db";
import { spyCategories, spyGameConfig, spyGames, spyLocations, spyProfiles, spyRooms, spySystemErrors, spyWallets, type SpyProfile, type SpyRoom } from "../../drizzle/schema";
import { identityFromRequest, type GameIdentity } from "./auth";
import { LOCATION_CATALOG, LOCATION_CATEGORIES } from "./catalog";
import { SECRET_WORDS } from "./secretWords";
import { listEquippedCosmetics, syncTelegramProfile } from "./economy";
import { buildTelegramInviteLink, notifyRoomEventOnce, notifyRoomPlayers } from "./telegramBot";
import { updateProfilesForResult } from "./resultService";

const api = Router();
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const MINUTE = 60_000;
const GAME_CONFIG_DEFAULTS = { voteSeconds: 45, xpParticipation: 25, xpWin: 35 } as const;

type GameStatus = "lobby" | "playing" | "voting" | "spy_guess" | "finished";
type PlayerState = GameIdentity & { ready: boolean; online: boolean; role?: "spy" | "civilian"; lastSeenAt?: number };
type QuestionState = { id: string; from: string; fromName: string; to: string; toName: string; text: string; answer?: string; answeredBy?: string; createdAt: number };
type MessageState = { id: string; from: string; fromName: string; text: string; createdAt: number };
type GameState = {
  players: PlayerState[];
  status: GameStatus;
  location?: string;
  category?: string;
  votes: Record<string, string>;
  questions: QuestionState[];
  messages: MessageState[];
  startedAt?: number;
  activePlayerId?: string;
  roundEndsAt?: number;
  votingEndsAt?: number;
  autoVoting?: boolean;
  spyGuessTarget?: string;
  roundId?: string;
  winner?: "spies" | "civilians";
  reason?: string;
  secretKind?: "location" | "word";
};
type RoomSettings = {
  name: string;
  maxPlayers: number;
  spyCount: number;
  durationMinutes: number;
  allowRejoin: boolean;
  isPrivate: boolean;
  categories: string[];
  mode: string;
};
type PublicPlayer = { id: string; firstName: string; lastName?: string; username?: string; avatarUrl?: string; ready: boolean; online: boolean; vip?: boolean; role?: "spy" | "civilian" };
type AuthRequest = Request & { gameIdentity?: GameIdentity };
type ProfileRow = SpyProfile & { winRate?: number };

function participantIds(state: GameState) { return state.players.map(player => player.id); }
function announceVoting(room: SpyRoom, state: GameState) {
  void notifyRoomEventOnce(`vote:${state.roundId}:${state.votingEndsAt}`, participantIds(state), `У кімнаті ${room.code} розпочалося голосування. Відкрийте ШПИГУН, щоб віддати голос.`, room.code);
}
function announceResult(room: SpyRoom, state: GameState) {
  const winner = state.winner === "spies" ? "шпигуни" : "агенти";
  const secretLabel = room.mode === "secret_word" ? "Слово" : "Локація";
  void notifyRoomEventOnce(`result:${state.roundId}`, participantIds(state), `Операцію ${room.code} завершено. Перемогли ${winner}. ${secretLabel}: ${state.location || "невідомо"}. ${state.reason || ""}`, room.code);
}
function announceSpyGuess(room: SpyRoom, state: GameState) {
  const target = state.players.find(player => player.id === state.spyGuessTarget);
  const secretLabel = room.mode === "secret_word" ? "слово" : "локацію";
  void notifyRoomEventOnce(`spy-guess:${state.roundId}`, participantIds(state), `У кімнаті ${room.code} шпигуна викрито. ${target?.firstName || "Шпигун"} має останній шанс вгадати ${secretLabel}.`, room.code);
}

class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
function fail(status: number, message: string): never { throw new ApiError(status, message); }
const asyncRoute = (handler: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => { void handler(req, res, next).catch(next); };

async function database() {
  const db = await getDb();
  if (!db) throw new ApiError(503, "Ігрова база даних тимчасово недоступна.");
  return db;
}

async function getCategories(activeOnly = true) {
  const db = await database();
  const rows = activeOnly
    ? await db.select().from(spyCategories).where(eq(spyCategories.active, true)).orderBy(spyCategories.name)
    : await db.select().from(spyCategories).orderBy(spyCategories.name);
  return rows;
}

async function getGameConfig() {
  const db = await database();
  const rows = await db.select().from(spyGameConfig);
  const config: { voteSeconds: number; xpParticipation: number; xpWin: number } = { ...GAME_CONFIG_DEFAULTS };
  for (const row of rows) {
    if (row.key in config) {
      const key = row.key as keyof typeof GAME_CONFIG_DEFAULTS;
      const value = Number(row.value);
      if (Number.isFinite(value)) config[key] = value;
    }
  }
  return config;
}

let catalogSeed: Promise<void> | undefined;
async function ensureLocationCatalog() {
  if (!catalogSeed) catalogSeed = (async () => {
    const db = await database();
    const existingCategories = await db.select({ id: spyCategories.id }).from(spyCategories).limit(1);
    if (existingCategories.length === 0) {
      await db.insert(spyCategories).values(LOCATION_CATEGORIES.map(name => ({ name, active: true }))).onDuplicateKeyUpdate({ set: { active: sql`VALUES(active)` } });
    }
    const existing = await db.select({ id: spyLocations.id }).from(spyLocations).limit(1);
    if (existing.length === 0) {
      await db.insert(spyLocations).values(LOCATION_CATALOG).onDuplicateKeyUpdate({ set: { category: sql`VALUES(category)` } });
    }
  })().catch(error => { catalogSeed = undefined; throw error; });
  return catalogSeed;
}

function toPlayerState(identity: GameIdentity, ready = false): PlayerState {
  return { ...identity, ready, online: true, lastSeenAt: Date.now() };
}

async function upsertProfile(identity: GameIdentity) {
  const db = await database();
  const rows = await db.select().from(spyProfiles).where(eq(spyProfiles.telegramId, identity.id)).limit(1);
  if (rows[0]?.blocked) fail(403, "Доступ до гри обмежено.");
  if (rows.length) {
    const current = rows[0];
    const avatarUrl = identity.avatarUrl?.trim();
    const next = {
      firstName: identity.firstName,
      lastName: identity.lastName ?? null,
      username: identity.username ?? null,
      ...(avatarUrl ? { avatarUrl: avatarUrl.slice(0, 2048) } : {}),
    };
    if (current.firstName !== next.firstName || current.lastName !== next.lastName || current.username !== next.username || (avatarUrl && current.avatarUrl !== next.avatarUrl)) {
      await db.update(spyProfiles).set(next).where(eq(spyProfiles.telegramId, identity.id));
    }
    return { ...rows[0], firstName: identity.firstName, lastName: identity.lastName ?? null, username: identity.username ?? null, ...(avatarUrl ? { avatarUrl: avatarUrl.slice(0, 2048) } : {}) };
  }
  const avatarUrl = identity.avatarUrl?.trim();
  const profile = {
    telegramId: identity.id,
    firstName: identity.firstName,
    lastName: identity.lastName ?? null,
    username: identity.username ?? null,
    avatarUrl: avatarUrl ? avatarUrl.slice(0, 2048) : null,
    gamesPlayed: 0, wins: 0, losses: 0, spyWins: 0, civilianWins: 0,
    rating: 1000, xp: 0, winStreak: 0, bestStreak: 0, spiesCaught: 0, achievements: [], blocked: false,
  };
  await db.insert(spyProfiles).values(profile);
  return profile;
}

function identity(req: Request) {
  const value = (req as AuthRequest).gameIdentity;
  if (!value) throw new ApiError(401, "Відкрийте гру через Telegram або оновіть сторінку.");
  return value;
}

function profileView(row: ProfileRow, includeTelegramId = false) {
  return {
    ...(includeTelegramId ? { telegramId: row.telegramId } : {}),
    firstName: row.firstName,
    lastName: row.lastName,
    username: row.username,
    avatarUrl: row.avatarUrl,
    gamesPlayed: row.gamesPlayed,
    wins: row.wins,
    losses: row.losses,
    spyWins: row.spyWins,
    civilianWins: row.civilianWins,
    rating: row.rating,
    xp: row.xp,
    winStreak: row.winStreak,
    bestStreak: row.bestStreak,
    achievements: row.achievements ?? [],
    winRate: row.gamesPlayed ? Math.round(row.wins / row.gamesPlayed * 100) : 0,
    level: Math.floor((row.xp ?? 0) / 250) + 1,
  };
}

function roomSettings(room: SpyRoom): RoomSettings {
  return {
    name: room.name,
    maxPlayers: room.maxPlayers,
    spyCount: room.spyCount,
    durationMinutes: room.durationMinutes,
    allowRejoin: room.allowRejoin,
    isPrivate: room.isPrivate,
    categories: room.categories ?? [],
    mode: room.mode,
  };
}

function readState(room: SpyRoom): GameState {
  const raw = room.state as unknown;
  const state = typeof raw === "string" ? JSON.parse(raw) as GameState : raw as GameState;
  if (!state || !Array.isArray(state.players)) fail(500, "Стан кімнати пошкоджений.");
  state.votes ??= {};
  state.questions ??= [];
  state.messages ??= [];
  return state;
}

async function toPublicRoom(room: SpyRoom, state: GameState, viewerId: string) {
  const me = state.players.find(player => player.id === viewerId);
  if (!me) throw new ApiError(403, "Ви не є учасником цієї кімнати.");
  const finished = state.status === "finished";
  const db = await database();
  const vipWallets = state.players.length ? await db.select({ telegramId: spyWallets.telegramId, vipUntil: spyWallets.vipUntil }).from(spyWallets).where(inArray(spyWallets.telegramId, state.players.map(player => player.id))) : [];
  const vipIds = new Set(vipWallets.filter((wallet: any) => wallet.vipUntil && new Date(wallet.vipUntil).getTime() > Date.now()).map((wallet: any) => wallet.telegramId));
  const players: PublicPlayer[] = state.players.map(player => ({
    id: player.id,
    firstName: player.firstName,
    lastName: player.lastName,
    username: player.username,
    avatarUrl: player.avatarUrl,
    ready: player.ready,
    online: player.online,
    vip: vipIds.has(player.id),
    ...(finished || player.id === viewerId ? { role: player.role } : {}),
  }));
  const result = finished ? {
    winner: state.winner!,
    location: state.location!,
    reason: state.reason || "Раунд завершено.",
    message: state.winner === "spies" ? "Шпигуни перехитрили агентів." : "Агенти викрили шпигуна.",
    participants: players,
  } : undefined;
  const votes = Object.values(state.votes);
  const spyTarget = state.spyGuessTarget ? state.players.find(player => player.id === state.spyGuessTarget) : undefined;
  return {
    code: room.code,
    name: room.name,
    ownerId: room.ownerId,
    settings: roomSettings(room),
    status: state.status,
    players,
    yourRole: me.role,
    // A spy's JSON response never contains the secret location or its category.
    ...(me.role === "spy" && !finished ? {} : { location: state.location, categories: state.category ? [state.category] : undefined }),
    startedAt: state.startedAt,
    secretKind: state.secretKind || "location",
    activePlayerId: state.activePlayerId,
    roundEndsAt: state.roundEndsAt,
    votingEndsAt: state.votingEndsAt,
    questions: state.questions,
    messages: state.messages,
    votesCast: votes.length,
    youVoted: Object.hasOwn(state.votes, viewerId),
    yourVote: state.votes[viewerId],
    spyGuessTargetId: state.spyGuessTarget,
    suspectedName: spyTarget?.firstName,
    result,
    roundId: state.roundId,
  };
}

async function findRoom(code: string) {
  const db = await database();
  const normalized = code.trim().toUpperCase();
  const rows = await db.select().from(spyRooms).where(eq(spyRooms.code, normalized)).limit(1);
  if (!rows[0]) throw new ApiError(404, "Кімнату не знайдено. Перевірте код запрошення.");
  return rows[0];
}

async function loadRoomView(code: string, identityId: string) {
  const db = await database();
  let room = await findRoom(code);
  let state = readState(room);
  const now = Date.now();
  const currentPlayer = state.players.find(player => player.id === identityId);
  if (!currentPlayer) fail(403, "Ви не є учасником цієї кімнати.");
  let presenceChanged = false;
  for (const player of state.players) {
    if (player.online && player.lastSeenAt && now - player.lastSeenAt > 20_000) {
      player.online = false;
      presenceChanged = true;
    }
  }
  if (!currentPlayer.online && !room.allowRejoin) fail(403, "Повторне приєднання до цієї кімнати заборонене.");
  if (!currentPlayer.online || !currentPlayer.lastSeenAt || now - currentPlayer.lastSeenAt >= 10_000) {
    currentPlayer.online = true;
    currentPlayer.lastSeenAt = now;
    presenceChanged = true;
  }
  if (presenceChanged) {
    await db.update(spyRooms).set({ state, version: room.version + 1 }).where(and(eq(spyRooms.id, room.id), eq(spyRooms.version, room.version)));
    room = await findRoom(code);
    state = readState(room);
  }
  if (state.status === "playing" && state.roundEndsAt && Date.now() >= state.roundEndsAt) {
    const config = await getGameConfig();
    await db.update(spyRooms).set({ status: "voting", state: { ...state, status: "voting", votingEndsAt: Date.now() + config.voteSeconds * 1000, autoVoting: true, votes: {} }, version: room.version + 1 })
      .where(and(eq(spyRooms.id, room.id), eq(spyRooms.version, room.version)));
    const updated = await findRoom(code);
    state = readState(updated);
    if (state.status === "voting") announceVoting(updated, state);
    return toPublicRoom(updated, state, identityId);
  }
  if (state.status === "voting" && state.votingEndsAt && Date.now() >= state.votingEndsAt) {
    const updated = await concludeTimedVote(room, state, true);
    if (updated.state.status === "finished") announceResult(updated.room, updated.state);
    return toPublicRoom(updated.room, updated.state, identityId);
  }
  return toPublicRoom(room, state, identityId);
}

async function finishRound(tx: any, room: SpyRoom, state: GameState, winner: "spies" | "civilians", reason: string) {
  if (state.status === "finished") return state;
  const gameConfig = await getGameConfig();
  const endedAt = Date.now();
  state.roundId ||= randomUUID();
  state.status = "finished";
  state.winner = winner;
  state.reason = reason;
  state.roundEndsAt = endedAt;
  state.votingEndsAt = undefined;
  const participants = state.players.map(player => ({
    id: player.id,
    name: [player.firstName, player.lastName].filter(Boolean).join(" ") || player.firstName,
    role: player.role || "civilian" as const,
    votedForSpy: player.role === "civilian" && state.votes[player.id] !== undefined && state.players.find(target => target.id === state.votes[player.id])?.role === "spy",
  }));
  const durationSeconds = state.startedAt ? Math.max(0, Math.floor((endedAt - state.startedAt) / 1000)) : 0;
  await tx.update(spyRooms).set({ status: "finished", state, version: room.version + 1 }).where(eq(spyRooms.id, room.id));
  await tx.insert(spyGames).values({
    roundId: state.roundId, roomCode: room.code, roomName: room.name, mode: room.mode,
    winner, location: state.location || "Невідома локація", participants, durationSeconds,
  }).onDuplicateKeyUpdate({ set: { winner, location: state.location || "Невідома локація", participants, durationSeconds } });
  await updateProfilesForResult(tx, {
    roundId: state.roundId,
    winner,
    players: state.players.map(player => ({ id: player.id, firstName: player.firstName, lastName: player.lastName, role: player.role || "civilian" })),
    durationSeconds,
    xpParticipation: gameConfig.xpParticipation,
    xpWin: gameConfig.xpWin,
  });
  return state;
}

async function concludeTimedVote(room: SpyRoom, state: GameState, timedOut: boolean) {
  const db = await database();
  const result = await db.transaction(async (tx: any) => {
    const rows = await tx.select().from(spyRooms).where(eq(spyRooms.code, room.code)).limit(1).for("update");
    const currentRoom = rows[0] as SpyRoom | undefined;
    if (!currentRoom) throw new ApiError(404, "Кімнату не знайдено.");
    const current = readState(currentRoom);
    if (current.status !== "voting") return { room: currentRoom, state: current };
    if (current.votingEndsAt && Date.now() < current.votingEndsAt) return { room: currentRoom, state: current };
    const tally = new Map<string, number>();
    Object.values(current.votes).forEach(target => tally.set(target, (tally.get(target) || 0) + 1));
    const ordered = [...tally.entries()].sort((a, b) => b[1] - a[1]);
    const hasStrictMajority = ordered.length > 0 && ordered[0][1] > current.players.length / 2 && (ordered.length === 1 || ordered[0][1] > ordered[1][1]);
    if (hasStrictMajority) {
      const suspected = current.players.find(player => player.id === ordered[0][0]);
      if (suspected?.role === "spy") {
        current.status = "spy_guess";
        current.spyGuessTarget = suspected.id;
        current.votingEndsAt = undefined;
        await tx.update(spyRooms).set({ status: "spy_guess", state: current, version: currentRoom.version + 1 }).where(eq(spyRooms.id, currentRoom.id));
        return { room: { ...currentRoom, status: "spy_guess" as const, state: current, version: currentRoom.version + 1 }, state: current };
      }
      await finishRound(tx, currentRoom, current, "spies", "Гравці більшістю помилково звинуватили мирного агента.");
      return { room: { ...currentRoom, status: "finished" as const, state: current, version: currentRoom.version + 1 }, state: current };
    }
    if (current.autoVoting || timedOut) {
      await finishRound(tx, currentRoom, current, "spies", "Час сплив, а агенти не змогли більшістю викрити шпигуна.");
      return { room: { ...currentRoom, status: "finished" as const, state: current, version: currentRoom.version + 1 }, state: current };
    }
    current.status = "playing";
    current.roundEndsAt = Date.now() + 2 * MINUTE;
    current.votingEndsAt = undefined;
    current.votes = {};
    await tx.update(spyRooms).set({ status: "playing", state: current, version: currentRoom.version + 1 }).where(eq(spyRooms.id, currentRoom.id));
    return { room: { ...currentRoom, status: "playing" as const, state: current, version: currentRoom.version + 1 }, state: current };
  });
  if (result.state.status === "finished") announceResult(result.room, result.state);
  else if (result.state.status === "spy_guess") announceSpyGuess(result.room, result.state);
  return result;
}

async function mutateRoom(code: string, change: (tx: any, room: SpyRoom, state: GameState) => Promise<GameState> | GameState) {
  const db = await database();
  return db.transaction(async (tx: any) => {
    const rows = await tx.select().from(spyRooms).where(eq(spyRooms.code, code.toUpperCase())).limit(1).for("update");
    const room = rows[0] as SpyRoom | undefined;
    if (!room) throw new ApiError(404, "Кімнату не знайдено.");
    const state = await change(tx, room, readState(room));
    await tx.update(spyRooms).set({ status: state.status, state, version: room.version + 1 }).where(eq(spyRooms.id, room.id));
    const fresh = { ...room, status: state.status, state, version: room.version + 1 } as SpyRoom;
    return { room: fresh, state };
  });
}

function requireMember(state: GameState, userId: string) {
  const member = state.players.find(player => player.id === userId);
  if (!member) throw new ApiError(403, "Спочатку приєднайтеся до кімнати.");
  return member;
}
function requireHost(room: SpyRoom, userId: string) {
  if (room.ownerId !== userId) fail(403, "Ця дія доступна лише власнику кімнати.");
}
function chooseCode() {
  return Array.from({ length: 6 }, () => CODE_ALPHABET[randomInt(CODE_ALPHABET.length)]).join("");
}
async function validatedSettings(input: any): Promise<RoomSettings> {
  const name = typeof input?.name === "string" ? input.name.trim().slice(0, 100) : "";
  const maxPlayers = Number(input?.maxPlayers);
  const spyCount = Number(input?.spyCount);
  const durationMinutes = Number(input?.durationMinutes);
  const mode = input?.mode === "secret_word" ? "secret_word" : input?.mode === "spyfall" || input?.mode === undefined ? "spyfall" : "";
  const availableCategories = (await getCategories()).map(category => category.name);
  const categories: string[] = [];
  if (Array.isArray(input?.categories)) {
    for (const item of input.categories as unknown[]) {
      if (typeof item === "string" && availableCategories.includes(item) && !categories.includes(item)) categories.push(item);
    }
  }
  if (name.length < 2) fail(400, "Назва кімнати має містити щонайменше 2 символи.");
  if (!Number.isInteger(maxPlayers) || maxPlayers < 3 || maxPlayers > 12) fail(400, "У кімнаті може бути від 3 до 12 гравців.");
  if (!Number.isInteger(spyCount) || spyCount < 1 || spyCount > 3 || spyCount >= maxPlayers) fail(400, "Оберіть від 1 до 3 шпигунів, менше ніж кількість місць.");
  if (![5, 7, 10, 15].includes(durationMinutes)) fail(400, "Тривалість раунду: 5, 7, 10 або 15 хвилин.");
  if (!mode) fail(400, "Оберіть доступний режим гри.");
  return {
    name,
    maxPlayers,
    spyCount,
    durationMinutes,
    allowRejoin: input.allowRejoin !== false,
    isPrivate: input.isPrivate !== false,
    categories,
    mode,
  };
}

function isAdmin(user: GameIdentity) {
  const configured = (process.env.ADMIN_IDS || process.env.SPY_ADMIN_IDS || "").split(/[ ,]+/).map(value => value.trim()).filter(Boolean);
  return configured.includes(user.id);
}

api.use(asyncRoute(async (req, res, next) => {
  const user = identityFromRequest(req);
  if (!user) return res.status(401).json({ error: process.env.TELEGRAM_BOT_TOKEN ? "Не вдалося перевірити Telegram-сеанс. Відкрийте гру повторно через бота." : "Telegram-бот ще не налаштований для production." });
  await ensureLocationCatalog();
  await upsertProfile(user);
  await syncTelegramProfile(user);
  (req as AuthRequest).gameIdentity = user;
  res.setHeader("Cache-Control", "no-store, private");
  next();
}));

api.get("/session", asyncRoute(async (req, res) => {
  const user = identity(req);
  const db = await database();
  const [rows, active, locations, walletRows] = await Promise.all([
    db.select().from(spyProfiles).where(eq(spyProfiles.telegramId, user.id)).limit(1),
    db.select({ id: spyRooms.id }).from(spyRooms).where(inArray(spyRooms.status, ["lobby", "playing", "voting", "spy_guess"])).limit(1),
    db.select({ id: spyLocations.id }).from(spyLocations).where(eq(spyLocations.active, true)),
    db.select({ vipUntil: spyWallets.vipUntil }).from(spyWallets).where(eq(spyWallets.telegramId, user.id)).limit(1),
  ]);
  const equippedCosmetics = await listEquippedCosmetics(user.id);
  const vipUntil = walletRows[0]?.vipUntil || null;
  return res.json({ player: { ...profileView(rows[0] as ProfileRow, true), vip: !!vipUntil && new Date(vipUntil).getTime() > Date.now(), vipUntil, equippedCosmetics }, admin: isAdmin(user), preview: user.preview, categories: (await getCategories()).map(category => category.name), locationCount: locations.length, hasActiveRoom: active.length > 0 });
}));

api.get("/rooms", asyncRoute(async (req, res) => {
  const db = await database();
  if (req.query.public === "1") {
    const rooms = await db.select().from(spyRooms).where(and(eq(spyRooms.isPrivate, false), eq(spyRooms.status, "lobby"))).orderBy(desc(spyRooms.createdAt)).limit(30);
    return res.json({ rooms: rooms.map(room => ({ code: room.code, name: room.name, count: readState(room).players.length, maxPlayers: room.maxPlayers })) });
  }
  return res.json({ rooms: [] });
}));

api.post("/rooms", asyncRoute(async (req, res) => {
  const user = identity(req);
  const settings = await validatedSettings(req.body);
  const db = await database();
  const player = toPlayerState(user, true);
  const state: GameState = { players: [player], status: "lobby", votes: {}, questions: [], messages: [] };
  for (let attempt = 0; attempt < 8; attempt++) {
    const code = chooseCode();
    try {
      await db.insert(spyRooms).values({ code, name: settings.name, ownerId: user.id, isPrivate: settings.isPrivate, maxPlayers: settings.maxPlayers, spyCount: settings.spyCount, durationMinutes: settings.durationMinutes, allowRejoin: settings.allowRejoin, categories: settings.categories, mode: settings.mode, status: "lobby", state, version: 1 });
      const room = await findRoom(code);
      return res.status(201).json({ room: await toPublicRoom(room, state, user.id), inviteCode: code });
    } catch (error) {
      const codeValue = (error as { code?: string })?.code;
      if (codeValue !== "ER_DUP_ENTRY" && !(error instanceof Error && /duplicate/i.test(error.message))) throw error;
    }
  }
  fail(503, "Не вдалося зарезервувати унікальний код кімнати. Спробуйте ще раз.");
}));

api.get("/rooms/:code", asyncRoute(async (req, res) => {
  const user = identity(req);
  const room = await findRoom(req.params.code);
  const state = readState(room);
  if (!state.players.some(player => player.id === user.id)) fail(403, "Приєднайтеся до кімнати, щоб переглянути гру.");
  return res.json({ room: await loadRoomView(room.code, user.id) });
}));

api.post("/rooms/:code/join", asyncRoute(async (req, res) => {
  const user = identity(req);
  let joined = false;
  const { room, state } = await mutateRoom(req.params.code, (_tx, room, state) => {
    const existing = state.players.find(player => player.id === user.id);
    if (existing) {
      if (existing.lastSeenAt && Date.now() - existing.lastSeenAt > 20_000) existing.online = false;
      if (!existing.online && !room.allowRejoin) fail(403, "Повторне приєднання до цієї кімнати заборонене.");
      existing.online = true;
      existing.lastSeenAt = Date.now();
      return state;
    }
    if (state.status !== "lobby") fail(409, "Раунд уже розпочався. Приєднання закрито.");
    if (state.players.length >= room.maxPlayers) fail(409, "У кімнаті вже немає вільних місць.");
    state.players.push(toPlayerState(user));
    joined = true;
    return state;
  });
  if (joined) void notifyRoomPlayers(state.players.filter(player => player.id !== user.id).map(player => player.id), `${user.firstName} приєднався до кімнати ${room.code}.`, room.code);
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.get("/rooms/:code/invite", asyncRoute(async (req, res) => {
  const user = identity(req);
  const room = await findRoom(req.params.code);
  requireMember(readState(room), user.id);
  return res.json({ inviteLink: buildTelegramInviteLink(room.code) });
}));

api.post("/rooms/:code/ready", asyncRoute(async (req, res) => {
  const user = identity(req);
  const { room, state } = await mutateRoom(req.params.code, (_tx, _room, state) => {
    if (state.status !== "lobby") fail(409, "Раунд уже розпочався.");
    const member = requireMember(state, user.id);
    member.ready = req.body?.ready !== false;
    return state;
  });
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.patch("/rooms/:code/settings", asyncRoute(async (req, res) => {
  const user = identity(req);
  const settings = await validatedSettings(req.body);
  const db = await database();
  const result = await db.transaction(async (tx: any) => {
    const rows = await tx.select().from(spyRooms).where(eq(spyRooms.code, req.params.code.toUpperCase())).limit(1).for("update");
    const room = rows[0] as SpyRoom | undefined;
    if (!room) fail(404, "Кімнату не знайдено.");
    requireHost(room, user.id);
    const state = readState(room);
    if (state.status !== "lobby") fail(409, "Налаштування можна змінювати лише в лобі.");
    if (state.players.length > settings.maxPlayers) fail(400, "Кількість місць не може бути меншою за склад команди.");
    await tx.update(spyRooms).set({ name: settings.name, maxPlayers: settings.maxPlayers, spyCount: settings.spyCount, durationMinutes: settings.durationMinutes, allowRejoin: settings.allowRejoin, isPrivate: settings.isPrivate, categories: settings.categories, version: room.version + 1 }).where(eq(spyRooms.id, room.id));
    return { room: { ...room, ...settings, status: state.status }, state };
  });
  return res.json({ room: await toPublicRoom(result.room as SpyRoom, result.state, user.id) });
}));

api.delete("/rooms/:code/players/:playerId", asyncRoute(async (req, res) => {
  const user = identity(req);
  const { room, state } = await mutateRoom(req.params.code, (_tx, room, state) => {
    requireHost(room, user.id);
    if (state.status !== "lobby") fail(409, "Гравця можна видалити лише до початку раунду.");
    if (req.params.playerId === room.ownerId) fail(400, "Власник кімнати не може видалити себе.");
    state.players = state.players.filter(player => player.id !== req.params.playerId);
    return state;
  });
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.post("/rooms/:code/leave", asyncRoute(async (req, res) => {
  const user = identity(req);
  const db = await database();
  await db.transaction(async (tx: any) => {
    const rows = await tx.select().from(spyRooms).where(eq(spyRooms.code, req.params.code.toUpperCase())).limit(1).for("update");
    const room = rows[0] as SpyRoom | undefined;
    if (!room) return;
    const state = readState(room);
    if (state.status === "lobby") {
      state.players = state.players.filter(player => player.id !== user.id);
      if (room.ownerId === user.id) {
        if (!state.players.length) {
          await tx.delete(spyRooms).where(eq(spyRooms.id, room.id));
          return;
        }
        await tx.update(spyRooms).set({ ownerId: state.players[0].id, state, version: room.version + 1 }).where(eq(spyRooms.id, room.id));
      } else {
        await tx.update(spyRooms).set({ state, version: room.version + 1 }).where(eq(spyRooms.id, room.id));
      }
    } else {
      const player = state.players.find(item => item.id === user.id);
      if (player) {
        player.online = false;
        await tx.update(spyRooms).set({ state, version: room.version + 1 }).where(eq(spyRooms.id, room.id));
      }
    }
  });
  return res.json({ success: true });
}));

api.post("/rooms/:code/start", asyncRoute(async (req, res) => {
  const user = identity(req);
  const db = await database();
  await ensureLocationCatalog();
  const room = await findRoom(req.params.code);
  const activeCategories = (await getCategories()).map(category => category.name);
  const categories = room.categories.length ? room.categories.filter(category => activeCategories.includes(category)) : activeCategories;
  if (room.mode !== "secret_word" && !categories.length) fail(400, "Для вибраних категорій немає активних категорій.");
  let secretValue: string;
  let secretCategory: string | undefined;
  let secretKind: "location" | "word" = "location";
  if (room.mode === "secret_word") {
    secretValue = SECRET_WORDS[randomInt(SECRET_WORDS.length)];
    secretKind = "word";
  } else {
    const available = await db.select().from(spyLocations).where(and(eq(spyLocations.active, true), inArray(spyLocations.category, categories)));
    if (!available.length) fail(400, "Для вибраних категорій немає доступних локацій.");
    const selected = available[randomInt(available.length)];
    secretValue = selected.name;
    secretCategory = selected.category;
  }
  const { room: updated, state } = await mutateRoom(req.params.code, (_tx, lockedRoom, state) => {
    requireHost(lockedRoom, user.id);
    if (state.status !== "lobby") fail(409, "Гра вже розпочалася.");
    if (lockedRoom.mode !== room.mode) fail(409, "Налаштування режиму змінилося. Спробуйте ще раз.");
    if (state.players.length < 3) fail(400, "Для початку гри потрібно щонайменше 3 гравці.");
    if (state.players.length > lockedRoom.maxPlayers) fail(400, "Кімната перевищує обмеження гравців.");
    if (state.players.filter(player => player.ready).length !== state.players.length) fail(400, "Дочекайтеся готовності кожного гравця.");
    if (lockedRoom.spyCount >= state.players.length) fail(400, "Шпигунів має бути менше, ніж гравців.");
    const shuffled = [...state.players];
    for (let i = shuffled.length - 1; i > 0; i--) { const j = randomInt(i + 1); [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]; }
    shuffled.forEach((player, index) => { player.role = index < lockedRoom.spyCount ? "spy" : "civilian"; });
    const started = Date.now();
    return { ...state, players: shuffled, status: "playing", location: secretValue, category: secretCategory, secretKind, votes: {}, questions: [], startedAt: started, activePlayerId: shuffled[0].id, roundEndsAt: started + lockedRoom.durationMinutes * MINUTE, roundId: randomUUID(), spyGuessTarget: undefined, winner: undefined, reason: undefined };
  });
  void notifyRoomEventOnce(`started:${state.roundId}`, participantIds(state), `Операція ${updated.code} почалася. Відкрийте Mini App, щоб переглянути своє особисте досьє.`, updated.code);
  return res.json({ room: await toPublicRoom(updated, state, user.id) });
}));

api.post("/rooms/:code/questions", asyncRoute(async (req, res) => {
  const user = identity(req);
  const text = typeof req.body?.text === "string" ? req.body.text.trim().slice(0, 280) : "";
  if (!text) fail(400, "Введіть запитання.");
  const { room, state } = await mutateRoom(req.params.code, (_tx, _room, state) => {
    if (state.status !== "playing") fail(409, "Запитання можна ставити під час раунду.");
    const from = requireMember(state, user.id);
    if (state.activePlayerId && state.activePlayerId !== from.id) fail(409, "Зараз хід іншого гравця.");
    const to = state.players.find(player => player.id === req.body?.to);
    if (!to || to.id === from.id) fail(400, "Оберіть іншого гравця.");
    state.questions.push({ id: randomUUID(), from: from.id, fromName: from.firstName, to: to.id, toName: to.firstName, text, createdAt: Date.now() });
    return state;
  });
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.post("/rooms/:code/questions/:questionId/answer", asyncRoute(async (req, res) => {
  const user = identity(req);
  const answer = typeof req.body?.answer === "string" ? req.body.answer.trim().slice(0, 280) : "";
  if (!answer) fail(400, "Введіть відповідь.");
  const { room, state } = await mutateRoom(req.params.code, (_tx, _room, state) => {
    if (state.status !== "playing") fail(409, "Відповіді приймаються під час раунду.");
    const member = requireMember(state, user.id);
    const question = state.questions.find(item => item.id === req.params.questionId);
    if (!question || question.to !== member.id) fail(403, "Відповісти може лише адресат запитання.");
    if (question.answer) fail(409, "На це запитання вже відповіли.");
  question.answer = answer;
  question.answeredBy = member.id;
  state.activePlayerId = member.id;
  return state;
  });
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.post("/rooms/:code/messages", asyncRoute(async (req, res) => {
  const user = identity(req);
  const text = typeof req.body?.text === "string" ? req.body.text.trim().slice(0, 280) : "";
  if (!text) fail(400, "Введіть повідомлення.");
  const { room, state } = await mutateRoom(req.params.code, (_tx, _room, state) => {
    if (state.status === "finished") fail(409, "Операцію завершено — чат закрито.");
    const sender = requireMember(state, user.id);
    state.messages.push({ id: randomUUID(), from: sender.id, fromName: sender.firstName, text, createdAt: Date.now() });
    if (state.messages.length > 200) state.messages.splice(0, state.messages.length - 200);
    return state;
  });
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.get("/locations/options", asyncRoute(async (req, res) => {
  if (req.query.mode === "secret_word") return res.json({ locations: [...SECRET_WORDS] });
  const db = await database();
  const locations = await db.select({ name: spyLocations.name }).from(spyLocations).where(eq(spyLocations.active, true)).orderBy(spyLocations.name);
  return res.json({ locations: locations.map(item => item.name) });
}));

api.post("/rooms/:code/vote/start", asyncRoute(async (req, res) => {
  const user = identity(req);
  const config = await getGameConfig();
  const { room, state } = await mutateRoom(req.params.code, (_tx, _room, state) => {
    requireMember(state, user.id);
    if (state.status !== "playing") fail(409, "Голосування вже триває або раунд завершено.");
    state.status = "voting";
    state.votes = {};
    state.autoVoting = false;
    state.votingEndsAt = Date.now() + config.voteSeconds * 1000;
    return state;
  });
  announceVoting(room, state);
  return res.json({ room: await toPublicRoom(room, state, user.id) });
}));

api.post("/rooms/:code/vote", asyncRoute(async (req, res) => {
  const user = identity(req);
  const targetId = typeof req.body?.targetId === "string" ? req.body.targetId : "";
  const outcome = await mutateRoom(req.params.code, async (tx, room, state) => {
    requireMember(state, user.id);
    if (state.status !== "voting") fail(409, "Зараз голосування не проводиться.");
    if (state.votingEndsAt && Date.now() >= state.votingEndsAt) fail(409, "Час голосування завершився.");
    if (Object.hasOwn(state.votes, user.id)) fail(409, "Ваш голос уже враховано.");
    if (!state.players.some(player => player.id === targetId) || targetId === user.id) fail(400, "Оберіть іншого гравця.");
    state.votes[user.id] = targetId;
    const tally = new Map<string, number>();
    Object.values(state.votes).forEach(id => tally.set(id, (tally.get(id) || 0) + 1));
    const ordered = [...tally.entries()].sort((a, b) => b[1] - a[1]);
    const majority = ordered.length && ordered[0][1] > state.players.length / 2 && (ordered.length === 1 || ordered[0][1] > ordered[1][1]);
    if (majority) {
      const suspect = state.players.find(player => player.id === ordered[0][0]);
      if (suspect?.role === "spy") {
        state.status = "spy_guess";
        state.spyGuessTarget = suspect.id;
        state.votingEndsAt = undefined;
      } else {
        await finishRound(tx, room, state, "spies", "Гравці більшістю помилково звинуватили мирного агента.");
      }
    } else if (Object.keys(state.votes).length === state.players.length) {
      if (state.autoVoting) await finishRound(tx, room, state, "spies", "Час сплив, а агенти не змогли більшістю викрити шпигуна.");
      else { state.status = "playing"; state.votes = {}; state.votingEndsAt = undefined; state.roundEndsAt = Date.now() + 2 * MINUTE; }
    }
    return state;
  });
  if (outcome.state.status === "spy_guess") announceSpyGuess(outcome.room, outcome.state);
  if (outcome.state.status === "finished") announceResult(outcome.room, outcome.state);
  const fresh = await findRoom(req.params.code);
  return res.json({ room: await toPublicRoom(fresh, outcome.state, user.id) });
}));

api.post("/rooms/:code/guess", asyncRoute(async (req, res) => {
  const user = identity(req);
  const secretGuess = typeof req.body?.secret === "string" ? req.body.secret.trim().slice(0, 140) : typeof req.body?.location === "string" ? req.body.location.trim().slice(0, 140) : "";
  if (!secretGuess) fail(400, "Введіть здогад.");
  const result = await mutateRoom(req.params.code, async (tx, room, state) => {
    const player = requireMember(state, user.id);
    if (state.status !== "spy_guess") fail(409, "Зараз шпигун не вгадує секрет.");
    if (player.role !== "spy" || player.id !== state.spyGuessTarget) fail(403, "Вгадати секрет може лише викритий шпигун.");
    const winner = secretGuess.toLocaleLowerCase("uk") === (state.location || "").toLocaleLowerCase("uk") ? "spies" : "civilians";
    const secretLabel = room.mode === "secret_word" ? "секретне слово" : "секретну локацію";
    await finishRound(tx, room, state, winner, winner === "spies" ? `Шпигун правильно вгадав ${secretLabel}.` : `Шпигун не вгадав ${secretLabel}.`);
    return state;
  });
  announceResult(result.room, result.state);
  const fresh = await findRoom(req.params.code);
  return res.json({ room: await toPublicRoom(fresh, result.state, user.id) });
}));

api.get("/leaderboard", asyncRoute(async (req, res) => {
  const db = await database();
  const sort = String(req.query.sort || "rating");
  const period = String(req.query.period || "all");
  const sortKey = sort === "wins" ? spyProfiles.wins : sort === "games" ? spyProfiles.gamesPlayed : spyProfiles.rating;
  if (period === "week" || period === "month") {
    const since = new Date(Date.now() - (period === "week" ? 7 : 30) * 24 * 60 * MINUTE);
    const games = await db.select().from(spyGames).where(gte(spyGames.createdAt, since)).orderBy(desc(spyGames.createdAt)).limit(2000);
    const aggregate = new Map<string, { games: number; wins: number }>();
    for (const game of games) for (const player of game.participants || []) {
      const entry = aggregate.get(player.id) || { games: 0, wins: 0 };
      entry.games++;
      if ((game.winner === "spies") === (player.role === "spy")) entry.wins++;
      aggregate.set(player.id, entry);
    }
    const ids = [...aggregate.keys()];
    const profiles = ids.length ? await db.select().from(spyProfiles).where(inArray(spyProfiles.telegramId, ids)) : [];
    const vipWallets = ids.length ? await db.select({ telegramId: spyWallets.telegramId, vipUntil: spyWallets.vipUntil }).from(spyWallets).where(inArray(spyWallets.telegramId, ids)) : [];
    const vipIds = new Set(vipWallets.filter((wallet: any) => wallet.vipUntil && new Date(wallet.vipUntil).getTime() > Date.now()).map((wallet: any) => wallet.telegramId));
    const sorted = profiles.map(profile => ({ ...profileView(profile), vip: vipIds.has(profile.telegramId), periodGames: aggregate.get(profile.telegramId)?.games ?? 0, periodWins: aggregate.get(profile.telegramId)?.wins ?? 0 }))
      .sort((a, b) => sort === "games" ? b.periodGames - a.periodGames : sort === "wins" ? b.periodWins - a.periodWins : b.rating - a.rating);
    return res.json({ players: sorted.slice(0, 50) });
  }
  const profiles = await db.select().from(spyProfiles).orderBy(desc(sortKey)).limit(50);
  const vipWallets = profiles.length ? await db.select({ telegramId: spyWallets.telegramId, vipUntil: spyWallets.vipUntil }).from(spyWallets).where(inArray(spyWallets.telegramId, profiles.map(profile => profile.telegramId))) : [];
  const vipIds = new Set(vipWallets.filter((wallet: any) => wallet.vipUntil && new Date(wallet.vipUntil).getTime() > Date.now()).map((wallet: any) => wallet.telegramId));
  return res.json({ players: profiles.map(profile => ({ ...profileView(profile as ProfileRow), vip: vipIds.has(profile.telegramId) })) });
}));

api.get("/profile/:id", asyncRoute(async (req, res) => {
  const user = identity(req);
  if (req.params.id !== user.id && !isAdmin(user)) fail(403, "Перегляд цього профілю недоступний.");
  const db = await database();
  const rows = await db.select().from(spyProfiles).where(eq(spyProfiles.telegramId, req.params.id)).limit(1);
  if (!rows[0]) fail(404, "Профіль не знайдено.");
  const wallet = (await db.select({ vipUntil: spyWallets.vipUntil }).from(spyWallets).where(eq(spyWallets.telegramId, req.params.id)).limit(1))[0];
  const vipUntil = wallet?.vipUntil || null;
  return res.json({ profile: { ...profileView(rows[0] as ProfileRow, true), vip: !!vipUntil && new Date(vipUntil).getTime() > Date.now(), vipUntil } });
}));

const adminRoute = (handler: (req: Request, res: Response) => Promise<unknown>): RequestHandler => asyncRoute(async (req, res) => {
  if (!isAdmin(identity(req))) fail(403, "Панель доступна лише адміністраторам.");
  return handler(req, res);
});
api.get("/admin/overview", adminRoute(async (_req, res) => {
  const db = await database();
  const [users, activeRooms, totalGames, games] = await Promise.all([
    db.select({ value: count() }).from(spyProfiles),
    db.select({ value: count() }).from(spyRooms).where(inArray(spyRooms.status, ["lobby", "playing", "voting", "spy_guess"])),
    db.select({ value: count() }).from(spyGames),
    db.select().from(spyGames).orderBy(desc(spyGames.createdAt)).limit(10),
  ]);
  return res.json({ users: Number(users[0]?.value || 0), activeRooms: Number(activeRooms[0]?.value || 0), gamesPlayed: Number(totalGames[0]?.value || 0), latestGames: games.map(game => ({ ...game, participants: game.participants?.length ?? 0 })) });
}));
api.get("/admin/players", adminRoute(async (_req, res) => {
  const db = await database();
  const players = await db.select().from(spyProfiles).orderBy(desc(spyProfiles.updatedAt)).limit(200);
  return res.json({ players: players.map(player => ({ ...profileView(player as ProfileRow, true), blocked: player.blocked })) });
}));
api.get("/admin/locations", adminRoute(async (_req, res) => {
  const db = await database();
  const [locations, categories] = await Promise.all([db.select().from(spyLocations).orderBy(spyLocations.category, spyLocations.name), getCategories(false)]);
  return res.json({ locations, categories });
}));
api.post("/admin/categories", adminRoute(async (req, res) => {
  const name = typeof req.body?.name === "string" ? req.body.name.trim().slice(0, 80) : "";
  if (name.length < 2) fail(400, "Назва категорії має містити щонайменше 2 символи.");
  const db = await database();
  if ((await db.select({ id: spyCategories.id }).from(spyCategories).where(eq(spyCategories.name, name)).limit(1)).length) fail(409, "Категорія з такою назвою вже існує.");
  await db.insert(spyCategories).values({ name, active: true });
  return res.status(201).json({ success: true });
}));
api.patch("/admin/categories/:id", adminRoute(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) fail(400, "Некоректний ID категорії.");
  const db = await database();
  await db.update(spyCategories).set({ active: req.body?.active !== false }).where(eq(spyCategories.id, id));
  return res.json({ success: true });
}));
api.post("/admin/locations", adminRoute(async (req, res) => {
  const name = typeof req.body?.name === "string" ? req.body.name.trim().slice(0, 140) : "";
  const category = typeof req.body?.category === "string" ? req.body.category : "";
  if (name.length < 2 || !(await getCategories()).some(item => item.name === category)) fail(400, "Вкажіть назву та активну категорію.");
  const db = await database();
  await db.insert(spyLocations).values({ name, category, active: true });
  return res.status(201).json({ success: true });
}));
api.patch("/admin/locations/:id", adminRoute(async (req, res) => {
  const db = await database();
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) fail(400, "Некоректний ID локації.");
  await db.update(spyLocations).set({ active: req.body?.active !== false }).where(eq(spyLocations.id, id));
  return res.json({ success: true });
}));
api.delete("/admin/locations/:id", adminRoute(async (req, res) => {
  const db = await database();
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) fail(400, "Некоректний ID локації.");
  await db.delete(spyLocations).where(eq(spyLocations.id, id));
  return res.json({ success: true });
}));
api.get("/admin/games", adminRoute(async (_req, res) => {
  const db = await database();
  const games = await db.select().from(spyGames).orderBy(desc(spyGames.createdAt)).limit(100);
  return res.json({ games });
}));
api.patch("/admin/players/:id/block", adminRoute(async (req, res) => {
  const db = await database();
  await db.update(spyProfiles).set({ blocked: req.body?.blocked !== false }).where(eq(spyProfiles.telegramId, req.params.id));
  return res.json({ success: true });
}));
api.get("/admin/settings", adminRoute(async (_req, res) => res.json({ settings: await getGameConfig() })));
api.patch("/admin/settings", adminRoute(async (req, res) => {
  const current = await getGameConfig();
  const next = { ...current };
  for (const key of ["voteSeconds", "xpParticipation", "xpWin"] as const) {
    if (req.body?.[key] !== undefined) next[key] = Number(req.body[key]);
  }
  if (!Number.isInteger(next.voteSeconds) || next.voteSeconds < 15 || next.voteSeconds > 120) fail(400, "Час голосування має бути від 15 до 120 секунд.");
  if (!Number.isInteger(next.xpParticipation) || next.xpParticipation < 5 || next.xpParticipation > 100) fail(400, "XP за участь має бути від 5 до 100.");
  if (!Number.isInteger(next.xpWin) || next.xpWin < 0 || next.xpWin > 100) fail(400, "Бонус XP за перемогу має бути від 0 до 100.");
  const db = await database();
  for (const key of ["voteSeconds", "xpParticipation", "xpWin"] as const) {
    await db.insert(spyGameConfig).values({ key, value: next[key] }).onDuplicateKeyUpdate({ set: { value: sql`VALUES(value)` } });
  }
  return res.json({ settings: next });
}));
api.get("/admin/errors", adminRoute(async (_req, res) => {
  const db = await database();
  const errors = await db.select().from(spySystemErrors).orderBy(desc(spySystemErrors.createdAt)).limit(100);
  return res.json({ errors });
}));

api.use((error: unknown, req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof ApiError) return res.status(error.status).json({ error: error.message });
  console.error("[Game API]", error);
  const route = `${req.baseUrl}${String(req.route?.path || "")}`.slice(0, 180) || "/api/game";
  const message = (error instanceof Error ? error.message : "Unknown server error").replace(/[\r\n\t]+/g, " ").slice(0, 500);
  void database().then(db => db.insert(spySystemErrors).values({ method: req.method.slice(0, 12), route, message })).catch(() => undefined);
  return res.status(500).json({ error: "Сталася помилка гри. Спробуйте ще раз." });
});

export function registerGameRoutes(app: import("express").Express) {
  app.use("/api/game", api);
}
