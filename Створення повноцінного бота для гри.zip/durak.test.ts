import { describe, it, expect } from "vitest";
import { durakEngine, DurakState } from "./durak.js";
import { ArcadePlayer, GameRuleError } from "./engine.js";
const players: ArcadePlayer[] = [
  { id: "a", name: "A", seat: 0 },
  { id: "b", name: "B", seat: 1 },
  { id: "c", name: "C", seat: 2 },
];
const ctx = { now: 1000, randomInt: (_n: number) => 0 };
function game(settings: Record<string, unknown> = {}) {
  return durakEngine.create(players, settings, ctx);
}
function act(
  s: DurakState,
  id: string,
  type: string,
  extra: Record<string, unknown> = {}
) {
  return durakEngine.applyAction(
    s,
    id,
    { type, ...extra },
    { ...ctx, now: ctx.now + 1 }
  ).state;
}
function legalPair(s: DurakState) {
  const d = s.players.find(p => p.id === s.defender)!;
  for (const q of s.table)
    for (const c of d.hand)
      if (
        (c.suit === q.attack.suit && c.rank > q.attack.rank) ||
        (c.suit === s.trumpSuit && q.attack.suit !== s.trumpSuit)
      )
        return { index: s.table.indexOf(q), cardId: c.id };
  return null;
}
describe("Durak engine", () => {
  it("builds 36-card deck, deals six each, selects lowest trump holder and deterministic shuffle", () => {
    const a = game(),
      b = game();
    expect(a.deck.length).toBe(18);
    expect(a.deck).toHaveLength(18);
    expect(a.players.every(p => p.hand.length === 6)).toBe(true);
    expect(
      new Set([...a.deck, ...a.players.flatMap(p => p.hand)].map(c => c.id))
        .size
    ).toBe(36);
    expect(a.players.find(p => p.id === a.attacker)!.hand).toEqual(
      b.players.find(p => p.id === b.attacker)!.hand
    );
    const lowest = a.players
      .flatMap(p => p.hand.map(c => ({ id: p.id, c })))
      .filter(x => x.c.suit === a.trumpSuit)
      .sort((x, y) => x.c.rank - y.c.rank)[0];
    expect(lowest.id).toBe(a.attacker);
    expect(a.trumpCard.suit).toBe(a.trumpSuit);
  });
  it("builds the selectable 52-card deck with ranks from two through ace", () => {
    const state = game({ deckSize: 52 });
    const allCards = [...state.deck, ...state.players.flatMap(p => p.hand)];
    expect(state.deckSize).toBe(52);
    expect(state.deck).toHaveLength(34);
    expect(state.players.every(p => p.hand.length === 6)).toBe(true);
    expect(new Set(allCards.map(card => card.id)).size).toBe(52);
    expect(allCards.some(card => card.rank === 2)).toBe(true);
    expect(allCards.some(card => card.rank === 5)).toBe(true);
  });
  it("allows full legal defense and completes beaten battle", () => {
    let s = game();
    s = act(s, s.attacker, "attack", {
      cardId: s.players.find(p => p.id === s.attacker)!.hand[0].id,
    });
    const pair = legalPair(s);
    if (!pair) return;
    s = act(s, s.defender, "defend", pair);
    expect(s.table[0].defense).toBeTruthy();
    s = act(s, s.attacker, "done");
    expect(s.table).toHaveLength(0);
    expect(s.attacker).toBeTruthy();
  });
  it("rejects attacks, covers, unauthorized turns and unknown cards without mutating source", () => {
    const s = game();
    const before = JSON.stringify(s);
    expect(() => act(s, "b", "attack", { cardId: "bad" })).toThrow(
      GameRuleError
    );
    expect(JSON.stringify(s)).toBe(before);
    expect(() =>
      durakEngine.applyAction(s, "a", { type: "defend", cardId: "bad" }, ctx)
    ).toThrow();
  });
  it("enforces throw-in ranks and attack cap", () => {
    let s = game();
    const a = s.players.find(p => p.id === s.attacker)!;
    const other = s.players.find(p => p.id !== a.id)!;
    const first = a.hand[0];
    s = act(s, a.id, "attack", { cardId: first.id });
    const d = s.defender;
    const thrower = s.players.find(p => p.id === a.id)!;
    const wrong = thrower.hand.find(c => c.rank !== first.rank);
    if (wrong) {
      const before = JSON.stringify(s);
      expect(() => act(s, a.id, "throw_in", { cardId: wrong.id })).toThrow();
      expect(JSON.stringify(s)).toBe(before);
    }
    expect(s.players.find(p => p.id === other.id)).toBeTruthy();
  });
  it("rejects transfer actions even when a same-rank card is available", () => {
    let s = game();
    const attacker = s.players.find(p => p.id === s.attacker)!;
    const defender = s.players.find(p => p.id === s.defender)!;
    const attackCard = attacker.hand[0];
    defender.hand[0].rank = attackCard.rank;
    s = act(s, attacker.id, "attack", { cardId: attackCard.id });
    const view = durakEngine.toView(s, defender.id) as { legalActions: Record<string, unknown>[] };
    expect(view.legalActions.some(action => action.type === "transfer")).toBe(false);
    expect(() => act(s, defender.id, "transfer", { cardId: defender.hand[0].id })).toThrow();
  });
  it("draws after battle and ends with last durak after stock empties", () => {
    const s = game();
    expect(s.deck.length).toBe(18);
    const v = durakEngine.toView(s, "a") as any;
    expect(v.players.find((p: any) => p.id === "a").hand).toHaveLength(6);
    expect(v.players.find((p: any) => p.id === "b").hand).toBeUndefined();
    expect(v.players.find((p: any) => p.id === "b").backs).toHaveLength(6);
  });
  it("timeout forfeit is terminal and exposes an outcome", () => {
    const s = game();
    const r = durakEngine.onTimeout!(s, { ...ctx, now: s.deadline! + 1 });
    expect(r?.state.phase).toBe("finished");
    expect(r?.outcome?.reason).toBe("timeout_forfeit");
  });
  it("gives the new defender a fresh per-turn deadline after an accepted attack", () => {
    const s = game();
    const originalDeadline = s.deadline!;
    const played = s.players.find(p => p.id === s.attacker)!.hand[0]!;
    const actionAt = originalDeadline - 10_000;
    const result = durakEngine.applyAction(
      s,
      s.attacker,
      { type: "attack", cardId: played.id },
      { ...ctx, now: actionAt }
    );
    expect(result.state.turn).toBe(s.defender);
    expect(result.state.deadline).toBe(actionAt + s.turnMs);
    expect(result.state.deadline).toBeGreaterThan(originalDeadline);
  });
  it("returns the attack to the original attacker after a two-player defender picks up", () => {
    const two = players.slice(0, 2);
    let s = durakEngine.create(two, {}, ctx);
    const originalAttacker = s.attacker;
    const playerWhoPicksUp = s.defender;
    const attackCard = s.players.find(p => p.id === originalAttacker)!.hand[0]!;
    s = act(s, originalAttacker, "attack", { cardId: attackCard.id });
    s = act(s, playerWhoPicksUp, "take");
    expect(s.phase).toBe("attack");
    expect(s.attacker).toBe(originalAttacker);
    expect(s.turn).toBe(originalAttacker);
    expect(s.players.find(p => p.id === playerWhoPicksUp)!.hand).toContainEqual(
      attackCard
    );
    expect(() => act(s, playerWhoPicksUp, "attack", { cardId: attackCard.id })).toThrow(
      "Зараз не ваш хід."
    );
  });
  it("lets the attacker throw in a matching rank while the defender still has the turn", () => {
    let s = game({ mode: "throw_in" });
    const attacker = s.players.find(p => p.id === s.attacker)!;
    const first = attacker.hand[0]!;
    const second = attacker.hand[1]!;
    attacker.hand[1] = { ...second, rank: first.rank };
    s = act(s, attacker.id, "attack", { cardId: first.id });
    expect(s.phase).toBe("defend");
    expect(s.turn).toBe(s.defender);
    const attackerActions = (durakEngine.toView(s, attacker.id) as any)
      .legalActions;
    expect(attackerActions).toContainEqual(
      expect.objectContaining({ type: "throw_in", cardId: second.id })
    );
    s = durakEngine.applyAction(
      s,
      attacker.id,
      { type: "throw_in", cardId: second.id },
      { ...ctx, now: ctx.now + 2 }
    ).state;
    expect(s.phase).toBe("defend");
    expect(s.turn).toBe(s.defender);
    expect(s.table).toHaveLength(2);
    expect(s.table.map(pair => pair.attack.rank)).toEqual([first.rank, first.rank]);
  });
  it("allows the attacker to throw in a matching rank after the defender has covered the current table", () => {
    let s = durakEngine.create(players.slice(0, 2), { mode: "throw_in" }, ctx);
    const attackerId = s.attacker;
    const defenderId = s.defender;
    const attacker = s.players.find(p => p.id === attackerId)!;
    const defender = s.players.find(p => p.id === defenderId)!;
    const first = { ...attacker.hand[0]!, rank: 8 as const, suit: "clubs" as const };
    const second = { ...attacker.hand[1]!, rank: 8 as const, suit: "spades" as const };
    const cover = { ...defender.hand[0]!, rank: 9 as const, suit: "clubs" as const };
    attacker.hand[0] = first;
    attacker.hand[1] = second;
    defender.hand[0] = cover;

    s = act(s, attackerId, "attack", { cardId: first.id });
    s = act(s, defenderId, "defend", { index: 0, cardId: cover.id });
    expect(s.phase).toBe("attack");
    expect(s.turn).toBe(attackerId);
    const attackerActions = (durakEngine.toView(s, attackerId) as any).legalActions;
    expect(attackerActions).toContainEqual(
      expect.objectContaining({ type: "done" })
    );
    expect(attackerActions).toContainEqual(
      expect.objectContaining({ type: "throw_in", cardId: second.id })
    );

    s = act(s, attackerId, "throw_in", { cardId: second.id });
    expect(s.phase).toBe("defend");
    expect(s.turn).toBe(defenderId);
    expect(s.table).toHaveLength(2);
    expect(s.table[1]).toMatchObject({ attack: second, defense: null });
  });
  it("does not mutate state for invalid transfer and only shows viewer hand", () => {
    const s = game({ mode: "throw_in" });
    const before = JSON.stringify(s);
    expect(() =>
      act(s, s.attacker, "transfer", { cardId: s.players[0].hand[0].id })
    ).toThrow();
    expect(JSON.stringify(s)).toBe(before);
    const v = durakEngine.toView(s, "a") as any;
    expect(v.players.find((p: any) => p.id === "a").hand).toHaveLength(6);
    expect(v.players.find((p: any) => p.id === "b").hand).toBeUndefined();
  });
  it("exposes concrete legal action objects with payloads and never private opponent cards", () => {
    const s = game();
    const v = durakEngine.toView(s, s.attacker) as any;
    expect(v.legalActions.length).toBeGreaterThan(0);
    expect(v.legalActions[0]).toMatchObject({
      type: "attack",
      label: expect.any(String),
      cardId: expect.any(String),
      payload: { cardId: expect.any(String) },
    });
    expect(
      v.players.find((p: any) => p.id !== s.attacker).hand
    ).toBeUndefined();
    expect((durakEngine.toView(s, "not-a-player") as any).legalActions).toEqual(
      []
    );
  });
  it("rejects transfer cards and transfer actions in legacy transfer-mode state", () => {
    const two = players.slice(0, 2);
    let s = durakEngine.create(two, { mode: "transfer" }, ctx);
    const originalAttacker = s.attacker;
    const originalDefender = s.defender;
    const attacker = s.players.find(p => p.id === originalAttacker)!;
    const defender = s.players.find(p => p.id === originalDefender)!;
    const chosen = attacker.hand.find(c => defender.hand.some(d => d.rank === c.rank));
    expect(chosen).toBeTruthy();
    if (!chosen) return;

    s = act(s, originalAttacker, "attack", { cardId: chosen.id });
    const matching = s.players.find(p => p.id === originalDefender)!.hand.find(c => c.rank === chosen.rank);
    expect(matching).toBeTruthy();
    if (!matching) return;
    const view = durakEngine.toView(s, originalDefender) as { legalActions: Record<string, unknown>[] };
    expect(view.legalActions.some(action => action.type === "transfer")).toBe(false);
    expect(() => act(s, originalDefender, "transfer", { cardId: matching.id })).toThrow();
  });
});
