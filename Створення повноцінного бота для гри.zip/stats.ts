import { and, desc, eq, inArray } from "drizzle-orm";
import { getDb } from "../../db";
import {
  gamePlayerStats,
  gameTablePlayers,
  gameTableResults,
  spyProfiles,
} from "../../../drizzle/schema";
import { isPlayableArcadeGameId, PLAYABLE_ARCADE_GAME_IDS } from "./playableGames";

type PlayerStatRow = {
  telegramId: string;
  gameId: string;
  gamesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  netCoins: number;
  biggestWin: number;
  rating: number;
};

type GlobalStatRow = Omit<PlayerStatRow, "gameId" | "rating"> & {
  rating: number;
  winRate: number;
};

export function calculateElo(
  rating: number,
  opponentRating: number,
  score: 0 | 0.5 | 1,
  k = 32
) {
  const expected = 1 / (1 + 10 ** ((opponentRating - rating) / 400));
  return Math.round(rating + k * (score - expected));
}

export const limitValue = (n: number) =>
  Math.max(1, Math.min(100, Number.isFinite(n) ? n : 30));

export function aggregateGlobalLeaderboard(
  rows: readonly PlayerStatRow[]
): GlobalStatRow[] {
  const groups = new Map<
    string,
    Omit<GlobalStatRow, "rating" | "winRate"> & {
      ratedTotal: number;
      ratedGames: number;
    }
  >();
  for (const row of rows) {
    if (!isPlayableArcadeGameId(row.gameId)) continue;
    const group = groups.get(row.telegramId) ?? {
      telegramId: row.telegramId,
      gamesPlayed: 0,
      wins: 0,
      losses: 0,
      draws: 0,
      netCoins: 0,
      biggestWin: 0,
      ratedTotal: 0,
      ratedGames: 0,
    };
    group.gamesPlayed += row.gamesPlayed;
    group.wins += row.wins;
    group.losses += row.losses;
    group.draws += row.draws;
    group.netCoins += row.netCoins;
    group.biggestWin = Math.max(group.biggestWin, row.biggestWin);
    group.ratedTotal += row.rating;
    group.ratedGames += 1;
    groups.set(row.telegramId, group);
  }
  return [...groups.values()]
    .map(row => ({
      telegramId: row.telegramId,
      gamesPlayed: row.gamesPlayed,
      wins: row.wins,
      losses: row.losses,
      draws: row.draws,
      netCoins: row.netCoins,
      biggestWin: row.biggestWin,
      rating: row.ratedGames ? Math.round(row.ratedTotal / row.ratedGames) : 0,
      winRate: row.gamesPlayed
        ? Math.round((row.wins / row.gamesPlayed) * 1000) / 10
        : 0,
    }))
    .sort(
      (a, b) =>
        b.rating - a.rating ||
        b.wins - a.wins ||
        b.gamesPlayed - a.gamesPlayed ||
        a.telegramId.localeCompare(b.telegramId)
    );
}

function userBankSettlement(outcome: unknown, telegramId: string) {
  const bank = (outcome as any)?.bankSettlement;
  if (!bank) return undefined;
  return {
    bankBalanceBefore: bank.bankBalanceBefore,
    availableBank: bank.availableBank,
    bankBalanceAfter: bank.bankBalanceAfter,
    bankCapped: bank.bankCapped,
    myTargetPayout: bank.targetPayouts?.[telegramId] ?? 0,
  };
}

export async function getGameHistory(
  telegramId: string,
  limit = 30,
  gameId?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  if (gameId && !isPlayableArcadeGameId(gameId)) return [];
  const rows = await db
    .select({
      tableId: gameTableResults.tableId,
      gameId: gameTableResults.gameId,
      winnerIds: gameTableResults.winnerIds,
      outcome: gameTableResults.outcome,
      payouts: gameTableResults.payouts,
      totalPot: gameTableResults.totalPot,
      completedAt: gameTableResults.completedAt,
    })
    .from(gameTableResults)
    .innerJoin(
      gameTablePlayers,
      eq(gameTablePlayers.tableId, gameTableResults.tableId)
    )
    .where(
      and(
        eq(gameTablePlayers.telegramId, telegramId),
        inArray(gameTableResults.gameId, [...PLAYABLE_ARCADE_GAME_IDS]),
        ...(gameId ? [eq(gameTableResults.gameId, gameId as any)] : [])
      )
    )
    .orderBy(desc(gameTableResults.completedAt))
    .limit(limitValue(limit));
  const ids = [
    ...new Set(rows.flatMap(r => [...r.winnerIds, ...Object.keys(r.payouts)])),
  ];
  const profiles = ids.length
    ? await db
        .select({
          id: spyProfiles.telegramId,
          first: spyProfiles.firstName,
          last: spyProfiles.lastName,
          username: spyProfiles.username,
        })
        .from(spyProfiles)
    : [];
  const names = new Map(
    profiles.map(p => [
      p.id,
      [p.first, p.last].filter(Boolean).join(" ") || p.username || "Гравець",
    ])
  );
  return rows.map(r => ({
    tableId: r.tableId,
    gameId: r.gameId,
    winners: r.winnerIds.map(id => names.get(id) || "Гравець"),
    outcome: { reason: r.outcome?.reason, draw: !!r.outcome?.draw },
    bankSettlement: userBankSettlement(r.outcome, telegramId),
    myPayout: r.payouts[telegramId] ?? 0,
    totalPot: r.totalPot,
    completedAt: r.completedAt,
  }));
}

export async function getLeaderboard(gameId?: string, limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  if (gameId && !isPlayableArcadeGameId(gameId)) return [];
  const source = await db
    .select()
    .from(gamePlayerStats)
    .where(
      gameId
        ? and(
            inArray(gamePlayerStats.gameId, [...PLAYABLE_ARCADE_GAME_IDS]),
            eq(gamePlayerStats.gameId, gameId as any)
          )
        : inArray(gamePlayerStats.gameId, [...PLAYABLE_ARCADE_GAME_IDS])
    )
    .orderBy(desc(gamePlayerStats.rating), desc(gamePlayerStats.wins));
  const rows: any[] = gameId
    ? source.map(row => ({
        ...row,
        winRate: row.gamesPlayed
          ? Math.round((row.wins / row.gamesPlayed) * 1000) / 10
          : 0,
      }))
    : aggregateGlobalLeaderboard(source as PlayerStatRow[]);
  const limited = rows.slice(0, limitValue(limit));
  const ids = limited.map(row => row.telegramId);
  const profiles = ids.length
    ? await db
        .select({
          id: spyProfiles.telegramId,
          first: spyProfiles.firstName,
          last: spyProfiles.lastName,
          username: spyProfiles.username,
        })
        .from(spyProfiles)
    : [];
  const names = new Map(
    profiles.map(p => [
      p.id,
      [p.first, p.last].filter(Boolean).join(" ") || p.username || "Гравець",
    ])
  );
  return limited.map(row => ({
    gameId: gameId || "all",
    name: names.get(row.telegramId) || "Гравець",
    gamesPlayed: row.gamesPlayed,
    wins: row.wins,
    losses: row.losses,
    draws: row.draws,
    rating: row.rating,
    winRate: row.winRate,
    netCoins: row.netCoins,
    biggestWin: row.biggestWin,
  }));
}

export async function recordPlayerStatTx(
  tx: any,
  playerId: string,
  gameId: string,
  result: "win" | "loss" | "draw",
  netCoins: number,
  payout: number,
  opponents: { rating: number; result: "win" | "loss" | "draw" }[] = []
) {
  const rows = await tx
    .select()
    .from(gamePlayerStats)
    .where(
      and(
        eq(gamePlayerStats.telegramId, playerId),
        eq(gamePlayerStats.gameId, gameId as any)
      )
    )
    .limit(1)
    .for("update");
  const old = rows[0];
  const vals: any = {
    gamesPlayed: (old?.gamesPlayed ?? 0) + 1,
    wins: (old?.wins ?? 0) + (result === "win" ? 1 : 0),
    losses: (old?.losses ?? 0) + (result === "loss" ? 1 : 0),
    draws: (old?.draws ?? 0) + (result === "draw" ? 1 : 0),
    netCoins: (old?.netCoins ?? 0) + netCoins,
    biggestWin: Math.max(old?.biggestWin ?? 0, payout),
  };
  if (gameId !== "blackjack" && opponents.length) {
    const initial = old?.rating ?? 1000;
    vals.rating = Math.round(
      opponents.reduce(
        (rating, opponent) =>
          calculateElo(
            rating,
            opponent.rating,
            result === "draw" || opponent.result === "draw"
              ? 0.5
              : result === "win"
                ? 1
                : 0
          ),
        initial
      )
    );
  }
  if (old)
    await tx
      .update(gamePlayerStats)
      .set(vals)
      .where(eq(gamePlayerStats.id, old.id));
  else
    await tx.insert(gamePlayerStats).values({
      telegramId: playerId,
      gameId: gameId as any,
      ...vals,
      rating: vals.rating ?? 1000,
    });
}
