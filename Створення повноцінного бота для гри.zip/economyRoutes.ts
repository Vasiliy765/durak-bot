import { Router, type Express, type NextFunction, type Request, type Response } from "express";
import { identityFromRequest } from "./auth";
import {
  EconomyError,
  claimDaily,
  claimSalary,
  equipInventoryItem,
  getEconomyOverview,
  listInventory,
  listShopItems,
  purchaseShopItem,
  wealthLeaderboard,
  createStarsInvoice,
  exchangeCrystals,
  buyVip,
  readEconomySettings,
  saveEconomySettings,
  grantEconomy,
  findEconomyPlayer,
  type EconomyIdentity,
} from "./economy";

const api = Router();
function isEconomyAdmin(id: string) {
  return (process.env.ADMIN_IDS || process.env.SPY_ADMIN_IDS || "").split(/[ ,]+/).filter(Boolean).includes(id);
}

type AuthRequest = Request & { economyIdentity?: EconomyIdentity };

function identity(req: Request): EconomyIdentity {
  const current = (req as AuthRequest).economyIdentity || identityFromRequest(req);
  if (!current) throw new EconomyError(401, "Відкрийте Mini App через Telegram і повторіть дію.");
  return {
    id: current.id,
    firstName: current.firstName,
    lastName: current.lastName,
    username: current.username,
    avatarUrl: current.avatarUrl,
  };
}

const asyncRoute = (handler: (req: Request, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => { void handler(req, res, next).catch(next); };

api.get("/overview", asyncRoute(async (req, res) => res.json(await getEconomyOverview(identity(req)))));
api.get("/shop", asyncRoute(async (_req, res) => res.json({ items: await listShopItems() })));
api.get("/inventory", asyncRoute(async (req, res) => res.json({ items: await listInventory(identity(req)) })));
api.get("/top", asyncRoute(async (req, res) => {
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
  return res.json({ players: await wealthLeaderboard(limit) });
}));
api.post("/salary", asyncRoute(async (req, res) => res.json(await claimSalary(identity(req)))));
api.post("/daily", asyncRoute(async (req, res) => res.json(await claimDaily(identity(req)))));
api.post("/stars/invoice", asyncRoute(async (req, res) => {
  const packageId = typeof req.body?.packageId === "string" ? req.body.packageId : "";
  return res.json(await createStarsInvoice(identity(req), packageId));
}));
api.post("/exchange", asyncRoute(async (req, res) => res.json(await exchangeCrystals(identity(req), Number(req.body?.crystals)))));
api.post("/vip", asyncRoute(async (req, res) => res.json(await buyVip(identity(req)))));
api.get("/admin/settings", asyncRoute(async (req, res) => {
  const who = identity(req);
  if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
  return res.json({ settings: await readEconomySettings() });
}));
api.post("/admin/settings", asyncRoute(async (req, res) => {
  const who = identity(req);
  if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
  return res.json({ settings: await saveEconomySettings(who.id, req.body || {}) });
}));
api.post("/admin/grant", asyncRoute(async (req, res) => {
  const who = identity(req);
  if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
  const { target, currency, amount } = req.body || {};
  if (typeof target !== "string" || !["coins", "crystals", "vip"].includes(currency)) throw new EconomyError(400, "Некоректний запит.");
  return res.json({ player: await grantEconomy(who.id, target, currency, Number(amount)) });
}));
api.get("/admin/player", asyncRoute(async (req, res) => {
  const who = identity(req);
  if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
  const target = typeof req.query.target === "string" ? req.query.target : "";
  const player = await findEconomyPlayer(target);
  if (!player) throw new EconomyError(404, "Гравця не знайдено в базі");
  return res.json({ player });
}));
api.post("/purchase", asyncRoute(async (req, res) => {
  const itemId = typeof req.body?.itemId === "string" ? req.body.itemId.trim() : "";
  if (!itemId) throw new EconomyError(400, "Оберіть предмет магазину.");
  return res.json(await purchaseShopItem(identity(req), itemId));
}));
api.post("/equip", asyncRoute(async (req, res) => {
  const itemId = typeof req.body?.itemId === "string" ? req.body.itemId.trim() : "";
  if (!itemId) throw new EconomyError(400, "Оберіть предмет зі свого інвентарю.");
  return res.json(await equipInventoryItem(identity(req), itemId));
}));

api.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof EconomyError) return res.status(error.status).json({ error: error.message });
  console.error("[Economy API]", error instanceof Error ? error.message : String(error));
  return res.status(500).json({ error: "Не вдалося виконати фінансову операцію. Спробуйте ще раз." });
});

export function registerEconomyRoutes(app: Express) {
  app.use("/api/game/economy", api);
  const aliases = Router();
  aliases.post("/create-invoice", asyncRoute(async (req, res) => {
    const packageId = typeof req.body?.packageId === "string" ? req.body.packageId : "";
    return res.json(await createStarsInvoice(identity(req), packageId));
  }));
  aliases.post("/exchange", asyncRoute(async (req, res) => res.json(await exchangeCrystals(identity(req), Number(req.body?.crystals)))));
  aliases.post("/buy-vip", asyncRoute(async (req, res) => res.json(await buyVip(identity(req)))));
  aliases.get("/admin/settings", asyncRoute(async (req, res) => {
    const who = identity(req);
    if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
    return res.json({ settings: await readEconomySettings() });
  }));
  aliases.post("/admin/settings", asyncRoute(async (req, res) => {
    const who = identity(req);
    if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
    return res.json({ settings: await saveEconomySettings(who.id, req.body || {}) });
  }));
  aliases.get("/admin/player", asyncRoute(async (req, res) => {
    const who = identity(req);
    if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
    const player = await findEconomyPlayer(typeof req.query.target === "string" ? req.query.target : "");
    if (!player) throw new EconomyError(404, "Гравця не знайдено в базі");
    return res.json({ player });
  }));
  aliases.post("/admin/grant", asyncRoute(async (req, res) => {
    const who = identity(req);
    if (!isEconomyAdmin(who.id)) throw new EconomyError(403, "Доступ заборонено.");
    const { target, currency, amount } = req.body || {};
    if (typeof target !== "string" || !["coins", "crystals", "vip"].includes(currency)) throw new EconomyError(400, "Некоректний запит.");
    return res.json({ player: await grantEconomy(who.id, target, currency, Number(amount)) });
  }));
  aliases.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (error instanceof EconomyError) return res.status(error.status).json({ error: error.message });
    console.error("[Economy API aliases]", error instanceof Error ? error.message : String(error));
    return res.status(500).json({ error: "Не вдалося виконати фінансову операцію. Спробуйте ще раз." });
  });
  app.use("/api", aliases);
}
