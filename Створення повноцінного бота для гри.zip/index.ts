import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { registerGameRoutes } from "../game/routes";
import { registerEconomyRoutes } from "../game/economyRoutes";
import { registerTelegramBotRoutes } from "../game/telegramBot";
import { gameCenterRouter } from "../game/arcade/routes";
import { startGameCenterWorker } from "../game/arcade/gameCenterWorker";
import { registerDurakReactionSocket } from "../game/arcade/reactionSocket";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

async function startServer() {
  const app = express();
  const server = createServer(app);
  registerDurakReactionSocket(server);
  // Game actions and Telegram updates are small; cap public request bodies against abuse.
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ limit: "1mb", extended: false }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  registerOAuthRoutes(app);
  registerGameRoutes(app);
  registerEconomyRoutes(app);
  registerTelegramBotRoutes(app);
  app.use("/api/game-center", gameCenterRouter);
  startGameCenterWorker();
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
