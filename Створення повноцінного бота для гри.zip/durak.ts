import {
  ArcadeEngine,
  ArcadePlayer,
  ArcadeEngineContext,
  ArcadeAction,
  ArcadeStep,
  ArcadeOutcome,
  GameRuleError,
  shuffle,
  requirePlayer,
} from "./engine.js";

export type DurakSuit = "clubs" | "diamonds" | "hearts" | "spades";
export type DurakRank = 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14;
export type DurakCard = { id: string; rank: DurakRank; suit: DurakSuit };
type Pair = { attack: DurakCard; defense: DurakCard | null };
type PlayerState = ArcadePlayer & { hand: DurakCard[] };
export type DurakState = {
  players: PlayerState[];
  deckSize: 36 | 52;
  deck: DurakCard[];
  trumpSuit: DurakSuit;
  trumpCard: DurakCard;
  table: Pair[];
  attacker: string;
  defender: string;
  turn: string;
  phase: "attack" | "defend" | "take" | "finished";
  limit: number;
  initialDefenderHand: number;
  deadline: number | null;
  turnMs: number;
  events: { type: string; playerId?: string; card?: DurakCard }[];
  outcome?: ArcadeOutcome;
};
const SUITS: DurakSuit[] = ["clubs", "diamonds", "hearts", "spades"];
const RANKS_36: DurakRank[] = [6, 7, 8, 9, 10, 11, 12, 13, 14];
const RANKS_52: DurakRank[] = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
const copy = (s: DurakState): DurakState => structuredClone(s);
const player = (s: DurakState, id: string) => {
  const p = s.players.find(x => x.id === id);
  if (!p) throw new GameRuleError("Гравець не бере участі.", "NOT_A_PLAYER");
  return p;
};
function nextActive(s: DurakState, id: string, includeSelf = false): string {
  const start = s.players.findIndex(p => p.id === id);
  if (start < 0) return id;
  for (
    let n = includeSelf ? 0 : 1;
    n < s.players.length + (includeSelf ? 0 : 1);
    n++
  ) {
    const p = s.players[(start + n) % s.players.length];
    if (p.hand.length) return p.id;
  }
  return id;
}
function finish(s: DurakState, reason: string, draw = false) {
  s.phase = "finished";
  s.turn = "";
  s.deadline = null;
  s.outcome = {
    winnerIds: draw
      ? []
      : s.players.filter(p => p.hand.length === 0).map(p => p.id),
    draw,
    reason,
    ...(draw ? { refundIds: s.players.map(p => p.id) } : {}),
  };
}
function settle(s: DurakState, success: boolean, ctx: ArcadeEngineContext) {
  const oldAtt = s.attacker,
    oldDef = s.defender;
  if (!success)
    player(s, oldDef).hand.push(
      ...s.table.flatMap(q => (q.defense ? [q.attack, q.defense] : [q.attack]))
    );
  s.table = [];
  // Cards are drawn clockwise from the attacker; the defender who picked up draws last.
  let cursor = oldAtt;
  for (let i = 0; i < s.players.length; i++) {
    const p = player(s, cursor);
    while (s.deck.length && p.hand.length < 6) p.hand.push(s.deck.shift()!);
    cursor = nextActive(s, cursor);
    if (cursor === oldAtt) break;
  }
  if (!s.deck.length) {
    const empty = s.players.filter(p => !p.hand.length),
      alive = s.players.filter(p => p.hand.length > 0);
    if (alive.length <= 1) {
      finish(s, alive.length === 1 ? "last_durak" : "draw", alive.length === 0);
      return;
    }
  }
  // If the defender takes, play passes clockwise from that defender. In a
  // two-player game this correctly returns the attack to the original attacker.
  let attacker = success ? oldDef : nextActive(s, oldDef);
  if (!player(s, attacker).hand.length) attacker = nextActive(s, attacker);
  let defender = nextActive(s, attacker);
  if (defender === attacker) {
    finish(s, "last_durak");
    return;
  }
  s.attacker = attacker;
  s.defender = defender;
  s.initialDefenderHand = player(s, defender).hand.length;
  s.limit = Math.min(6, s.initialDefenderHand);
  s.phase = "attack";
  s.turn = attacker;
  s.deadline = ctx.now + s.turnMs;
}
function beats(c: DurakCard, a: DurakCard, trump: DurakSuit) {
  return (
    (c.suit === a.suit && c.rank > a.rank) ||
    (c.suit === trump && a.suit !== trump)
  );
}
function tableRanks(s: DurakState) {
  return new Set(
    s.table.flatMap(q => [
      q.attack.rank,
      ...(q.defense ? [q.defense.rank] : []),
    ])
  );
}
function legal(s: DurakState, viewer: string): Record<string, unknown>[] {
  const mayThrowInOutOfTurn =
    (s.phase === "attack" || s.phase === "defend") &&
    s.table.length > 0 &&
    s.table.length < s.limit &&
    s.table.length < 6 &&
    viewer !== s.defender;
  if (viewer !== s.turn && !mayThrowInOutOfTurn) return [];
  const p = s.players.find(x => x.id === viewer);
  if (!p) return [];
  const out: Record<string, unknown>[] = [];
  const add = (type: string, c?: DurakCard, index?: number, label?: string) =>
    out.push({
      type,
      ...(c ? { payload: { cardId: c.id }, cardId: c.id } : {}),
      ...(index === undefined ? {} : { index }),
      label: label ?? type,
    });
  if (s.phase === "attack") {
    if (viewer === s.attacker) {
      if (!s.table.length)
        for (const c of p.hand) add("attack", c, undefined, "Атакувати");
      else if (s.table.length < s.limit && s.table.length < 6)
        for (const c of p.hand)
          if (tableRanks(s).has(c.rank))
            add("throw_in", c, undefined, "Підкинути");
    } else if (mayThrowInOutOfTurn) {
      for (const c of p.hand)
        if (tableRanks(s).has(c.rank))
          add("throw_in", c, undefined, "Підкинути");
    }
    if (viewer === s.attacker && s.table.length && s.table.every(q => q.defense))
      add("done", undefined, undefined, "Бито");
  } else if (s.phase === "defend") {
    const canAdd = s.table.length > 0 && s.table.length < s.limit && s.table.length < 6;
    if (mayThrowInOutOfTurn && canAdd)
      for (const c of p.hand)
        if (tableRanks(s).has(c.rank))
          add("throw_in", c, undefined, "Підкинути");
    if (viewer === s.defender) {
      for (let i = 0; i < s.table.length; i++)
        if (!s.table[i].defense)
          for (const c of p.hand)
            if (beats(c, s.table[i].attack, s.trumpSuit))
              add("defend", c, i, "Покрити");
      if (s.table.some(q => !q.defense))
        add("take", undefined, undefined, "Взяти карти");
    }
  }
  return out;
}
export const durakEngine: ArcadeEngine<DurakState, unknown> = {
  gameId: "durak",
  minPlayers: 2,
  maxPlayers: 6,
  create(players, settings, ctx) {
    if (players.length < 2 || players.length > 6)
      throw new GameRuleError("Потрібно 2–6 гравців.");
    if (new Set(players.map(p => p.id)).size !== players.length)
      throw new GameRuleError("Повторний гравець.");
    const deckSize = settings.deckSize === 52 ? 52 : 36;
    const ranks = deckSize === 52 ? RANKS_52 : RANKS_36;
    const ordered = [...players].sort((a, b) => a.seat - b.seat),
      deck = shuffle(
        SUITS.flatMap(s =>
          ranks.map(r => ({ id: `${s}-${r}`, rank: r, suit: s }) as DurakCard)
        ),
        ctx.randomInt
      ),
      ps: PlayerState[] = ordered.map(p => ({ ...p, hand: [] }));
    for (let n = 0; n < 6; n++) for (const p of ps) p.hand.push(deck.shift()!);
    const trumpCard = deck[deck.length - 1];
    let starter = ps[0];
    for (const p of ps)
      for (const c of p.hand)
        if (
          c.suit === trumpCard.suit &&
          !ps.some(x =>
            x.hand.some(y => y.suit === trumpCard.suit && y.rank < c.rank)
          )
        )
          starter = p;
    const turnMs = Number.isFinite(settings.turnMs)
        ? Math.max(1000, Number(settings.turnMs))
        : 60_000;
    const state: DurakState = {
      players: ps,
      deckSize,
      deck,
      trumpSuit: trumpCard.suit,
      trumpCard,
      table: [],
      attacker: starter.id,
      defender: "",
      turn: starter.id,
      phase: "attack",
      limit: 6,
      initialDefenderHand: 6,
      deadline: ctx.now + turnMs,
      turnMs,
      events: [],
    };
    state.defender = nextActive(state, starter.id);
    return state;
  },
  applyAction(state, actorId, action, ctx) {
    const s = copy(state);
    requirePlayer(s.players, actorId);
    if (s.phase === "finished") throw new GameRuleError("Гру завершено.");
    const type = String(action.type ?? action.action ?? "").toLowerCase();
    const participantThrowIn =
      type === "throw_in" &&
      (s.phase === "attack" || s.phase === "defend") &&
      s.table.length > 0 &&
      s.table.length < s.limit &&
      s.table.length < 6 &&
      actorId !== s.defender;
    if (actorId !== s.turn && !participantThrowIn)
      throw new GameRuleError("Зараз не ваш хід.", "NOT_YOUR_TURN");
    const p = player(s, actorId),
      id = String(
        action.cardId ??
          (action.card && typeof action.card === "object"
            ? (action.card as { id?: unknown }).id
            : "")
      ),
      card = p.hand.find(c => c.id === id);
    const useCard = () => {
      if (!card) throw new GameRuleError("Карти немає у руці.");
      p.hand.splice(p.hand.indexOf(card), 1);
      return card;
    };
    if (type === "attack" || type === "throw_in") {
      if (
        (type === "attack" && (s.phase !== "attack" || actorId !== s.attacker)) ||
        (type === "throw_in" &&
          ((s.phase !== "attack" && s.phase !== "defend") || actorId === s.defender))
      )
        throw new GameRuleError("Зараз не можна атакувати.");
      if (type === "attack" && s.table.length)
        throw new GameRuleError("Атака вже почалася.");
      if (type === "throw_in" && !s.table.length)
        throw new GameRuleError("Спочатку потрібна атака.");
      if (!card) throw new GameRuleError("Карти немає у руці.");
      if (s.table.length && !tableRanks(s).has(card.rank))
        throw new GameRuleError("Можна підкидати лише номінал зі столу.");
      if (s.table.length >= s.limit || s.table.length >= 6)
        throw new GameRuleError("Досягнуто ліміт атаки.");
      const c = useCard();
      const defenderWasAlreadyActing = s.phase === "defend";
      s.table.push({ attack: c, defense: null });
      if (!defenderWasAlreadyActing) {
        s.phase = "defend";
        s.turn = s.defender;
      }
      s.events.push({ type, playerId: actorId, card: c });
    } else if (type === "defend" || type === "cover") {
      if (s.phase !== "defend" || actorId !== s.defender)
        throw new GameRuleError("Зараз не можна захищатися.");
      const i = Number(action.index),
        pair = s.table[i];
      if (!Number.isInteger(i) || !pair || pair.defense)
        throw new GameRuleError("Невірна ціль захисту.");
      if (!card) throw new GameRuleError("Карти немає у руці.");
      if (!beats(card, pair.attack, s.trumpSuit))
        throw new GameRuleError("Ця карта не б'є атаку.");
      const c = useCard();
      pair.defense = c;
      s.events.push({ type: "defend", playerId: actorId, card: c });
      if (s.table.every(q => q.defense)) {
        s.phase = "attack";
        s.turn = s.attacker;
      } else s.turn = s.defender;
    } else if (type === "take" || type === "pickup") {
      if (
        s.phase !== "defend" ||
        actorId !== s.defender ||
        !s.table.some(q => !q.defense)
      )
        throw new GameRuleError("Забрати зараз неможливо.");
      s.events.push({ type: "take", playerId: actorId });
      settle(s, false, ctx);
    } else if (type === "done" || type === "beat") {
      if (
        s.phase !== "attack" ||
        actorId !== s.attacker ||
        !s.table.length ||
        s.table.some(q => !q.defense)
      )
        throw new GameRuleError(
          "Бито можна оголосити лише після повного захисту."
        );
      s.events.push({ type: "beat", playerId: actorId });
      settle(s, true, ctx);
    } else throw new GameRuleError("Невідома дія.");
    if (!s.outcome) s.deadline = ctx.now + s.turnMs;
    return {
      state: s,
      events: [
        { type, actorId, at: ctx.now, publicText: type },
        ...(s.outcome ? [{ type: "game_over", actorId, at: ctx.now, publicText: "Гру завершено" }] : []),
      ],
      outcome: s.outcome,
    };
  },
  toView(state, viewerId) {
    return {
      gameId: "durak",
      phase: state.phase,
      turn: state.turn,
      deadline: state.deadline,
      attacker: state.attacker,
      defender: state.defender,
      deckSize: state.deckSize ?? 36,
      trump: { suit: state.trumpSuit, card: state.trumpCard },
      deckCount: state.deck.length,
      players: state.players.map(p => ({
        id: p.id,
        name: p.name,
        seat: p.seat,
        cardCount: p.hand.length,
        hand: p.id === viewerId ? p.hand.map(c => ({ ...c })) : undefined,
        backs:
          p.id === viewerId
            ? undefined
            : Array.from({ length: p.hand.length }, () => ({ back: true })),
      })),
      table: state.table.map(q => ({ attack: q.attack, defense: q.defense })),
      legalActions: state.phase === "finished" ? [] : legal(state, viewerId),
      events: state.events.slice(-30),
      outcome: state.outcome,
    };
  },
  getDeadline(state) {
    return state.deadline;
  },
  onTimeout(state, ctx) {
    if (state.phase === "finished" || !state.turn) return null;
    const s = copy(state),
      forfeiter = s.turn,
      remaining = s.players.filter(
        p => p.id !== forfeiter && p.hand.length > 0
      );
    s.players.find(p => p.id === forfeiter)!.hand = [];
    finish(s, "timeout_forfeit");
    s.outcome!.winnerIds = remaining.map(p => p.id);
    return {
      state: s,
      events: [
        {
          type: "timeout_forfeit",
          actorId: forfeiter,
          at: ctx.now,
          publicText: "Гравець програв за тайм-аутом.",
        },
        { type: "game_over", actorId: forfeiter, at: ctx.now, publicText: "Гру завершено" },
      ],
      outcome: s.outcome,
    };
  },
};
