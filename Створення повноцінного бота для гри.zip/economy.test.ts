import { describe, expect, it } from "vitest";
import {
  ECONOMY_RULES,
  configuredRewardAmount,
  formatRemaining,
  gameRewardAmount,
  gameRewardIdempotencyKey,
  isGameRewardEligible,
  calculateVipAdminAdjustment,
  starsPreCheckoutMatches,
} from "./economy";

describe("shared coin economy rules", () => {
  it("uses the specified fixed salary and bonus base values", () => {
    expect(ECONOMY_RULES.startingBalance).toBe(100);
    expect(ECONOMY_RULES.salaryMin).toBe(100);
    expect(ECONOMY_RULES.salaryMax).toBe(100);
    expect(ECONOMY_RULES.salaryCooldownMs).toBe(2 * 60 * 60 * 1000);
    expect(ECONOMY_RULES.dailyMin).toBe(50);
    expect(ECONOMY_RULES.dailyMax).toBe(50);
    expect(ECONOMY_RULES.dailyCooldownMs).toBe(24 * 60 * 60 * 1000);
  });

  it("doubles only the configured fixed reward for active VIP", () => {
    expect(configuredRewardAmount(100, false)).toBe(100);
    expect(configuredRewardAmount(100, true)).toBe(200);
    expect(configuredRewardAmount(50, false)).toBe(50);
    expect(configuredRewardAmount(50, true)).toBe(100);
  });

  it("validates Stars pre-checkout against the pending order owner, amount, and XTR currency", () => {
    const order = { status: "pending", telegramId: "123", stars: 50 };
    expect(starsPreCheckoutMatches(order, { from: { id: 123 }, currency: "XTR", total_amount: 50 })).toBe(true);
    expect(starsPreCheckoutMatches({ ...order, status: "paid" }, { from: { id: 123 }, currency: "XTR", total_amount: 50 })).toBe(false);
    expect(starsPreCheckoutMatches(order, { from: { id: 456 }, currency: "XTR", total_amount: 50 })).toBe(false);
    expect(starsPreCheckoutMatches(order, { from: { id: 123 }, currency: "USD", total_amount: 50 })).toBe(false);
    expect(starsPreCheckoutMatches(order, { from: { id: 123 }, currency: "XTR", total_amount: 49 })).toBe(false);
  });

  it("records accurate VIP-day balances for admin grants and debits", () => {
    const now = Date.UTC(2026, 0, 1);
    expect(calculateVipAdminAdjustment(null, 30, now)).toMatchObject({ vipUntil: new Date(now + 30 * 86_400_000), daysRemaining: 30 });
    expect(calculateVipAdminAdjustment(new Date(now + 10 * 86_400_000), -3, now).daysRemaining).toBe(7);
    expect(calculateVipAdminAdjustment(new Date(now + 2 * 86_400_000), -5, now)).toEqual({ vipUntil: null, daysRemaining: 0 });
  });

  it("rejects short or undersized matches for game rewards", () => {
    expect(isGameRewardEligible(2, 600)).toBe(false);
    expect(isGameRewardEligible(3, 179)).toBe(false);
    expect(isGameRewardEligible(3, 180)).toBe(true);
    expect(isGameRewardEligible(12, 180)).toBe(true);
  });

  it("awards participation plus a win bonus and keeps each player-round key unique", () => {
    expect(gameRewardAmount(false)).toBe(5);
    expect(gameRewardAmount(true)).toBe(10);
    expect(gameRewardIdempotencyKey("round-1", "123")).toBe("game:round-1:123");
    expect(gameRewardIdempotencyKey("round-1", "123")).toBe(gameRewardIdempotencyKey("round-1", "123"));
    expect(gameRewardIdempotencyKey("round-1", "123")).not.toBe(gameRewardIdempotencyKey("round-2", "123"));
    expect(gameRewardIdempotencyKey("round-1", "123")).not.toBe(gameRewardIdempotencyKey("round-1", "456"));
  });

  it("rounds cooldown messages up to the next whole minute", () => {
    expect(formatRemaining(1)).toBe("1 хв");
    expect(formatRemaining(60_000)).toBe("1 хв");
    expect(formatRemaining(3_600_000)).toBe("1 год 0 хв");
    expect(formatRemaining(3_661_000)).toBe("1 год 2 хв");
  });
});
