import {
  chatPrankCategories,
  getChatPrankDefinition,
  type ChatPrankAction,
} from "../../shared/chatPrankCatalog";

export type ChatPrank = {
  action: ChatPrankAction;
  trigger: string;
  suffix?: string;
};

export type ChatPrankParticipant = {
  id: number;
  name: string;
};

const triggerEntries: { action: ChatPrankAction; trigger: string }[] = [];
for (const category of chatPrankCategories) {
  for (const action of category.actions) {
    for (const trigger of action.triggers) {
      triggerEntries.push({ action: action.id, trigger });
    }
  }
}
triggerEntries.sort((left, right) => right.trigger.length - left.trigger.length);

function normalizePhrase(value: string) {
  return value.replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim();
}

export function parseChatPrank(text: string): ChatPrank | null {
  const normalized = normalizePhrase(text);
  if (!normalized) return null;
  const lowered = normalized.toLocaleLowerCase("uk");

  for (const entry of triggerEntries) {
    const trigger = entry.trigger.toLocaleLowerCase("uk");
    if (!lowered.startsWith(trigger)) continue;

    const boundary = lowered.slice(trigger.length, trigger.length + 1);
    if (boundary && !/[\s,.;:!?—–-]/u.test(boundary)) continue;

    const suffix = normalized
      .slice(entry.trigger.length)
      .replace(/^[\s,.;:!?—–-]+/u, "")
      .trim()
      .slice(0, 160);

    return {
      action: entry.action,
      trigger: entry.trigger,
      ...(suffix ? { suffix } : {}),
    };
  }

  return null;
}

export function isEligibleChatPrankReply(
  actor: { id: number; is_bot?: boolean } | undefined,
  target: { id: number; is_bot?: boolean } | undefined
) {
  return Boolean(
    actor &&
      Number.isSafeInteger(actor.id) &&
      actor.id > 0 &&
      actor.is_bot !== true &&
      target &&
      Number.isSafeInteger(target.id) &&
      target.id > 0 &&
      target.id !== actor.id &&
      target.is_bot !== true
  );
}

function safeLabel(value: string, fallback: string) {
  return (
    normalizePhrase(value)
      .replace(/[\u0000-\u001f\u007f]/g, " ")
      .slice(0, 64) || fallback
  );
}

function escapeTelegramHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function mention(participant: ChatPrankParticipant) {
  if (!Number.isSafeInteger(participant.id) || participant.id <= 0) return null;
  const name = escapeTelegramHtml(safeLabel(participant.name, "Гравець"));
  return `<a href="tg://user?id=${participant.id}">${name}</a>`;
}

export function formatChatPrank(
  action: ChatPrankAction,
  actor: ChatPrankParticipant,
  target: ChatPrankParticipant,
  suffix?: string
) {
  const definition = getChatPrankDefinition(action);
  const actorMention = mention(actor);
  const targetMention = mention(target);
  if (!definition || !actorMention || !targetMention) return null;

  const safeSuffix = suffix
    ? normalizePhrase(suffix)
        .replace(/[\u0000-\u001f\u007f]/g, " ")
        .slice(0, 160)
    : "";
  const italicSuffix = safeSuffix
    ? ` <i>(${escapeTelegramHtml(safeSuffix)})</i>`
    : "";

  return `${definition.leadingEmoji} ${actorMention} ${definition.actionText} ${targetMention} ${definition.endingEmoji}${italicSuffix}`;
}
