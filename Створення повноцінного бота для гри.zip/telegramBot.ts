import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import type { Express, Request, Response } from "express";
import { getDb } from "../db";
import { spyTelegramUpdates } from "../../drizzle/schema";
import {
  economyTextCommands,
  parseEconomyTextCommand,
  parseTelegramCommand,
} from "../../shared/telegramCommands";
import {
  claimDaily,
  claimSalary,
  formatRemaining,
  getBalance,
  wealthLeaderboard,
  type EconomyIdentity,
  handleStarsPreCheckout,
  fulfillStarsPayment,
  syncTelegramProfile,
} from "./economy";
import {
  handleGroupCallback,
  handleGroupCommand,
  handleGroupMessage,
  startGroupGameWorker,
} from "./groupGame";
import {
  isTelegramAdmin,
  telegramBotTokenConfigured,
  telegramBotUsername,
  telegramCall,
  type TelegramMessage,
  type TelegramUser,
} from "./telegramApi";
import { handleWagerCallback, handleWagerMessage, startWagerWorker } from "./chatWagers";
import {
  formatChatPrank,
  isEligibleChatPrankReply,
  parseChatPrank,
} from "./chatPranks";

const ROOM_CODE = /^[A-HJ-NP-Z2-9]{4,8}$/i;
const handledUpdates = new Map<number, Promise<void>>();

export type BotUpdate = {
  update_id?: number;
  message?: TelegramMessage & { successful_payment?: { currency: string; total_amount: number; invoice_payload: string; telegram_payment_charge_id: string } };
  pre_checkout_query?: { id: string; from: TelegramUser; currency: string; total_amount: number; invoice_payload: string };
  callback_query?: {
    id: string;
    from: TelegramUser;
    data?: string;
    message?: TelegramMessage;
  };
};

function botToken() {
  return process.env.TELEGRAM_BOT_TOKEN || "";
}
function webhookSecret() {
  const configured = process.env.TELEGRAM_WEBHOOK_SECRET?.trim();
  if (configured) return configured;
  const token = botToken();
  return token
    ? createHash("sha256")
        .update("spyfall:telegram-webhook:v1\0")
        .update(token)
        .digest("hex")
    : "";
}
function botUsername() {
  return telegramBotUsername();
}
function appUrl(code?: string, page?: string) {
  const configured = process.env.TELEGRAM_WEBAPP_URL?.trim();
  if (!configured) return null;
  try {
    const url = new URL(configured);
    if (process.env.NODE_ENV === "production" && url.protocol !== "https:")
      return null;
    if (code) url.searchParams.set("startapp", code);
    if (page) url.searchParams.set("view", page);
    return url.toString();
  } catch {
    return null;
  }
}

function miniAppDeepLink(startParam?: string) {
  const username = botUsername();
  if (!username) return null;
  const appName = process.env.TELEGRAM_APP_SHORT_NAME?.trim();
  const base = appName
    ? `https://t.me/${username}/${encodeURIComponent(appName)}`
    : `https://t.me/${username}`;
  return startParam
    ? `${base}?startapp=${encodeURIComponent(startParam)}`
    : base;
}

export function buildTelegramInviteLink(code: string) {
  const deepLink = miniAppDeepLink(code.toUpperCase());
  if (!deepLink || !ROOM_CODE.test(code)) return null;
  return deepLink;
}

function miniAppButtonLabel(page?: string) {
  if (page === "inventory") return "Відкрити інвентар";
  if (page === "shop") return "Відкрити магазин";
  if (page === "top") return "Рейтинг монет";
  if (page === "economy" || page === "wallet")
    return "Відкрити гаманець і магазин";
  return "Запустити ШПИГУН";
}

function webAppMarkup(code?: string, page?: string) {
  const target = appUrl(code, page);
  if (!target) return undefined;
  return {
    inline_keyboard: [
      [
        {
          text: code ? "Відкрити операцію" : miniAppButtonLabel(page),
          web_app: { url: target },
        },
      ],
    ],
  };
}

function directLinkMarkup(code?: string, page?: string) {
  const link = code
    ? buildTelegramInviteLink(code)
    : miniAppDeepLink(page || undefined);
  if (!link) return undefined;
  return {
    inline_keyboard: [
      [
        {
          text: code ? "Відкрити кімнату в Telegram" : miniAppButtonLabel(page),
          url: link,
        },
      ],
    ],
  };
}

async function sendBotMessage(
  chatId: number,
  text: string,
  code?: string,
  isPrivate = true,
  page?: string
) {
  const chatMarkup =
    (isPrivate ? webAppMarkup(code, page) : undefined) ||
    directLinkMarkup(code, page);
  await telegramCall("sendMessage", {
    chat_id: chatId,
    text,
    ...(chatMarkup ? { reply_markup: chatMarkup } : {}),
    disable_web_page_preview: true,
  });
}

function identityFromTelegram(user: TelegramUser): EconomyIdentity {
  return {
    id: String(user.id),
    firstName: user.first_name?.trim() || "Агент",
    lastName: user.last_name?.trim() || null,
    username: user.username || null,
  };
}

function displayTelegramName(user: TelegramUser) {
  return (
    [user.first_name?.trim(), user.last_name?.trim()]
      .filter((part): part is string => Boolean(part))
      .join(" ") ||
    (user.username ? `@${user.username}` : "Гравець")
  );
}

async function sendText(chatId: number, text: string, markup?: unknown) {
  await telegramCall("sendMessage", {
    chat_id: chatId,
    text,
    ...(markup ? { reply_markup: markup } : {}),
    disable_web_page_preview: true,
  });
}

async function sendHtmlText(chatId: number, text: string) {
  await telegramCall("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
  });
}

function secretMatches(received: string | undefined, expected: string) {
  if (!received || !expected) return false;
  const left = Buffer.from(received, "utf8");
  const right = Buffer.from(expected, "utf8");
  return left.length === right.length && timingSafeEqual(left, right);
}

async function sendSalary(message: TelegramMessage, updateId: string) {
  if (!message.from) return;
  const result = await claimSalary(
    identityFromTelegram(message.from),
    updateId
  );
  const chatId = message.chat.id;
  if (result.claimed)
    await sendText(
      chatId,
      `💼 Зарплата агента: +${result.amount} 🪙. Баланс: ${result.balance} 🪙.\nНаступна виплата через 2 години.`
    );
  else
    await sendText(
      chatId,
      `⏳ Наступна зарплата буде доступна через ${formatRemaining(result.remainingMs)}. Баланс: ${result.balance} 🪙.`
    );
}

async function sendDaily(message: TelegramMessage, updateId: string) {
  if (!message.from) return;
  const result = await claimDaily(identityFromTelegram(message.from), updateId);
  const chatId = message.chat.id;
  if (result.claimed) {
    await sendText(
      chatId,
      `🎁 Бонус: +${result.amount} 🪙. Баланс: ${result.balance} 🪙.`
    );
  } else
    await sendText(
      chatId,
      `⏳ Наступний бонус буде доступний через ${formatRemaining(result.remainingMs)}. Баланс: ${result.balance} 🪙.`
    );
}

async function sendBalance(message: TelegramMessage) {
  if (!message.from) return;
  const identity = identityFromTelegram(message.from);
  const wallet = await getBalance(identity);
  const vip = wallet.vipUntil && new Date(wallet.vipUntil).getTime() > Date.now()
    ? `VIP 👑 до ${new Intl.DateTimeFormat("uk-UA", { dateStyle: "medium", timeStyle: "short" }).format(new Date(wallet.vipUntil))}`
    : "VIP не активний";
  await sendText(
    message.chat.id,
    `🪙 ${wallet.balance} монет · 💎 ${wallet.crystals || 0} кристалів\n${vip}\nЗарплата: «зп» або «зарплата»; бонус: «бонус».`
  );
}

async function sendCoinTop(message: TelegramMessage) {
  const players = await wealthLeaderboard(10);
  const lines = players.map(
    (player, index) =>
      `${index + 1}. ${player.username ? `@${player.username}` : [player.firstName, player.lastName].filter(Boolean).join(" ") || "Агент"} — ${player.balance} 🪙`
  );
  await sendText(
      message.chat.id,
      lines.length
        ? `🏆 Рейтинг за монетами\n\n${lines.join("\n")}`
        : "Поки що рейтинг порожній. Заробляйте монети словами «зп»/«зарплата» та «бонус»."
  );
}

async function sendHelp(message: TelegramMessage) {
  const isPrivate = message.chat.type === "private";
  const text = isPrivate
    ? "🕵️ ШПИГУН — гра на соціальну дедукцію.\n\nОсновна партія проходить у груповому чаті: адміністратор додає бота й надає йому потрібні права, але будь-який учасник створює лобі командою /game. Після набору щонайменше 3 гравців будь-який учасник чату може запустити гру кнопкою або /startgame. Ролі приходять приватно. У групі спершу обирають підозрюваного, потім тим самим повідомленням голосують 👍 за страту чи 👎 за помилування; кожна фаза триває 60 секунд. Страта шпигуна одразу завершує гру перемогою агентів; страчений агент вибуває, а при 1 агенті та 1 шпигуні перемагає шпигун. Категорія відкривається лише у фіналі.\n\nОсновні економічні слова: «баланс» або «балік», «зп» або «зарплата», «бонус», «топ мажорів» або «топ». Магазин та інвентар: /shop, /inventory. Переможці Telegram-групової гри отримують по 10 🪙. Mini App містить ігровий центр, профіль, гаманець та магазин."
    : "🕵️ Команди групової гри: /game, /join, /leave, /players, /startgame, /stopgame, /rules, /stats. Будь-який учасник чату може створити лобі й запустити партію після набору 3 гравців.\n\nРолі приходять приватно; категорія не показується в групі до фіналу. Голосування: спершу оберіть підозрюваного, потім тим самим повідомленням проголосуйте 👍 за страту або 👎 проти; обидві фази тривають по 60 секунд. Вибулі не діють і не голосують. Страта шпигуна одразу завершує гру перемогою агентів; гра після страти агента триває до 1 агента й 1 шпигуна, коли перемагає шпигун. Переможці отримують 10 🪙. Економіка: «баланс» або «балік», «зп» або «зарплата», «бонус», «топ мажорів» або «топ»; магазин та інвентар: /shop, /inventory.";
  await sendBotMessage(
    message.chat.id,
    text,
    undefined,
    isPrivate,
    isPrivate ? "economy" : undefined
  );
}

async function processCommand(message: TelegramMessage, updateId: string) {
  const text = message.text?.trim();
  if (!text) return;
  const parsed = parseTelegramCommand(text);
  const textCommand = parseEconomyTextCommand(text)?.command;
  const legacyDailyText = /^daily$/iu.test(text);
  const command = parsed?.command ?? textCommand ?? (legacyDailyText ? "daily" : undefined);
  if (!command) return;

  if (command === "terms") {
    return sendText(message.chat.id, "Умови: кристали 💎 — віртуальний цифровий товар для функцій Mini App, вони не є грошима та не можуть бути виведені. Пакети оплачуються Telegram Stars (XTR); перед оплатою Telegram показує остаточну суму. Цифрові товари зараховуються після підтвердження платежу сервером. Для питань щодо покупки використайте /paysupport та додайте номер замовлення або опис проблеми.");
  }
  if (command === "paysupport") {
    if (message.chat.type !== "private" || !message.from) {
      return sendText(message.chat.id, "Для безпеки платіжну підтримку відкрийте в особистому чаті з ботом: /paysupport опис проблеми.");
    }
    const details = parsed?.args.join(" ").trim();
    if (!details) {
      return sendText(message.chat.id, "Опишіть проблему командою /paysupport, додавши invoice/order ID або Telegram payment charge ID. Не надсилайте реквізити карток чи коди підтвердження.");
    }
    const adminIds = (process.env.ADMIN_IDS || process.env.SPY_ADMIN_IDS || "").split(/[ ,]+/).filter(Boolean);
    if (!adminIds.length) return sendText(message.chat.id, "Платіжна підтримка наразі недоступна: адміністратора не налаштовано.");
    const sender = message.from.username ? `@${message.from.username}` : `${message.from.first_name || "Гравець"} (ID ${message.from.id})`;
    await Promise.all(adminIds.map(id => sendText(Number(id), `Звернення /paysupport від ${sender} · Telegram ID ${message.from!.id}\n${details.slice(0, 1200)}`)));
    return sendText(message.chat.id, "Звернення надіслано адміністрації. Не надсилайте дані картки або коди безпеки.");
  }

  if (command === "zp") return sendSalary(message, updateId);
  if (command === "daily" || command === "щодня")
    return sendDaily(message, updateId);

  const isPrivate = message.chat.type === "private";

  if (!isPrivate && parsed) {
    if (await handleGroupCommand(message, parsed.command, parsed.args)) return;
    if (
      parsed.command === "game" ||
      parsed.command === "startgame" ||
      parsed.command === "stopgame" ||
      parsed.command === "join" ||
      parsed.command === "leave"
    ) {
      await sendText(
        message.chat.id,
        "Команди групової гри працюють у груповому чаті."
      );
      return;
    }
  }

  if (command === "start" || command === "play") {
    const args = parsed?.args || [];
    const rawCode = args[0]?.replace(/^(?:invite[_:-]?)?/i, "").toUpperCase();
    const code = rawCode && ROOM_CODE.test(rawCode) ? rawCode : undefined;
    const name = message.from?.first_name?.trim() || "Агенте";
    const welcome = code
      ? `Вітаю, ${name}! Для вас є запрошення до кімнати ${code}. Відкрийте його в Telegram.`
      : `Вітаю, ${name}! Це оперативний центр «ШПИГУН». Основна гра проходить у груповому чаті: додайте бота до групи з потрібними правами; будь-який учасник може створити /game, долучити щонайменше 3 гравців і натиснути запуск або ввести /startgame.`;
    await sendBotMessage(
      message.chat.id,
      welcome,
      code,
      isPrivate,
      isPrivate ? "economy" : undefined
    );
    return;
  }
  if (command === "help") return sendHelp(message);
  if (command === "balance" || command === "bal") return sendBalance(message);
  if (command === "top") return sendCoinTop(message);
  if (command === "shop" || command === "inventory") {
    await sendBotMessage(
      message.chat.id,
      command === "inventory"
        ? "Відкрийте інвентар своїх косметичних предметів у Mini App."
        : "Відкрийте гаманець і каталог косметики в Mini App.",
      undefined,
      isPrivate,
      command === "inventory" ? "inventory" : "shop"
    );
    return;
  }
  if (command === "rules") {
    await sendText(
      message.chat.id,
      "Шпигун не знає секрет. Спочатку оберіть підозрюваного; потім те саме повідомлення перемкнеться на 👍 стратити або 👎 помилувати. Кожна фаза триває повні 60 секунд, а більшість не зупиняє її раніше. Для страти потрібна сувора більшість активних гравців; вибулі не голосують і не діють. Страта шпигуна одразу завершує гру перемогою агентів; якщо страчено агента, гра триває до 1 агента й 1 шпигуна — тоді перемагає шпигун. Переможці отримують 10 🪙. Категорія відкривається лише після фіналу; бот один раз оголошує результат."
    );
    return;
  }
  if (
    command === "game" ||
    command === "startgame" ||
    command === "stopgame" ||
    command === "join" ||
    command === "leave" ||
    command === "players" ||
    command === "stats"
  ) {
    await sendText(
      message.chat.id,
      "Цю команду потрібно запускати у груповому чаті, де встановлено бота."
    );
    return;
  }
}

async function processUpdate(update: BotUpdate) {
  const updateId = String(update.update_id ?? randomUUID());
  if (update.message?.successful_payment && update.message.from) {
    await syncTelegramProfile(identityFromTelegram(update.message.from));
    const payment = update.message.successful_payment;
    const result = await fulfillStarsPayment({
      telegramId: String(update.message.from.id),
      payload: payment.invoice_payload,
      currency: payment.currency,
      totalAmount: payment.total_amount,
      chargeId: payment.telegram_payment_charge_id,
    });
    await sendText(update.message.chat.id, result.duplicate ? "Цей платіж уже був зарахований." : `Оплату підтверджено. Зараховано ${result.crystals} 💎.`);
    return;
  }
  if (update.callback_query) {
    if (await handleWagerCallback(update.callback_query)) return;
    await handleGroupCallback(update.callback_query);
    return;
  }
  const message = update.message;
  if (!message || !message.chat) return;
  if (message.from) await syncTelegramProfile(identityFromTelegram(message.from));
  const isGroup =
    message.chat.type === "group" || message.chat.type === "supergroup";
  if (isGroup && (await handleWagerMessage(message))) return;
  if (isGroup && message.text && message.from) {
    const prank = parseChatPrank(message.text);
    const targetUser = message.reply_to_message?.from;
    if (prank && isEligibleChatPrankReply(message.from, targetUser)) {
      const response = formatChatPrank(
        prank.action,
        { id: message.from.id, name: displayTelegramName(message.from) },
        { id: targetUser!.id, name: displayTelegramName(targetUser!) },
        prank.suffix
      );
      if (response) {
        await sendHtmlText(message.chat.id, response);
        return;
      }
    }
  }
  if (message.text && parseEconomyTextCommand(message.text)) {
    await processCommand(message, updateId);
    return;
  }
  if (isGroup && (await handleGroupMessage(message))) return;
  await processCommand(message, updateId);
}

async function claimUpdate(updateId: number) {
  const db = await getDb();
  if (!db) throw new Error("Telegram update ledger database is unavailable");
  return db.transaction(async (tx: any) => {
    const rows = await tx
      .select()
      .from(spyTelegramUpdates)
      .where(eq(spyTelegramUpdates.updateId, String(updateId)))
      .limit(1)
      .for("update");
    const row = rows[0];
    if (row?.status === "done") return false;
    if (
      row?.status === "processing" &&
      Date.now() - new Date(row.updatedAt).getTime() < 60_000
    )
      return false;
    if (row) {
      await tx
        .update(spyTelegramUpdates)
        .set({
          status: "processing",
          attempts: row.attempts + 1,
          lastError: null,
        })
        .where(eq(spyTelegramUpdates.updateId, String(updateId)));
    } else {
      await tx
        .insert(spyTelegramUpdates)
        .values({
          updateId: String(updateId),
          status: "processing",
          attempts: 1,
          lastError: null,
        });
    }
    return true;
  });
}

async function markUpdate(
  updateId: number,
  status: "done" | "failed",
  error?: string
) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(spyTelegramUpdates)
    .set({ status, lastError: error?.slice(0, 500) || null })
    .where(eq(spyTelegramUpdates.updateId, String(updateId)));
}

export function registerTelegramBotRoutes(app: Express) {
  startGroupGameWorker();
  startWagerWorker();
  app.post("/api/telegram/webhook", async (req: Request, res: Response) => {
    const token = botToken();
    const secret = webhookSecret();
    if (!token || !secret)
      return res
        .status(503)
        .json({ ok: false, error: "Telegram bot webhook is not configured." });
    if (!secretMatches(req.get("x-telegram-bot-api-secret-token"), secret))
      return res.status(403).json({ ok: false });
    const update = req.body as BotUpdate;
    if (update.pre_checkout_query) {
      void handleStarsPreCheckout(update.pre_checkout_query).catch(error => {
        console.error("[Telegram Stars pre-checkout]", error instanceof Error ? error.message : String(error));
      });
      return res.status(200).json({ ok: true });
    }
    const id = update.update_id;
    if (typeof id === "number" && handledUpdates.has(id)) {
      try {
        await handledUpdates.get(id);
        return res.status(200).json({ ok: true });
      } catch {
        handledUpdates.delete(id);
      }
    }
    const processing = (async () => {
      const claimed = typeof id === "number" ? await claimUpdate(id) : true;
      if (!claimed) return;
      try {
        await processUpdate(update);
        if (typeof id === "number") await markUpdate(id, "done");
      } catch (error) {
        if (typeof id === "number")
          await markUpdate(
            id,
            "failed",
            error instanceof Error ? error.message : String(error)
          );
        throw error;
      }
    })();
    if (typeof id === "number") handledUpdates.set(id, processing);
    try {
      await processing;
      if (handledUpdates.size > 1000)
        handledUpdates.delete(handledUpdates.keys().next().value as number);
      return res.status(200).json({ ok: true });
    } catch (error) {
      if (typeof id === "number") handledUpdates.delete(id);
      console.error(
        "[Telegram bot update]",
        error instanceof Error ? error.message : String(error)
      );
      return res.status(500).json({ ok: false });
    }
  });

  app.get("/api/telegram/status", (_req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json({
      configured: Boolean(
        botToken() && webhookSecret() && appUrl() && botUsername()
      ),
      botUsername: botUsername() || null,
      groupCommands: [
        "game",
        "join",
        "leave",
        "players",
        "startgame",
        "stopgame",
        "rules",
        "stats",
      ],
      economyCommands: ["balance", "zp", "daily", "top", "shop", "inventory"],
      economyTextTriggers: economyTextCommands.flatMap(entry => [...entry.triggers]),
    });
  });
}

export async function notifyRoomPlayers(
  userIds: string[],
  text: string,
  code?: string
) {
  if (!botToken()) return;
  const recipients = [...new Set(userIds)].filter(id => /^\d+$/.test(id));
  await Promise.allSettled(
    recipients.map(id =>
      telegramCall("sendMessage", {
        chat_id: Number(id),
        text,
        ...(code && webAppMarkup(code)
          ? { reply_markup: webAppMarkup(code) }
          : {}),
        disable_web_page_preview: true,
      })
    )
  );
}

const deliveredEvents = new Map<string, Promise<void>>();
export function notifyRoomEventOnce(
  key: string,
  userIds: string[],
  text: string,
  code?: string
) {
  if (deliveredEvents.has(key)) return deliveredEvents.get(key);
  const pending = notifyRoomPlayers(userIds, text, code).catch(error => {
    console.error(
      "[Telegram notification]",
      error instanceof Error ? error.message : String(error)
    );
  });
  deliveredEvents.set(key, pending);
  if (deliveredEvents.size > 500)
    deliveredEvents.delete(deliveredEvents.keys().next().value as string);
  return pending;
}

export function telegramBotConfigured() {
  return Boolean(
    telegramBotTokenConfigured() && webhookSecret() && appUrl() && botUsername()
  );
}
