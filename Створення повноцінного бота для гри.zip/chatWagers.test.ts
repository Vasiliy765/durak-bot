import { describe, expect, it } from "vitest";
import {
  calculateWager,
  WAGER_TIMEOUT_MESSAGE,
  diceSendFailurePolicy,
  MAX_DICE_SEND_FAILURES,
  mayAccept,
  mayDecline,
  parseWager,
  tiePolicy,
  MAX_ACTIVE_CHALLENGES_PER_CREATOR,
  wagerChallengeLimitReached,
} from "./chatWagers";

describe("group wager rules", () => {
  it("uses the exact challenge timeout notice", () => {
    expect(WAGER_TIMEOUT_MESSAGE).toBe("⏳ Час виклику вийшов, гру скасовано");
  });
  it("limits each creator to five concurrent challenges globally", () => {
    expect(MAX_ACTIVE_CHALLENGES_PER_CREATOR).toBe(5);
    expect(wagerChallengeLimitReached(4)).toBe(false);
    expect(wagerChallengeLimitReached(5)).toBe(true);
  });
  it("parses exact Ukrainian ordinary-text wager phrases and stake limits", () => {
    expect(parseWager("Зіграти в монетку 50 @agent_name")).toEqual({ game: "coin", stake: 50, username: "agent_name" });
    expect(parseWager("Зіграти в кубики 10")).toEqual({ game: "dice", stake: 10 });
    expect(parseWager("Зіграти в кубики 101")).toBeNull();
    expect(parseWager("please play dice 50")).toBeNull();
  });
  it("rounds aggregate fee and computes winner payout", () => {
    expect(calculateWager(50)).toEqual({ pot: 100, fee: 5, payout: 95 });
    expect(calculateWager(10)).toEqual({ pot: 20, fee: 1, payout: 19 });
    expect(calculateWager(25)).toEqual({ pot: 50, fee: 3, payout: 47 });
    for (const stake of [10, 25, 50, 100]) {
      const { pot, fee, payout } = calculateWager(stake);
      expect(fee + payout).toBe(pot);
    }
  });
  it("rerolls ties and otherwise selects the higher die", () => {
    expect(tiePolicy(4, 4)).toBe("reroll");
    expect(tiePolicy(6, 2)).toBe("challenger");
    expect(tiePolicy(1, 3)).toBe("opponent");
  });
  it("bounds consecutive Telegram Dice send failures and refunds on the final attempt", () => {
    expect(diceSendFailurePolicy(0)).toEqual({ failureCount: 1, shouldRefund: false });
    expect(diceSendFailurePolicy(1)).toEqual({ failureCount: 2, shouldRefund: false });
    expect(diceSendFailurePolicy(MAX_DICE_SEND_FAILURES - 1)).toEqual({
      failureCount: MAX_DICE_SEND_FAILURES,
      shouldRefund: true,
    });
  });
  it("restricts targeted invites and forbids self-acceptance", () => {
    const base = { challengerId: "1", status: "pending", now: 10, expiresAt: 20 };
    expect(mayAccept({ ...base, actorId: "2", opponentId: "2" })).toBe(true);
    expect(mayAccept({ ...base, actorId: "3", opponentId: "2" })).toBe(false);
    expect(mayAccept({ ...base, actorId: "1", opponentId: null })).toBe(false);
    expect(mayAccept({ ...base, actorId: "2", opponentId: null, now: 21 })).toBe(false);
  });
  it("allows only the invited opponent to decline a targeted challenge", () => {
    const base = { challengerId: "1", opponentId: "2", status: "pending", now: 10, expiresAt: 20 };
    expect(mayDecline({ ...base, actorId: "2" })).toBe(true);
    expect(mayDecline({ ...base, actorId: "1" })).toBe(false);
    expect(mayDecline({ ...base, actorId: "3" })).toBe(false);
    expect(mayDecline({ ...base, actorId: "2", now: 21 })).toBe(false);
    expect(mayDecline({ ...base, opponentId: null, actorId: "3" })).toBe(true);
  });
});
