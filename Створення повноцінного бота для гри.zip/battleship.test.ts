import { describe, expect, it } from "vitest";
import { GameRuleError, type ArcadePlayer } from "./engine.js";
import {
  battleshipEngine,
  type BattleshipState,
  type ShipPlacement,
} from "./battleship.js";

const players: ArcadePlayer[] = [
  { id: "a", name: "A", seat: 0 },
  { id: "b", name: "B", seat: 1 },
];
let now = 1_000;
const ctx = (random = 0) => ({ now, randomInt: (_max: number) => random });
const fleet: ShipPlacement[] = [
  { x: 0, y: 0, length: 4, orientation: "horizontal" },
  { x: 0, y: 2, length: 3, orientation: "horizontal" },
  { x: 5, y: 0, length: 3, orientation: "vertical" },
  { x: 0, y: 4, length: 2, orientation: "horizontal" },
  { x: 3, y: 4, length: 2, orientation: "horizontal" },
  { x: 6, y: 4, length: 2, orientation: "horizontal" },
  { x: 0, y: 6, length: 1, orientation: "horizontal" },
  { x: 2, y: 6, length: 1, orientation: "horizontal" },
  { x: 4, y: 6, length: 1, orientation: "horizontal" },
  { x: 6, y: 6, length: 1, orientation: "horizontal" },
];
function create(extraShotOnHit = false) {
  return battleshipEngine.create(
    players,
    { extraShotOnHit, turnMs: 10_000 },
    ctx()
  ) as BattleshipState;
}
function place(state: BattleshipState, id: string, layout = fleet) {
  return battleshipEngine.applyAction(
    state,
    id,
    { type: "place", ships: layout },
    ctx()
  ).state;
}
function ready(state: BattleshipState, id: string) {
  return battleshipEngine.applyAction(state, id, { type: "ready" }, ctx())
    .state;
}
function start(extra = false) {
  let state = place(create(extra), "a");
  state = place(state, "b");
  state = ready(state, "a");
  return ready(state, "b");
}
function act(
  state: BattleshipState,
  id: string,
  type: string,
  coords: object = {}
) {
  return battleshipEngine.applyAction(state, id, { type, ...coords }, ctx());
}
function throwsRule(fn: () => unknown, code?: string) {
  try {
    fn();
    throw new Error("expected rule error");
  } catch (error) {
    expect(error).toBeInstanceOf(GameRuleError);
    if (code) expect((error as GameRuleError).code).toBe(code);
  }
}

describe("battleshipEngine", () => {
  it("accepts complete standard fleet, places manually, begins only once both are ready", () => {
    let s = create();
    s = place(s, "a");
    expect(s.phase).toBe("placing");
    s = ready(s, "a");
    expect(s.phase).toBe("placing");
    s = place(s, "b");
    s = ready(s, "b");
    expect(s.phase).toBe("playing");
    expect(s.currentPlayerId).toBe("a");
  });
  it("preserves placing view contract and validates server-generated auto fleets", () => {
    const initial = create();
    expect(battleshipEngine.toView(initial, "a")).toMatchObject({
      phase: "placing",
      ownBoard: { ships: [] },
      ready: false,
      opponentReady: false,
    });
    const placed = battleshipEngine.applyAction(
      initial,
      "a",
      { type: "auto_place" },
      { now, randomInt: max => max - 1 }
    ).state;
    expect(placed.boards.a.ships).toHaveLength(10);
    const proposed = placed.boards.a.ships.map(ship => {
      const first = ship.cells[0]!;
      return {
        x: first.x,
        y: first.y,
        length: ship.cells.length,
        orientation:
          ship.cells.length < 2 || ship.cells[1]!.x !== first.x
            ? ("horizontal" as const)
            : ("vertical" as const),
      };
    });
    expect(() =>
      battleshipEngine.applyAction(
        initial,
        "a",
        { type: "place", ships: proposed },
        ctx()
      )
    ).not.toThrow();
  });
  it("rejects wrong fleet count/length, out-of-bounds, overlap and diagonal adjacency", () => {
    throwsRule(() => place(create(), "a", fleet.slice(0, 9)));
    const wrongLength = fleet.map((s, i) =>
      i === 0 ? { ...s, length: 3 } : s
    );
    throwsRule(() => place(create(), "a", wrongLength));
    const edge = fleet.map((s, i) => (i === 0 ? { ...s, x: 7 } : s));
    throwsRule(() => place(create(), "a", edge), "OUT_OF_BOUNDS");
    const overlap = fleet.map((s, i) => (i === 1 ? { ...s, x: 1, y: 0 } : s));
    throwsRule(() => place(create(), "a", overlap), "INVALID_FLEET");
    const diagonal = fleet.map((s, i) => (i === 1 ? { ...s, x: 4, y: 4 } : s));
    throwsRule(() => place(create(), "a", diagonal), "INVALID_FLEET");
  });
  it("hides opponent fleet while exposing own ships and shot outcome/remaining count", () => {
    let s = start();
    const v = battleshipEngine.toView(s, "a");
    expect(v.ownBoard.ships).toHaveLength(10);
    expect(v.opponent).not.toHaveProperty("ships");
    expect(JSON.stringify(v.opponent)).not.toContain('"x":0,"y":0');
    const shooter = s.currentPlayerId!;
    const target = shooter === "a" ? "b" : "a";
    const miss = act(s, shooter, "shoot", { x: 9, y: 9 });
    s = miss.state;
    expect(miss.events[0].type).toBe("miss");
    expect(battleshipEngine.toView(s, shooter).opponent.shots).toContainEqual({
      x: 9,
      y: 9,
      result: "miss",
    });
    expect(
      battleshipEngine.toView(s, target).ownBoard.shotsReceived
    ).toContainEqual({ x: 9, y: 9, result: "miss" });
    expect(battleshipEngine.toView(s, target).opponent).not.toHaveProperty(
      "ships"
    );
  });
  it("offers only unshot coordinates to the active player", () => {
    let s = start();
    const actor = s.currentPlayerId!;
    expect(battleshipEngine.toView(s, actor).legalActions).toHaveLength(100);
    s = act(s, actor, "shoot", { x: 9, y: 9 }).state;
    const nextActor = s.currentPlayerId!;
    expect(battleshipEngine.toView(s, nextActor).legalActions).toHaveLength(
      100
    );
    s = act(s, nextActor, "shoot", { x: 9, y: 9 }).state;
    expect(
      battleshipEngine.toView(s, s.currentPlayerId!).legalActions
    ).toHaveLength(99);
    expect(
      battleshipEngine.toView(s, s.currentPlayerId === "a" ? "b" : "a")
        .legalActions
    ).toEqual([]);
  });
  it("rejects repeat shots, wrong player and invalid action without mutating original state", () => {
    const s = start(true);
    const shooter = s.currentPlayerId!;
    const other = shooter === "a" ? "b" : "a";
    throwsRule(() => act(s, other, "shoot", { x: 1, y: 1 }), "NOT_YOUR_TURN");
    throwsRule(
      () => act(s, "outsider", "shoot", { x: 1, y: 1 }),
      "NOT_A_PLAYER"
    );
    throwsRule(() => act(s, shooter, "explode", { x: 1, y: 1 }));
    const after = act(s, shooter, "shoot", { x: 0, y: 0 }).state;
    throwsRule(
      () => act(after, shooter, "shoot", { x: 0, y: 0 }),
      "REPEAT_SHOT"
    );
    expect(s.boards[other].shotsReceived).toHaveLength(0);
  });
  it("handles hit, miss, sinking, optional extra shot and winner", () => {
    let s = start(false);
    let actor = s.currentPlayerId!;
    let defender = actor === "a" ? "b" : "a";
    // Shoot a known cell of defender's first ship; guaranteed initial actor selected via deterministic random.
    let result = act(s, actor, "shoot", { x: 0, y: 0 });
    expect(result.events[0].type).toBe("hit");
    s = result.state;
    expect(s.currentPlayerId).toBe(defender);
    s = start(true);
    actor = s.currentPlayerId!;
    defender = actor === "a" ? "b" : "a";
    result = act(s, actor, "shoot", { x: 0, y: 0 });
    expect(result.events[0].type).toBe("hit");
    expect(result.state.currentPlayerId).toBe(actor);
    // Remove 20-segment opposing fleet through valid, alternating shots to prove authoritative win/sink.
    s = start(true);
    actor = s.currentPlayerId!;
    defender = actor === "a" ? "b" : "a";
    const cells = fleet.flatMap(p =>
      Array.from({ length: p.length }, (_, i) => ({
        x: p.x + (p.orientation === "horizontal" ? i : 0),
        y: p.y + (p.orientation === "vertical" ? i : 0),
      }))
    );
    let last = "";
    for (const c of cells) {
      const step = act(s, actor, "shoot", c);
      last = step.events[0].type;
      s = step.state;
    }
    expect(last).toBe("sunk");
    expect(s.phase).toBe("finished");
    expect(s.outcome?.winnerIds).toEqual([actor]);
    expect(
      s.boards[defender].ships.reduce((n, ship) => n + ship.hits.length, 0)
    ).toBe(20);
  });
  it("forfeits the player on deadline and does nothing before deadline", () => {
    let s = start();
    now = s.deadline! - 1;
    expect(battleshipEngine.onTimeout!(s, ctx())).toBeNull();
    now = s.deadline!;
    const step = battleshipEngine.onTimeout!(s, ctx())!;
    expect(step.state.phase).toBe("finished");
    expect(step.outcome?.winnerIds).toEqual([
      s.players.find(p => p.id !== s.currentPlayerId)!.id,
    ]);
    expect(step.events[0].type).toBe("timeout_forfeit");
  });
});
