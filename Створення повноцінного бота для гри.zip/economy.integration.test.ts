import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { randomUUID } from "node:crypto";
import { eq, inArray } from "drizzle-orm";
import { getDb } from "../db";
import {
  spyEconomyLedger,
  spyInventory,
  spyProfiles,
  spyWallets,
} from "../../drizzle/schema";
import {
  claimDaily,
  claimSalary,
  awardGameRewardTx,
  equipInventoryItem,
  getBalance,
  listInventory,
  listShopItems,
  purchaseShopItem,
  type EconomyIdentity,
} from "./economy";
import { updateProfilesForResult } from "./resultService";

const enabled = process.env.RUN_ECONOMY_DB_TESTS === "1";
const suffix = randomUUID();
const identities: EconomyIdentity[] = [0, 1, 2].map(index => ({
  id: `e2e-${suffix}-${index}`,
  firstName: `Тестовий агент ${index + 1}`,
}));
const ids = identities.map(identity => identity.id);
let db: Awaited<ReturnType<typeof getDb>> | null = null;

describe.skipIf(!enabled)(
  "economy database integration (opt-in; uses temporary synthetic users)",
  () => {
    beforeAll(async () => {
      db = await getDb();
      expect(
        db,
        "DATABASE_URL must point to a migrated MySQL/TiDB database"
      ).toBeTruthy();
      await Promise.all(identities.map(identity => getBalance(identity)));
    });

    afterAll(async () => {
      if (!db) return;
      await db
        .delete(spyInventory)
        .where(inArray(spyInventory.telegramId, ids));
      await db
        .delete(spyEconomyLedger)
        .where(inArray(spyEconomyLedger.telegramId, ids));
      await db.delete(spyWallets).where(inArray(spyWallets.telegramId, ids));
      await db.delete(spyProfiles).where(inArray(spyProfiles.telegramId, ids));
      await (db as any).$client?.end?.();
    });

    it("serializes reward claims and debits purchases atomically, then updates the shared game profile", async () => {
      const participants = identities.map((identity, index) => ({
        id: identity.id,
        firstName: identity.firstName,
        role: index === 0 ? ("spy" as const) : ("civilian" as const),
      }));
      const roundId = `e2e-round-${suffix}`;
      await db!.transaction(tx =>
        updateProfilesForResult(tx, {
          roundId,
          winner: "spies",
          players: participants,
          durationSeconds: 180,
          xpParticipation: 25,
          xpWin: 35,
          winnerRewardOverride: 10,
        })
      );

      const profiles = await db!
        .select()
        .from(spyProfiles)
        .where(inArray(spyProfiles.telegramId, ids));
      const spyProfile = profiles.find(
        profile => profile.telegramId === identities[0]!.id
      )!;
      const civilianProfiles = profiles.filter(
        profile => profile.telegramId !== identities[0]!.id
      );
      expect(spyProfile).toMatchObject({
        gamesPlayed: 1,
        wins: 1,
        spyWins: 1,
        xp: 60,
      });
      expect(civilianProfiles).toHaveLength(2);
      expect(
        civilianProfiles.every(
          profile =>
            profile.gamesPlayed === 1 &&
            profile.losses === 1 &&
            profile.xp === 25
        )
      ).toBe(true);

      const rewardRows = await db!
        .select()
        .from(spyEconomyLedger)
        .where(eq(spyEconomyLedger.referenceId, roundId));
      expect(rewardRows.map(row => row.amount).sort((a, b) => a - b)).toEqual([
        5, 5, 10,
      ]);

      const spy = identities[0]!;
      const duplicateReward = await db!.transaction(tx =>
        awardGameRewardTx(tx, {
          identity: spy,
          roundId,
          won: true,
          participantCount: 3,
          durationSeconds: 180,
        })
      );
      expect(duplicateReward).toMatchObject({ amount: 10, duplicate: true });
      const balanceBeforeCap = (await getBalance(spy)).balance;
      const capResults = await Promise.all(
        [0, 1, 2].map(index =>
          db!.transaction(tx =>
            awardGameRewardTx(tx, {
              identity: spy,
              roundId: `e2e-cap-${suffix}-${index}`,
              won: true,
              participantCount: 3,
              durationSeconds: 180,
            })
          )
        )
      );
      expect(capResults.filter(Boolean)).toHaveLength(2);
      expect(capResults.filter(result => result === null)).toHaveLength(1);
      expect((await getBalance(spy)).balance).toBe(balanceBeforeCap + 20);

      const guaranteedWinner = identities[2]!;
      const rewardDate = new Date().toISOString().slice(0, 10);
      await db!
        .update(spyWallets)
        .set({ gameRewardsDate: rewardDate, gameRewardsToday: 3 })
        .where(eq(spyWallets.telegramId, guaranteedWinner.id));
      const guaranteedReward = await db!.transaction(tx =>
        awardGameRewardTx(tx, {
          identity: guaranteedWinner,
          roundId: `e2e-guaranteed-win-${suffix}`,
          won: true,
          participantCount: 3,
          durationSeconds: 5,
          winnerRewardOverride: 10,
        })
      );
      expect(guaranteedReward).toMatchObject({ amount: 10, duplicate: false });
      const duplicateGuaranteedReward = await db!.transaction(tx =>
        awardGameRewardTx(tx, {
          identity: guaranteedWinner,
          roundId: `e2e-guaranteed-win-${suffix}`,
          won: true,
          participantCount: 3,
          durationSeconds: 5,
          winnerRewardOverride: 10,
        })
      );
      expect(duplicateGuaranteedReward).toMatchObject({
        amount: 10,
        duplicate: true,
      });

      const beforeClaims = await getBalance(spy);
      const dailyUpdate = `e2e-daily-${suffix}`;
      const [dailyA, dailyB] = await Promise.all([
        claimDaily(spy, dailyUpdate),
        claimDaily(spy, dailyUpdate),
      ]);
      expect(dailyA.claimed && dailyB.claimed).toBe(true);
      expect([dailyA.duplicate, dailyB.duplicate].filter(Boolean)).toHaveLength(
        1
      );
      expect(
        [dailyA.amount, dailyB.amount].every(
          amount => amount >= 20 && amount <= 100
        )
      ).toBe(true);
      const blockedDaily = await claimDaily(spy, `${dailyUpdate}-next`);
      expect(blockedDaily.claimed).toBe(false);

      const salaryUpdate = `e2e-salary-${suffix}`;
      const [salaryA, salaryB] = await Promise.all([
        claimSalary(spy, salaryUpdate),
        claimSalary(spy, salaryUpdate),
      ]);
      expect(salaryA.claimed && salaryB.claimed).toBe(true);
      expect(
        [salaryA.duplicate, salaryB.duplicate].filter(Boolean)
      ).toHaveLength(1);
      expect(
        [salaryA.amount, salaryB.amount].every(
          amount => amount >= 1 && amount <= 20
        )
      ).toBe(true);
      expect((await claimSalary(spy, `${salaryUpdate}-next`)).claimed).toBe(
        false
      );

      const dailyRows = await db!
        .select()
        .from(spyEconomyLedger)
        .where(eq(spyEconomyLedger.idempotencyKey, `daily:${dailyUpdate}`));
      const salaryRows = await db!
        .select()
        .from(spyEconomyLedger)
        .where(eq(spyEconomyLedger.idempotencyKey, `salary:${salaryUpdate}`));
      expect(dailyRows).toHaveLength(1);
      expect(salaryRows).toHaveLength(1);
      expect((await getBalance(spy)).balance).toBe(
        beforeClaims.balance + dailyA.amount + salaryA.amount
      );

      await db!
        .update(spyWallets)
        .set({ balance: 10_000 })
        .where(eq(spyWallets.telegramId, spy.id));
      const items = await listShopItems();
      const firstBadge = items.find(item => item.itemId === "badge-shadow");
      const secondBadge = items.find(item => item.itemId === "badge-crosshair");
      expect(firstBadge && secondBadge).toBeTruthy();
      const [purchaseA, purchaseB] = await Promise.all([
        purchaseShopItem(spy, firstBadge!.itemId),
        purchaseShopItem(spy, firstBadge!.itemId),
      ]);
      expect(
        [purchaseA.alreadyOwned, purchaseB.alreadyOwned].filter(value => !value)
      ).toHaveLength(1);
      await purchaseShopItem(spy, secondBadge!.itemId);
      await equipInventoryItem(spy, firstBadge!.itemId);
      await equipInventoryItem(spy, secondBadge!.itemId);
      const badgeInventory = (await listInventory(spy)).filter(
        item => item.category === "badge"
      );
      expect(badgeInventory).toHaveLength(2);
      expect(
        badgeInventory.filter(item => item.equipped).map(item => item.itemId)
      ).toEqual([secondBadge!.itemId]);
      expect(
        (
          await db!
            .select()
            .from(spyInventory)
            .where(eq(spyInventory.telegramId, spy.id))
        ).length
      ).toBe(2);
    }, 30_000);
  }
);
