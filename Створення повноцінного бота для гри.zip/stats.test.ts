import { describe, expect, it } from "vitest";
import { aggregateGlobalLeaderboard } from "./stats";

describe("aggregateGlobalLeaderboard", () => {
  it("combines only active game rows into one global row per player", () => {
    const rows = aggregateGlobalLeaderboard([
      {
        telegramId: "u1",
        gameId: "tic_tac_toe",
        gamesPlayed: 4,
        wins: 3,
        losses: 1,
        draws: 0,
        netCoins: 18,
        biggestWin: 12,
        rating: 1120,
      },
      {
        telegramId: "u1",
        gameId: "battleship",
        gamesPlayed: 2,
        wins: 1,
        losses: 0,
        draws: 1,
        netCoins: -3,
        biggestWin: 8,
        rating: 1080,
      },
      {
        telegramId: "u1",
        gameId: "blackjack",
        gamesPlayed: 10,
        wins: 9,
        losses: 1,
        draws: 0,
        netCoins: 100,
        biggestWin: 50,
        rating: 9999,
      },
    ]);

    expect(rows).toEqual([
      {
        telegramId: "u1",
        gamesPlayed: 6,
        wins: 4,
        losses: 1,
        draws: 1,
        netCoins: 15,
        biggestWin: 12,
        rating: 1100,
        winRate: 66.7,
      },
    ]);
  });

  it("sorts deterministically and omits players whose only historical game was Blackjack", () => {
    const rows = aggregateGlobalLeaderboard([
      {
        telegramId: "z",
        gameId: "blackjack",
        gamesPlayed: 1,
        wins: 0,
        losses: 1,
        draws: 0,
        netCoins: -10,
        biggestWin: 0,
        rating: 1000,
      },
      {
        telegramId: "a",
        gameId: "durak",
        gamesPlayed: 2,
        wins: 1,
        losses: 1,
        draws: 0,
        netCoins: 0,
        biggestWin: 10,
        rating: 1000,
      },
    ]);

    expect(rows.map(row => [row.telegramId, row.rating])).toEqual([
      ["a", 1000],
    ]);
    expect(rows[0].winRate).toBe(50);
  });
});
