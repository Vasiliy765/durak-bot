const TELEGRAM_API = "https://api.telegram.org";

export type TelegramUser = {
  id: number;
  is_bot?: boolean;
  first_name?: string;
  last_name?: string;
  username?: string;
};

export type TelegramChat = {
  id: number;
  type: "private" | "group" | "supergroup" | "channel";
  title?: string;
};

export type TelegramMessage = {
  message_id: number;
  date?: number;
  chat: TelegramChat;
  from?: TelegramUser;
  text?: string;
  reply_to_message?: { message_id: number; from?: TelegramUser; text?: string };
};

export type TelegramPermissions = Record<string, boolean>;

export type TelegramChatMember = {
  status: "creator" | "administrator" | "member" | "restricted" | "left" | "kicked";
  user: TelegramUser;
  is_anonymous?: boolean;
  can_be_edited?: boolean;
  can_manage_chat?: boolean;
  can_delete_messages?: boolean;
  can_restrict_members?: boolean;
  can_promote_members?: boolean;
  can_change_info?: boolean;
  can_invite_users?: boolean;
  can_pin_messages?: boolean;
  can_manage_topics?: boolean;
  is_member?: boolean;
  until_date?: number;
  can_send_messages?: boolean;
  can_send_audios?: boolean;
  can_send_documents?: boolean;
  can_send_photos?: boolean;
  can_send_videos?: boolean;
  can_send_video_notes?: boolean;
  can_send_voice_notes?: boolean;
  can_send_polls?: boolean;
  can_send_other_messages?: boolean;
  can_add_web_page_previews?: boolean;
  can_react_to_messages?: boolean;
  can_edit_tag?: boolean;
  can_manage_tags?: boolean;
};

export type TelegramButton = { text: string; callback_data?: string; url?: string; web_app?: { url: string } };
export type TelegramMarkup = { inline_keyboard: TelegramButton[][] };

export class TelegramApiError extends Error {
  constructor(public readonly method: string, public readonly errorCode: number | undefined, message: string) {
    super(message);
    this.name = "TelegramApiError";
  }
}

export function telegramBotTokenConfigured() {
  return Boolean(process.env.TELEGRAM_BOT_TOKEN?.trim());
}

export function telegramBotUsername() {
  return (process.env.TELEGRAM_BOT_USERNAME || "").trim().replace(/^@/, "");
}

export async function telegramCall<T>(method: string, body: Record<string, unknown>, timeoutMs = 10_000): Promise<T> {
  const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
  if (!token) throw new TelegramApiError(method, undefined, "Telegram bot token is not configured");
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const request = (async () => {
      const response = await fetch(`${TELEGRAM_API}/bot${token}/${method}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      const payload = await response.json().catch(() => null) as { ok?: boolean; error_code?: number; description?: string; result?: T } | null;
      if (!response.ok || !payload?.ok) {
        throw new TelegramApiError(method, payload?.error_code || response.status, (payload?.description || response.statusText || "Telegram API error").slice(0, 300));
      }
      return payload.result as T;
    })();
    const deadline = new Promise<never>((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        reject(new TelegramApiError(method, undefined, `Telegram API deadline exceeded after ${timeoutMs}ms`));
      }, Math.max(1, timeoutMs));
    });
    return await Promise.race([request, deadline]);
  } catch (error) {
    if (error instanceof TelegramApiError) throw error;
    const raw = error instanceof Error ? error.message : String(error);
    throw new TelegramApiError(method, undefined, raw.split(token).join("[redacted]").slice(0, 300));
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export function isTelegramAdmin(member: TelegramChatMember | undefined) {
  return member?.status === "creator" || member?.status === "administrator";
}

export function telegramMessagePermissions(defaults?: TelegramPermissions | null): TelegramPermissions {
  const source = defaults || {};
  const flags = [
    "can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos", "can_send_videos",
    "can_send_video_notes", "can_send_voice_notes", "can_send_polls", "can_send_other_messages",
    "can_add_web_page_previews", "can_react_to_messages", "can_edit_tag",
  ];
  return Object.fromEntries(flags.map(flag => [flag, source[flag] !== false]));
}
