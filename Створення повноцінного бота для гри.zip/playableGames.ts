export const PLAYABLE_ARCADE_GAME_IDS = [
  "battleship",
  "durak",
  "tic_tac_toe",
] as const;

export type PlayableArcadeGameId = (typeof PLAYABLE_ARCADE_GAME_IDS)[number];

export function isPlayableArcadeGameId(
  value: unknown
): value is PlayableArcadeGameId {
  return (
    typeof value === "string" &&
    (PLAYABLE_ARCADE_GAME_IDS as readonly string[]).includes(value)
  );
}
