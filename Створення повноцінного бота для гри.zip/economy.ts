import { randomInt, randomUUID } from "node:crypto";
import { and, asc, desc, eq, sql } from "drizzle-orm";
import { getDb } from "../db";
import {
  spyEconomyLedger,
  spyInventory,
  spyProfiles,
  spyShopItems,
  spyWallets,
  economySettings,
  spyStarsOrders,
  users,
} from "../../drizzle/schema";
import { telegramCall } from "./telegramApi";

export type EconomyIdentity = {
  id: string;
  firstName: string;
  lastName?: string | null;
  username?: string | null;
  avatarUrl?: string | null;
};

export class EconomyError extends Error {
  constructor(
    public readonly status: number,
    message: string
  ) {
    super(message);
    this.name = "EconomyError";
  }
}

export const ECONOMY_RULES = {
  startingBalance: 100,
  salaryCooldownMs: 2 * 60 * 60 * 1000,
  salaryMin: 100,
  salaryMax: 100,
  dailyCooldownMs: 24 * 60 * 60 * 1000,
  dailyStreakWindowMs: 48 * 60 * 60 * 1000,
  dailyMin: 50,
  dailyMax: 50,
  gameParticipation: 5,
  gameWinBonus: 5,
  gameRewardCapPerUtcDay: 3,
  gameRewardMinPlayers: 3,
  gameRewardMinDurationSeconds: 180,
} as const;

export const ECONOMY_DEFAULTS = {
  exchange_rate: 100,
  vip_price_crystals: 100,
  salary_coins: 100,
  bonus_coins: 50,
  stars_packages: [
    { id: "crystal_10", stars: 10, crystals: 10 },
    { id: "crystal_55", stars: 50, crystals: 55 },
    { id: "crystal_120", stars: 100, crystals: 120 },
    { id: "crystal_650", stars: 500, crystals: 650 },
  ],
} as const;

export async function readEconomySettings() {
  const db = await requireDb();
  const rows = await db.select().from(economySettings);
  const values: Record<string, any> = { ...ECONOMY_DEFAULTS };
  for (const row of rows) values[row.key] = row.value;
  for (const [key, value] of Object.entries(ECONOMY_DEFAULTS)) {
    if (!rows.some(row => row.key === key)) {
      await db.insert(economySettings).values({ key, value: value as any }).onDuplicateKeyUpdate({ set: { key: sql`${economySettings.key}` } });
    }
  }
  return values as typeof ECONOMY_DEFAULTS;
}

function isVip(wallet: any, now = Date.now()) {
  return !!wallet.vipUntil && new Date(wallet.vipUntil).getTime() > now;
}

const SHOP_SEED: Array<{
  itemId: string;
  name: string;
  category: string;
  description: string;
  price: number;
  metadata: Record<string, string | number | boolean>;
}> = [
  {
    itemId: "frame-ember",
    name: "Бурштинове кільце",
    category: "avatar_frame",
    description: "Тепла рамка для оперативного досьє.",
    price: 180,
    metadata: { color: "#d4ad65", style: "ring" },
  },
  {
    itemId: "frame-ice",
    name: "Крижаний контур",
    category: "avatar_frame",
    description: "Стриманий холодний контур.",
    price: 260,
    metadata: { color: "#91d6e8", style: "ring" },
  },
  {
    itemId: "frame-crimson",
    name: "Червоний сигнал",
    category: "avatar_frame",
    description: "Контур оперативного рівня тривоги.",
    price: 420,
    metadata: { color: "#f04452", style: "glow" },
  },
  {
    itemId: "badge-shadow",
    name: "Тінь",
    category: "badge",
    description: "Знак тихого спостерігача.",
    price: 120,
    metadata: { icon: "eye", color: "#aab1b5" },
  },
  {
    itemId: "badge-crosshair",
    name: "Приціл",
    category: "badge",
    description: "Знак точного розрахунку.",
    price: 220,
    metadata: { icon: "crosshair", color: "#f04452" },
  },
  {
    itemId: "badge-veteran",
    name: "Ветеран операцій",
    category: "badge",
    description: "Знак досвідченого агента.",
    price: 360,
    metadata: { icon: "shield", color: "#91d6c0" },
  },
  {
    itemId: "title-analyst",
    name: "Аналітик",
    category: "title",
    description: "Титул уважного гравця.",
    price: 160,
    metadata: { text: "АНАЛІТИК" },
  },
  {
    itemId: "title-ghost",
    name: "Привид",
    category: "title",
    description: "Титул, який не залишає слідів.",
    price: 380,
    metadata: { text: "ПРИВИД" },
  },
  {
    itemId: "title-director",
    name: "Куратор",
    category: "title",
    description: "Титул керівника операцій.",
    price: 600,
    metadata: { text: "КУРАТОР" },
  },
  {
    itemId: "color-mint",
    name: "М’ятний канал",
    category: "name_color",
    description: "Спокійний бірюзовий колір імені.",
    price: 150,
    metadata: { color: "#91d6c0" },
  },
  {
    itemId: "color-crimson",
    name: "Кодове червоне",
    category: "name_color",
    description: "Акцентний оперативний червоний.",
    price: 240,
    metadata: { color: "#f04452" },
  },
  {
    itemId: "color-gold",
    name: "Золотий протокол",
    category: "name_color",
    description: "Теплий золотий акцент.",
    price: 340,
    metadata: { color: "#d4ad65" },
  },
  {
    itemId: "theme-night",
    name: "Нічна операція",
    category: "profile_theme",
    description: "Додаткове оформлення профілю в темних тонах.",
    price: 520,
    metadata: { theme: "night" },
  },
  {
    itemId: "theme-radar",
    name: "Радарна сітка",
    category: "profile_theme",
    description: "Тематичний фон оперативного планшета.",
    price: 780,
    metadata: { theme: "radar" },
  },
  {
    itemId: "profile-stamp",
    name: "Гриф «ТАЄМНО»",
    category: "other",
    description: "Декоративний штамп для досьє.",
    price: 300,
    metadata: { stamp: "classified" },
  },
];

async function requireDb() {
  const db = await getDb();
  if (!db)
    throw new EconomyError(
      503,
      "Економіка тимчасово недоступна. Спробуйте пізніше."
    );
  return db;
}

async function touchProfile(identity: EconomyIdentity) {
  const db = await requireDb();
  const rows = await db
    .select()
    .from(spyProfiles)
    .where(eq(spyProfiles.telegramId, identity.id))
    .limit(1);
  const current = rows[0];
  if (current?.blocked) throw new EconomyError(403, "Доступ до гри обмежено.");
  const avatarUrl = identity.avatarUrl?.trim();
  const values = {
    firstName: (identity.firstName || "Агент").slice(0, 100),
    lastName: identity.lastName?.slice(0, 100) || null,
    username: identity.username?.slice(0, 100) || null,
    ...(avatarUrl ? { avatarUrl: avatarUrl.slice(0, 2048) } : {}),
  };
  if (current) {
    if (
      current.firstName !== values.firstName ||
      current.lastName !== values.lastName ||
      current.username !== values.username ||
      (avatarUrl && current.avatarUrl !== values.avatarUrl)
    ) {
      await db
        .update(spyProfiles)
        .set(values)
        .where(eq(spyProfiles.telegramId, identity.id));
    }
    await db.transaction((tx: any) => syncEconomyUserTx(tx, identity.id));
    return;
  }
  await db
    .insert(spyProfiles)
    .values({
      telegramId: identity.id,
      ...values,
      avatarUrl: avatarUrl ? avatarUrl.slice(0, 2048) : null,
      gamesPlayed: 0,
      wins: 0,
      losses: 0,
      spyWins: 0,
      civilianWins: 0,
      spiesCaught: 0,
      rating: 1000,
      xp: 0,
      winStreak: 0,
      bestStreak: 0,
      achievements: [],
      blocked: false,
    })
    .onDuplicateKeyUpdate({ set: values });
  await db.transaction((tx: any) => syncEconomyUserTx(tx, identity.id));
}

export async function syncTelegramProfile(identity: EconomyIdentity) {
  await touchProfile(identity);
}

async function ensureWalletTx(tx: any, telegramId: string) {
  const before = await tx
    .select()
    .from(spyWallets)
    .where(eq(spyWallets.telegramId, telegramId))
    .limit(1)
    .for("update");
  const isNewWallet = !before[0];
  await tx
    .insert(spyWallets)
    .values({ telegramId, balance: ECONOMY_RULES.startingBalance, dailyStreak: 0, gameRewardsToday: 0 })
    .onDuplicateKeyUpdate({ set: { balance: sql`${spyWallets.balance}` } });
  const rows = await tx
    .select()
    .from(spyWallets)
    .where(eq(spyWallets.telegramId, telegramId))
    .limit(1)
    .for("update");
  if (!rows[0]) throw new EconomyError(503, "Не вдалося відкрити гаманець.");
  if (isNewWallet) {
    const idempotencyKey = `welcome:${telegramId}`;
    const prior = await tx.select().from(spyEconomyLedger)
      .where(eq(spyEconomyLedger.idempotencyKey, idempotencyKey)).limit(1).for("update");
    if (!prior[0]) await tx.insert(spyEconomyLedger).values({
      telegramId,
      kind: "welcome_grant",
      amount: ECONOMY_RULES.startingBalance,
      balanceAfter: rows[0].balance,
      idempotencyKey,
      note: "Стартовий баланс нового гравця",
    });
  }
  await syncEconomyUserTx(tx, telegramId);
  return rows[0];
}

/** Keep the required users-table fields in step with the established wallet ledger. */
export async function syncEconomyUserTx(tx: any, telegramId: string) {
  const [walletRows, profileRows] = await Promise.all([
    tx.select().from(spyWallets).where(eq(spyWallets.telegramId, telegramId)).limit(1),
    tx.select().from(spyProfiles).where(eq(spyProfiles.telegramId, telegramId)).limit(1),
  ]);
  const wallet = walletRows[0];
  if (!wallet) return;
  const profile = profileRows[0];
  const displayName = [profile?.firstName, profile?.lastName].filter(Boolean).join(" ") || "Агент";
  await tx.insert(users).values({
    openId: `telegram:${telegramId}`,
    telegramId,
    username: profile?.username || null,
    coins: wallet.balance,
    crystals: wallet.crystals || 0,
    vipUntil: wallet.vipUntil || null,
    name: displayName,
    loginMethod: "telegram",
  }).onDuplicateKeyUpdate({ set: {
    username: profile?.username || null,
    coins: wallet.balance,
    crystals: wallet.crystals || 0,
    vipUntil: wallet.vipUntil || null,
    name: displayName,
    loginMethod: "telegram",
  } });
}

let shopSeedPromise: Promise<void> | undefined;
async function ensureShopSeed() {
  if (shopSeedPromise) return shopSeedPromise;
  shopSeedPromise = (async () => {
    const db = await requireDb();
    await db
      .insert(spyShopItems)
      .values(SHOP_SEED)
      .onDuplicateKeyUpdate({ set: { itemId: sql`${spyShopItems.itemId}` } });
  })().catch(error => {
    shopSeedPromise = undefined;
    throw error;
  });
  return shopSeedPromise;
}

function utcDay(date: Date) {
  return date.toISOString().slice(0, 10);
}

export function formatRemaining(ms: number) {
  const seconds = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.ceil((seconds % 3600) / 60);
  if (hours > 0) return `${hours} год ${minutes} хв`;
  return `${Math.max(1, minutes)} хв`;
}

export function isGameRewardEligible(
  participantCount: number,
  durationSeconds: number
) {
  return (
    participantCount >= ECONOMY_RULES.gameRewardMinPlayers &&
    durationSeconds >= ECONOMY_RULES.gameRewardMinDurationSeconds
  );
}

export function gameRewardAmount(won: boolean) {
  return (
    ECONOMY_RULES.gameParticipation + (won ? ECONOMY_RULES.gameWinBonus : 0)
  );
}

export function configuredRewardAmount(baseAmount: number, vipActive: boolean) {
  const fixed = Number.isFinite(baseAmount) ? Math.max(0, Math.trunc(baseAmount)) : 0;
  return fixed * (vipActive ? 2 : 1);
}

export function gameRewardIdempotencyKey(roundId: string, telegramId: string) {
  return `game:${roundId}:${telegramId}`.slice(0, 140);
}

export async function claimSalary(
  identity: EconomyIdentity,
  updateId?: string
) {
  await touchProfile(identity);
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const wallet = await ensureWalletTx(tx, identity.id);
    const idempotencyKey = `salary:${updateId || randomUUID()}`;
    const previous = await tx
      .select()
      .from(spyEconomyLedger)
      .where(eq(spyEconomyLedger.idempotencyKey, idempotencyKey))
      .limit(1)
      .for("update");
    if (previous[0]) {
      const availableAt = wallet.lastSalaryAt
        ? new Date(wallet.lastSalaryAt).getTime() +
          ECONOMY_RULES.salaryCooldownMs
        : Date.now();
      return {
        claimed: true,
        duplicate: true,
        amount: previous[0].amount,
        balance: previous[0].balanceAfter,
        remainingMs: Math.max(0, availableAt - Date.now()),
      };
    }
    const now = new Date();
    const lastClaim = wallet.lastSalaryAt
      ? new Date(wallet.lastSalaryAt).getTime()
      : 0;
    const remainingMs = Math.max(
      0,
      lastClaim + ECONOMY_RULES.salaryCooldownMs - now.getTime()
    );
    if (remainingMs > 0)
      return {
        claimed: false,
        duplicate: false,
        amount: 0,
        balance: wallet.balance,
        remainingMs,
      };
    const settings = await readEconomySettings();
    const amount = configuredRewardAmount(Number(settings.salary_coins) || 100, isVip(wallet));
    const balance = wallet.balance + amount;
    await tx
      .update(spyWallets)
      .set({ balance, lastSalaryAt: now })
      .where(eq(spyWallets.telegramId, identity.id));
    await syncEconomyUserTx(tx, identity.id);
    await tx.insert(spyEconomyLedger).values({
      telegramId: identity.id,
      kind: "salary",
      amount,
      balanceAfter: balance,
      idempotencyKey,
      referenceId: updateId || null,
      note: "Зарплата агента",
    });
    return {
      claimed: true,
      duplicate: false,
      amount,
      balance,
      remainingMs: ECONOMY_RULES.salaryCooldownMs,
    };
  });
}

export async function claimDaily(identity: EconomyIdentity, updateId?: string) {
  await touchProfile(identity);
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const wallet = await ensureWalletTx(tx, identity.id);
    const idempotencyKey = `daily:${updateId || randomUUID()}`;
    const previous = await tx
      .select()
      .from(spyEconomyLedger)
      .where(eq(spyEconomyLedger.idempotencyKey, idempotencyKey))
      .limit(1)
      .for("update");
    if (previous[0]) {
      const availableAt = wallet.lastDailyAt
        ? new Date(wallet.lastDailyAt).getTime() + ECONOMY_RULES.dailyCooldownMs
        : Date.now();
      return {
        claimed: true,
        duplicate: true,
        amount: previous[0].amount,
        balance: previous[0].balanceAfter,
        streak: wallet.dailyStreak,
        streakBonus: 0,
        remainingMs: Math.max(0, availableAt - Date.now()),
      };
    }
    const now = new Date();
    const lastClaim = wallet.lastDailyAt
      ? new Date(wallet.lastDailyAt).getTime()
      : 0;
    const remainingMs = Math.max(
      0,
      lastClaim + ECONOMY_RULES.dailyCooldownMs - now.getTime()
    );
    if (remainingMs > 0)
      return {
        claimed: false,
        duplicate: false,
        amount: 0,
        balance: wallet.balance,
        streak: wallet.dailyStreak,
        streakBonus: 0,
        remainingMs,
      };
    const streak =
      lastClaim > 0 &&
      now.getTime() - lastClaim <= ECONOMY_RULES.dailyStreakWindowMs
        ? wallet.dailyStreak + 1
        : 1;
    const settings = await readEconomySettings();
    const baseAmount = Math.max(0, Number(settings.bonus_coins) || 50);
    const streakBonus = 0;
    const amount = configuredRewardAmount(baseAmount, isVip(wallet));
    const balance = wallet.balance + amount;
    await tx
      .update(spyWallets)
      .set({ balance, lastDailyAt: now, dailyStreak: streak })
      .where(eq(spyWallets.telegramId, identity.id));
    await syncEconomyUserTx(tx, identity.id);
    await tx.insert(spyEconomyLedger).values({
      telegramId: identity.id,
      kind: "daily",
      amount,
      balanceAfter: balance,
      idempotencyKey,
      referenceId: updateId || null,
      note: streakBonus
        ? `Щоденний бонус · серія ${streak} дн.`
        : "Щоденний бонус",
    });
    return {
      claimed: true,
      duplicate: false,
      amount,
      baseAmount,
      balance,
      streak,
      streakBonus,
      remainingMs: ECONOMY_RULES.dailyCooldownMs,
    };
  });
}

export async function getBalance(identity: EconomyIdentity) {
  await touchProfile(identity);
  const db = await requireDb();
  return db.transaction((tx: any) => ensureWalletTx(tx, identity.id));
}

export async function getEconomyOverview(identity: EconomyIdentity) {
  const wallet = await getBalance(identity);
  const now = Date.now();
  return {
    balance: wallet.balance,
    crystals: wallet.crystals ?? 0,
    vipUntil: wallet.vipUntil ? new Date(wallet.vipUntil).toISOString() : null,
    vipActive: isVip(wallet, now),
    settings: await readEconomySettings(),
    dailyStreak: wallet.dailyStreak,
    nextSalaryAt: wallet.lastSalaryAt
      ? new Date(wallet.lastSalaryAt).getTime() + ECONOMY_RULES.salaryCooldownMs
      : null,
    nextDailyAt: wallet.lastDailyAt
      ? new Date(wallet.lastDailyAt).getTime() + ECONOMY_RULES.dailyCooldownMs
      : null,
    salaryReady:
      !wallet.lastSalaryAt ||
      now - new Date(wallet.lastSalaryAt).getTime() >=
        ECONOMY_RULES.salaryCooldownMs,
    dailyReady:
      !wallet.lastDailyAt ||
      now - new Date(wallet.lastDailyAt).getTime() >=
        ECONOMY_RULES.dailyCooldownMs,
  };
}

export async function exchangeCrystals(identity: EconomyIdentity, crystals: number) {
  if (!Number.isSafeInteger(crystals) || crystals <= 0 || crystals > 1_000_000)
    throw new EconomyError(400, "Вкажіть додатну кількість кристалів.");
  await touchProfile(identity);
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const wallet = await ensureWalletTx(tx, identity.id);
    if ((wallet.crystals ?? 0) < crystals) throw new EconomyError(409, "Недостатньо кристалів.");
    const settings = await readEconomySettings();
    const coins = crystals * Math.max(1, Number(settings.exchange_rate) || 100);
    const key = `exchange:${randomUUID()}`;
    await tx.update(spyWallets).set({ crystals: wallet.crystals - crystals, balance: wallet.balance + coins }).where(eq(spyWallets.telegramId, identity.id));
    await syncEconomyUserTx(tx, identity.id);
    await tx.insert(spyEconomyLedger).values([
      { telegramId: identity.id, kind: "crystal_exchange", currency: "crystals", amount: -crystals, balanceAfter: wallet.crystals - crystals, idempotencyKey: `${key}:crystals`, note: "Обмін кристалів на монети" },
      { telegramId: identity.id, kind: "crystal_exchange", currency: "coins", amount: coins, balanceAfter: wallet.balance + coins, idempotencyKey: `${key}:coins`, note: "Обмін кристалів на монети" },
    ]);
    return { balance: wallet.balance + coins, crystals: wallet.crystals - crystals, receivedCoins: coins };
  });
}

export async function buyVip(identity: EconomyIdentity) {
  await touchProfile(identity);
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const wallet = await ensureWalletTx(tx, identity.id);
    const settings = await readEconomySettings();
    const price = Math.max(1, Number(settings.vip_price_crystals) || 100);
    if ((wallet.crystals ?? 0) < price) throw new EconomyError(409, "Недостатньо кристалів для VIP.");
    const base = Math.max(Date.now(), wallet.vipUntil ? new Date(wallet.vipUntil).getTime() : 0);
    const vipUntil = new Date(base + 30 * 86400_000);
    const key = `vip:${randomUUID()}`;
    await tx.update(spyWallets).set({ crystals: wallet.crystals - price, vipUntil }).where(eq(spyWallets.telegramId, identity.id));
    await syncEconomyUserTx(tx, identity.id);
    await tx.insert(spyEconomyLedger).values({ telegramId: identity.id, kind: "vip_purchase", currency: "crystals", amount: -price, balanceAfter: wallet.crystals - price, idempotencyKey: key, note: "VIP на 30 днів" });
    return { crystals: wallet.crystals - price, vipUntil: vipUntil.toISOString() };
  });
}

export async function createStarsInvoice(identity: EconomyIdentity, packageId: string) {
  const db = await requireDb();
  const settings = await readEconomySettings();
  const pkg = (settings.stars_packages as ReadonlyArray<{ id: string; stars: number; crystals: number }>).find(item => item.id === packageId);
  if (!pkg || !Number.isSafeInteger(pkg.stars) || !Number.isSafeInteger(pkg.crystals) || pkg.stars <= 0 || pkg.crystals <= 0)
    throw new EconomyError(400, "Пакет кристалів недоступний.");
  const id = randomUUID();
  await db.insert(spyStarsOrders).values({ id, telegramId: identity.id, packageId: pkg.id, stars: pkg.stars, crystals: pkg.crystals, status: "pending" });
  try {
    const invoiceUrl = await telegramCall<string>("createInvoiceLink", {
      title: `${pkg.crystals} кристалів`, description: `Пакет ${pkg.crystals} 💎 для Mini App`, payload: id,
      provider_token: "", currency: "XTR", prices: [{ label: `${pkg.crystals} кристалів`, amount: pkg.stars }],
    });
    return { invoiceUrl, orderId: id };
  } catch (error) {
    await db.update(spyStarsOrders).set({ status: "cancelled" }).where(eq(spyStarsOrders.id, id));
    throw error;
  }
}

export function starsPreCheckoutMatches(order: { status?: string; telegramId?: string; stars?: number } | undefined, query: { from: { id: number }; currency: string; total_amount: number }) {
  return !!order && order.status === "pending" && order.telegramId === String(query.from.id) && query.currency === "XTR" && order.stars === query.total_amount;
}

export async function handleStarsPreCheckout(query: { id: string; from: { id: number }; currency: string; total_amount: number; invoice_payload: string }) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const verification = (async () => {
    const db = await requireDb();
    const order = (await db.select().from(spyStarsOrders).where(eq(spyStarsOrders.id, query.invoice_payload)).limit(1))[0];
    return starsPreCheckoutMatches(order, query);
  })();
  const valid = await Promise.race([
    verification.catch(() => false),
    new Promise<boolean>(resolve => { timer = setTimeout(() => resolve(false), 3_500); }),
  ]);
  if (timer) clearTimeout(timer);
  await telegramCall("answerPreCheckoutQuery", {
    pre_checkout_query_id: query.id,
    ok: valid,
    ...(!valid ? { error_message: "Замовлення недійсне або вже опрацьоване. Створіть новий рахунок." } : {}),
  }, 3_000);
}

export async function fulfillStarsPayment(input: { telegramId: string; payload: string; currency: string; totalAmount: number; chargeId: string }) {
  if (input.currency !== "XTR") throw new EconomyError(400, "Невідома валюта платежу.");
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const order = (await tx.select().from(spyStarsOrders).where(eq(spyStarsOrders.id, input.payload)).limit(1).for("update"))[0];
    if (!order || order.telegramId !== input.telegramId || order.stars !== input.totalAmount) throw new EconomyError(400, "Платіж не відповідає замовленню.");
    if (order.status === "paid") return { duplicate: true, crystals: order.crystals };
    if (order.status !== "pending") throw new EconomyError(409, "Замовлення вже закрите.");
    const wallet = await ensureWalletTx(tx, input.telegramId);
    const charge = await tx.select().from(spyStarsOrders).where(eq(spyStarsOrders.chargeId, input.chargeId)).limit(1);
    if (charge.length) throw new EconomyError(409, "Цей платіж уже зарахований.");
    const crystals = wallet.crystals + order.crystals;
    await tx.update(spyWallets).set({ crystals }).where(eq(spyWallets.telegramId, input.telegramId));
    await syncEconomyUserTx(tx, input.telegramId);
    await tx.update(spyStarsOrders).set({ status: "paid", chargeId: input.chargeId, paidAt: new Date() }).where(eq(spyStarsOrders.id, order.id));
    await tx.insert(spyEconomyLedger).values({ telegramId: input.telegramId, kind: "stars_purchase", currency: "crystals", amount: order.crystals, balanceAfter: crystals, idempotencyKey: `stars:${order.id}`, referenceId: order.id, note: `Telegram Stars ${order.stars}` });
    return { duplicate: false, crystals };
  });
}

export async function saveEconomySettings(actorId: string, input: Record<string, unknown>) {
  const allowed = new Set(["exchange_rate", "vip_price_crystals", "salary_coins", "bonus_coins", "stars_packages"]);
  if (Object.keys(input).some(key => !allowed.has(key))) throw new EconomyError(400, "Невідомий параметр економіки.");
  const next = { ...await readEconomySettings(), ...input } as any;
  for (const key of ["exchange_rate", "vip_price_crystals", "salary_coins", "bonus_coins"])
    if (!Number.isSafeInteger(next[key]) || next[key] < 1 || next[key] > 10_000_000) throw new EconomyError(400, `Некоректне значення ${key}.`);
  if (!Array.isArray(next.stars_packages) || next.stars_packages.length !== 4 || next.stars_packages.some((p: any) => !p || typeof p.id !== "string" || !Number.isSafeInteger(p.stars) || p.stars <= 0 || !Number.isSafeInteger(p.crystals) || p.crystals <= 0))
    throw new EconomyError(400, "Некоректні пакети Stars.");
  const db = await requireDb();
  for (const key of allowed) if (Object.hasOwn(input, key)) {
    await db.insert(economySettings).values({ key, value: (next as any)[key], updatedBy: actorId }).onDuplicateKeyUpdate({ set: { value: (next as any)[key], updatedBy: actorId } });
  }
  return readEconomySettings();
}

export async function findEconomyPlayer(target: string) {
  const db = await requireDb();
  const needle = target.replace(/^@/, "").trim();
  if (!needle) return null;
  const profile = (await db.select().from(spyProfiles).where(/^\d+$/.test(needle) ? eq(spyProfiles.telegramId, needle) : sql`lower(${spyProfiles.username}) = lower(${needle})`).limit(1))[0];
  if (!profile) return null;
  const wallet = (await db.select().from(spyWallets).where(eq(spyWallets.telegramId, profile.telegramId)).limit(1))[0];
  return { telegramId: profile.telegramId, firstName: profile.firstName, username: profile.username, balance: wallet?.balance ?? 0, crystals: wallet?.crystals ?? 0, vipUntil: wallet?.vipUntil ?? null };
}

export function calculateVipAdminAdjustment(currentVipUntil: Date | string | null, amountDays: number, nowMs: number) {
  const currentUntil = currentVipUntil ? (currentVipUntil instanceof Date ? currentVipUntil.getTime() : new Date(currentVipUntil).getTime()) : nowMs;
  const nextUntilMs = Math.max(nowMs, currentUntil) + amountDays * 86_400_000;
  const vipUntil = nextUntilMs <= nowMs ? null : new Date(nextUntilMs);
  return { vipUntil, daysRemaining: vipUntil ? Math.ceil((vipUntil.getTime() - nowMs) / 86_400_000) : 0 };
}

export async function grantEconomy(actorId: string, target: string, currency: "coins" | "crystals" | "vip", amount: number) {
  if (!Number.isSafeInteger(amount) || amount === 0 || Math.abs(amount) > 1_000_000) throw new EconomyError(400, "Кількість має бути цілим числом від -1 000 000 до 1 000 000, крім нуля.");
  const db = await requireDb();
  const needle = target.replace(/^@/, "").trim();
  const profile = (await db.select().from(spyProfiles).where(/^\d+$/.test(needle) ? eq(spyProfiles.telegramId, needle) : sql`lower(${spyProfiles.username}) = lower(${needle})`).limit(1))[0];
  if (!profile) throw new EconomyError(404, "Гравця не знайдено в базі");
  await touchProfile({ id: profile.telegramId, firstName: profile.firstName, lastName: profile.lastName, username: profile.username });
  return db.transaction(async (tx: any) => {
    const wallet = await ensureWalletTx(tx, profile.telegramId);
    if (currency === "vip") {
      const adjustment = calculateVipAdminAdjustment(wallet.vipUntil, amount, Date.now());
      await tx.update(spyWallets).set({ vipUntil: adjustment.vipUntil }).where(eq(spyWallets.telegramId, profile.telegramId));
      await syncEconomyUserTx(tx, profile.telegramId);
      await tx.insert(spyEconomyLedger).values({
        telegramId: profile.telegramId,
        kind: "admin_adjustment",
        currency: "vip_days",
        amount,
        balanceAfter: adjustment.daysRemaining,
        idempotencyKey: `admin:${randomUUID()}`,
        referenceId: actorId,
        note: `Ручна корекція VIP на ${amount} днів адміністратором ${actorId}`,
      });
      return { telegramId: profile.telegramId, username: profile.username, vipUntil: adjustment.vipUntil?.toISOString() ?? null, vipDaysRemaining: adjustment.daysRemaining };
    }
    const current = currency === "coins" ? wallet.balance : wallet.crystals;
    if (current + amount < 0) throw new EconomyError(409, "Списання перевищує баланс гравця.");
    const next = current + amount;
    await tx.update(spyWallets).set(currency === "coins" ? { balance: next } : { crystals: next }).where(eq(spyWallets.telegramId, profile.telegramId));
    await syncEconomyUserTx(tx, profile.telegramId);
    await tx.insert(spyEconomyLedger).values({ telegramId: profile.telegramId, kind: "admin_adjustment", currency, amount, balanceAfter: next, idempotencyKey: `admin:${randomUUID()}`, referenceId: actorId, note: `Ручна корекція адміністратором ${actorId}` });
    return { telegramId: profile.telegramId, username: profile.username, balance: currency === "coins" ? next : wallet.balance, crystals: currency === "crystals" ? next : wallet.crystals };
  });
}

export async function listShopItems() {
  await ensureShopSeed();
  const db = await requireDb();
  return db
    .select()
    .from(spyShopItems)
    .where(eq(spyShopItems.active, true))
    .orderBy(asc(spyShopItems.category), asc(spyShopItems.price));
}

export async function listInventory(identity: EconomyIdentity) {
  await touchProfile(identity);
  const db = await requireDb();
  return db
    .select({
      itemId: spyInventory.itemId,
      equipped: spyInventory.equipped,
      purchasedAt: spyInventory.purchasedAt,
      name: spyShopItems.name,
      category: spyShopItems.category,
      description: spyShopItems.description,
      price: spyShopItems.price,
      metadata: spyShopItems.metadata,
    })
    .from(spyInventory)
    .innerJoin(spyShopItems, eq(spyInventory.itemId, spyShopItems.itemId))
    .where(eq(spyInventory.telegramId, identity.id))
    .orderBy(asc(spyShopItems.category), asc(spyShopItems.name));
}

export async function listEquippedCosmetics(telegramId: string) {
  const db = await requireDb();
  return db
    .select({
      itemId: spyInventory.itemId,
      name: spyShopItems.name,
      category: spyShopItems.category,
      description: spyShopItems.description,
      metadata: spyShopItems.metadata,
    })
    .from(spyInventory)
    .innerJoin(spyShopItems, eq(spyInventory.itemId, spyShopItems.itemId))
    .where(
      and(
        eq(spyInventory.telegramId, telegramId),
        eq(spyInventory.equipped, true)
      )
    )
    .orderBy(asc(spyShopItems.category));
}

export async function wealthLeaderboard(limit = 50) {
  const db = await requireDb();
  return db
    .select({
      balance: spyWallets.balance,
      firstName: spyProfiles.firstName,
      lastName: spyProfiles.lastName,
      username: spyProfiles.username,
      avatarUrl: spyProfiles.avatarUrl,
      vipUntil: spyWallets.vipUntil,
    })
    .from(spyWallets)
    .leftJoin(spyProfiles, eq(spyWallets.telegramId, spyProfiles.telegramId))
    .orderBy(desc(spyWallets.balance), asc(spyWallets.telegramId))
    .limit(Math.max(1, Math.min(100, limit)))
    .then((rows: any[]) => rows.map(row => ({ ...row, vip: !!row.vipUntil && new Date(row.vipUntil).getTime() > Date.now() })));
}

export async function purchaseShopItem(
  identity: EconomyIdentity,
  itemId: string
) {
  await touchProfile(identity);
  await ensureShopSeed();
  if (!/^[a-z0-9-]{2,64}$/i.test(itemId))
    throw new EconomyError(400, "Некоректний предмет магазину.");
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const wallet = await ensureWalletTx(tx, identity.id);
    const itemRows = await tx
      .select()
      .from(spyShopItems)
      .where(
        and(eq(spyShopItems.itemId, itemId), eq(spyShopItems.active, true))
      )
      .limit(1)
      .for("update");
    const item = itemRows[0];
    if (!item) throw new EconomyError(404, "Цей предмет більше не продається.");
    const existing = await tx
      .select()
      .from(spyInventory)
      .where(
        and(
          eq(spyInventory.telegramId, identity.id),
          eq(spyInventory.itemId, itemId)
        )
      )
      .limit(1)
      .for("update");
    if (existing[0])
      return {
        success: true,
        alreadyOwned: true,
        balance: wallet.balance,
        itemId,
      };
    if (wallet.balance < item.price)
      throw new EconomyError(409, "Недостатньо монет для покупки.");
    const balance = wallet.balance - item.price;
    const idempotencyKey = `purchase:${identity.id}:${itemId}`;
    const prior = await tx
      .select()
      .from(spyEconomyLedger)
      .where(eq(spyEconomyLedger.idempotencyKey, idempotencyKey))
      .limit(1)
      .for("update");
    if (prior[0])
      throw new EconomyError(
        409,
        "Цю покупку вже оброблено; оновіть інвентар."
      );
    await tx
      .update(spyWallets)
      .set({ balance })
      .where(eq(spyWallets.telegramId, identity.id));
    await syncEconomyUserTx(tx, identity.id);
    await tx
      .insert(spyInventory)
      .values({ telegramId: identity.id, itemId, equipped: false });
    await tx.insert(spyEconomyLedger).values({
      telegramId: identity.id,
      kind: "purchase",
      amount: -item.price,
      balanceAfter: balance,
      idempotencyKey,
      referenceId: itemId,
      note: `Покупка: ${item.name}`,
    });
    return { success: true, alreadyOwned: false, balance, itemId };
  });
}

export async function equipInventoryItem(
  identity: EconomyIdentity,
  itemId: string
) {
  await touchProfile(identity);
  const db = await requireDb();
  return db.transaction(async (tx: any) => {
    const itemRows = await tx
      .select({ category: spyShopItems.category })
      .from(spyShopItems)
      .where(eq(spyShopItems.itemId, itemId))
      .limit(1);
    if (!itemRows[0])
      throw new EconomyError(404, "Предмету немає у вашому інвентарі.");
    const peers: Array<{
      inventoryId: number;
      itemId: string;
      category: string;
    }> = await tx
      .select({
        inventoryId: spyInventory.id,
        itemId: spyInventory.itemId,
        category: spyShopItems.category,
      })
      .from(spyInventory)
      .innerJoin(spyShopItems, eq(spyInventory.itemId, spyShopItems.itemId))
      .where(
        and(
          eq(spyInventory.telegramId, identity.id),
          eq(spyShopItems.category, itemRows[0].category)
        )
      )
      .orderBy(asc(spyInventory.id))
      .for("update");
    const owned = peers.find(peer => peer.itemId === itemId);
    if (!owned)
      throw new EconomyError(404, "Предмету немає у вашому інвентарі.");
    for (const peer of peers) {
      await tx
        .update(spyInventory)
        .set({ equipped: peer.inventoryId === owned.inventoryId })
        .where(eq(spyInventory.id, peer.inventoryId));
    }
    return { success: true, itemId, category: owned.category };
  });
}

/** Called inside the game's result transaction; one reward per player and round. Group winners may use an explicit guaranteed override. */
export async function awardGameRewardTx(
  tx: any,
  input: {
    identity: EconomyIdentity;
    roundId: string;
    won: boolean;
    participantCount: number;
    durationSeconds: number;
    winnerRewardOverride?: number;
    now?: Date;
  }
) {
  const guaranteedWinnerPayout =
    input.won &&
    input.winnerRewardOverride !== undefined &&
    Number.isSafeInteger(input.winnerRewardOverride) &&
    input.winnerRewardOverride >= 0 &&
    input.participantCount >= ECONOMY_RULES.gameRewardMinPlayers;
  if (
    !guaranteedWinnerPayout &&
    !isGameRewardEligible(input.participantCount, input.durationSeconds)
  )
    return null;
  const wallet = await ensureWalletTx(tx, input.identity.id);
  const idempotencyKey = gameRewardIdempotencyKey(
    input.roundId,
    input.identity.id
  );
  const previous = await tx
    .select()
    .from(spyEconomyLedger)
    .where(eq(spyEconomyLedger.idempotencyKey, idempotencyKey))
    .limit(1)
    .for("update");
  if (previous[0])
    return {
      amount: previous[0].amount,
      balance: previous[0].balanceAfter,
      duplicate: true,
    };
  const now = input.now || new Date();
  const today = utcDay(now);
  const rewardsToday =
    wallet.gameRewardsDate === today ? wallet.gameRewardsToday : 0;
  if (
    rewardsToday >= ECONOMY_RULES.gameRewardCapPerUtcDay &&
    !guaranteedWinnerPayout
  )
    return null;
  const amount = guaranteedWinnerPayout
    ? input.winnerRewardOverride!
    : gameRewardAmount(input.won);
  const balance = wallet.balance + amount;
  await tx
    .update(spyWallets)
    .set({
      balance,
      gameRewardsDate: today,
      gameRewardsToday: rewardsToday + 1,
    })
    .where(eq(spyWallets.telegramId, input.identity.id));
  await syncEconomyUserTx(tx, input.identity.id);
  await tx.insert(spyEconomyLedger).values({
    telegramId: input.identity.id,
    kind: "game_reward",
    amount,
    balanceAfter: balance,
    idempotencyKey,
    referenceId: input.roundId,
    note: guaranteedWinnerPayout
      ? "Гарантована винагорода переможця Telegram-гри"
      : input.won
        ? "Участь у завершеній партії та перемога"
        : "Участь у завершеній партії",
  });
  return { amount, balance, duplicate: false };
}
