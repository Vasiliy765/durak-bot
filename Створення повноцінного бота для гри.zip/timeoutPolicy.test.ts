import { describe, expect, it } from "vitest";
import {
  shouldExtendTurnForReconnect,
  shouldWaitForReconnect,
} from "./timeoutPolicy";

const deadline = 100_000;
const graceMs = 120_000;

describe("arcade reconnect timeout policy", () => {
  it("does not grant grace to a connected player whose heartbeat is after deadline", () => {
    expect(
      shouldWaitForReconnect(deadline + 1, deadline, deadline + 2, graceMs)
    ).toBe(false);
    expect(
      shouldExtendTurnForReconnect({
        isCurrentPlayer: true,
        lastSeenAt: deadline + 1,
        turnDeadline: deadline,
        now: deadline + 2,
        graceMs,
        graceAlreadyUsed: false,
      })
    ).toBe(false);
  });

  it("waits for a genuinely offline player only until the bounded grace expires", () => {
    const lastSeenAt = deadline - 20_000;
    expect(
      shouldWaitForReconnect(lastSeenAt, deadline, deadline + 50_000, graceMs)
    ).toBe(true);
    expect(
      shouldWaitForReconnect(
        lastSeenAt,
        deadline,
        lastSeenAt + graceMs,
        graceMs
      )
    ).toBe(false);
  });

  it("grants one fresh turn when the offline current player returns during grace", () => {
    const input = {
      isCurrentPlayer: true,
      lastSeenAt: deadline - 20_000,
      turnDeadline: deadline,
      now: deadline + 60_000,
      graceMs,
      graceAlreadyUsed: false,
    };
    expect(shouldExtendTurnForReconnect(input)).toBe(true);
    expect(
      shouldExtendTurnForReconnect({ ...input, graceAlreadyUsed: true })
    ).toBe(false);
    expect(
      shouldExtendTurnForReconnect({ ...input, isCurrentPlayer: false })
    ).toBe(false);
  });

  it("does not extend after reconnect grace has elapsed", () => {
    expect(
      shouldExtendTurnForReconnect({
        isCurrentPlayer: true,
        lastSeenAt: deadline - 20_000,
        turnDeadline: deadline,
        now: deadline + graceMs,
        graceMs,
        graceAlreadyUsed: false,
      })
    ).toBe(false);
  });
});
