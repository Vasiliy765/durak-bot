import { describe, expect, it } from "vitest";
import {
  activeGroupPlayers,
  beginGroupVote,
  claimGroupResultAnnouncement,
  castExecutionVote,
  castGroupVote,
  chooseQuestionTarget,
  completeGroupResultAnnouncement,
  finishGroupRound,
  formatGroupWinnerAnnouncement,
  isActiveGroupPlayer,
  isGroupPlayer,
  joinGroupLobby,
  leaveGroupLobby,
  newGroupLobby,
  recordGroupAnswer,
  recordGroupQuestion,
  resolveGroupVote,
  startGroupRound,
  tickGroupRound,
} from "./groupGameRules";

const p1 = { id: "101", firstName: "Агент 1" };
const p2 = { id: "102", firstName: "Агент 2" };
const p3 = { id: "103", firstName: "Агент 3" };
const p4 = { id: "104", firstName: "Агент 4" };

function fourPlayerRound() {
  let state = newGroupLobby("round-test-0001", p1);
  state = joinGroupLobby(state, p2);
  state = joinGroupLobby(state, p3);
  state = joinGroupLobby(state, p4);
  return startGroupRound(state, {
    spyIds: [p3.id],
    secret: "Міжнародний аеропорт",
    category: "Транспорт",
    now: 1_000,
  });
}

function accuseSpy(state = fourPlayerRound()) {
  state = beginGroupVote(state, p1.id, 2_000);
  state = castGroupVote(state, p1.id, p3.id, 2_001).state;
  state = castGroupVote(state, p2.id, p3.id, 2_002).state;
  state = castGroupVote(state, p4.id, p3.id, 2_003).state;
  return resolveGroupVote(state, state.voteEndsAt!);
}

describe("Telegram group game state machine", () => {
  it("requires at least three players and avoids duplicate joins", () => {
    let state = newGroupLobby("round-test-0001", p1);
    expect(() =>
      startGroupRound(state, { spyIds: [], secret: "Локація", now: 0 })
    ).toThrow(/щонайменше 3/);
    state = joinGroupLobby(state, p1);
    state = joinGroupLobby(state, p2);
    expect(state.players).toHaveLength(2);
  });

  it("recognizes every joined lobby player and rejects a non-player", () => {
    let state = newGroupLobby("round-test-0001", p1);
    state = joinGroupLobby(state, p2);
    expect(isGroupPlayer(state, p1.id)).toBe(true);
    expect(isGroupPlayer(state, p2.id)).toBe(true);
    expect(isGroupPlayer(state, "outsider")).toBe(false);
  });

  it("transfers lobby ownership when its creator leaves", () => {
    let state = newGroupLobby("round-test-0001", p1);
    state = joinGroupLobby(state, p2);
    state = leaveGroupLobby(state, p1.id);
    expect(state.hostId).toBe(p2.id);
    expect(state.players.map(player => player.id)).toEqual([p2.id]);
  });

  it("assigns roles only in persisted state and routes a question and answer to selected participants", () => {
    let state = fourPlayerRound();
    expect(state.players.find(player => player.id === p3.id)?.role).toBe("spy");
    expect(state.players.filter(player => player.role === "spy")).toHaveLength(
      1
    );
    expect(state.secret).toBe("Міжнародний аеропорт");

    const askerId = state.activeAskerId!;
    const targetId = state.players.find(player => player.id !== askerId)!.id;
    state = chooseQuestionTarget(state, askerId, targetId);
    state = recordGroupQuestion(
      state,
      askerId,
      "Тут часто буває багато людей?",
      2_000
    );
    expect(state.phase).toBe("await_answer");
    expect(() => recordGroupAnswer(state, askerId, "Так", 3_000)).toThrow(
      /обраний активний гравець/
    );
    state = recordGroupAnswer(state, targetId, "Так, особливо зранку.", 3_000);
    expect(state.questions[0]).toMatchObject({
      question: "Тут часто буває багато людей?",
      answer: "Так, особливо зранку.",
    });
    expect(state.activeAskerId).toBe(targetId);
    expect(state.phase).toBe("choose_target");
  });

  it("keeps accusation open for a full minute even after a suspect majority", () => {
    let state = beginGroupVote(fourPlayerRound(), p1.id, 2_000);
    state = { ...state, voteMessageId: 987 };
    expect(() => castGroupVote(state, p1.id, p1.id, 2_001)).toThrow(/себе/);
    state = castGroupVote(state, p1.id, p3.id, 2_002).state;
    expect(() => castGroupVote(state, p1.id, p3.id, 2_003)).toThrow(
      /вже проголосували/
    );
    state = castGroupVote(state, p2.id, p3.id, 2_004).state;
    expect(state.status).toBe("voting");
    const accusation = castGroupVote(state, p4.id, p3.id, 2_005);
    expect(accusation.resolved).toBe(false);
    expect(accusation.state).toMatchObject({
      status: "voting",
      phase: "voting",
      voteStage: "accusation",
      voteMessageId: 987,
    });
    expect(
      resolveGroupVote(accusation.state, accusation.state.voteEndsAt! - 1)
        .resolved
    ).toBe(false);
    expect(() =>
      castGroupVote(
        accusation.state,
        p3.id,
        p1.id,
        accusation.state.voteEndsAt!
      )
    ).toThrow(/Час/);
    const ended = resolveGroupVote(
      accusation.state,
      accusation.state.voteEndsAt!
    );
    expect(ended.result).toBe("execution_vote");
    expect(ended.state).toMatchObject({
      status: "voting",
      phase: "execution_vote",
      voteStage: "execution",
      accusedId: p3.id,
      voteMessageId: 987,
      voteEndsAt: accusation.state.voteEndsAt! + 60_000,
    });
    expect(ended.state.guesserId).toBeNull();
    expect(ended.state.accusationVoteHistory).toHaveLength(3);
  });

  it("ends immediately with an agents win when the executed suspect is a spy", () => {
    const accusation = accuseSpy();
    expect(accusation.result).toBe("execution_vote");
    const deadline = accusation.state.voteEndsAt!;
    let verdict = castExecutionVote(
      accusation.state,
      p1.id,
      true,
      deadline - 3
    );
    expect(verdict.resolved).toBe(false);
    verdict = castExecutionVote(verdict.state, p2.id, true, deadline - 2);
    expect(verdict.resolved).toBe(false);
    verdict = castExecutionVote(verdict.state, p4.id, true, deadline - 1);
    expect(verdict.resolved).toBe(false);
    expect(() =>
      castExecutionVote(verdict.state, p3.id, true, deadline)
    ).toThrow(/Час/);
    const ended = resolveGroupVote(verdict.state, deadline);
    expect(ended.result).toBe("civilians_win");
    expect(ended.state.status).toBe("finished");
    expect(ended.state.winner).toBe("civilians");
    expect(ended.state.eliminatedPlayerIds).toContain(p3.id);
    expect(ended.state.resultText).toMatch(/негайно/);
  });

  it("eliminates executed agents and gives spies the win at one active agent versus one spy", () => {
    let state = beginGroupVote(fourPlayerRound(), p1.id, 2_000);
    state = castGroupVote(state, p1.id, p2.id, 2_001).state;
    state = castGroupVote(state, p3.id, p2.id, 2_002).state;
    state = castGroupVote(state, p4.id, p2.id, 2_003).state;
    const accusation = resolveGroupVote(state, state.voteEndsAt!);
    expect(accusation.state.status).toBe("voting");
    const deadline = accusation.state.voteEndsAt!;
    let verdict = castExecutionVote(
      accusation.state,
      p1.id,
      true,
      deadline - 3
    );
    verdict = castExecutionVote(verdict.state, p3.id, true, deadline - 2);
    verdict = castExecutionVote(verdict.state, p4.id, true, deadline - 1);
    expect(verdict.resolved).toBe(false);
    const afterFirstExecution = resolveGroupVote(verdict.state, deadline);
    expect(afterFirstExecution.state.status).toBe("playing");
    expect(afterFirstExecution.state.eliminatedPlayerIds).toEqual([p2.id]);
    expect(activeGroupPlayers(afterFirstExecution.state)).toHaveLength(3);
    expect(isActiveGroupPlayer(afterFirstExecution.state, p2.id)).toBe(false);

    const activeBallot = beginGroupVote(
      afterFirstExecution.state,
      p1.id,
      deadline + 1
    );
    expect(() =>
      castGroupVote(activeBallot, p2.id, p4.id, deadline + 2)
    ).toThrow(/активні учасники/);
    state = castGroupVote(activeBallot, p1.id, p4.id, deadline + 2).state;
    state = castGroupVote(state, p3.id, p4.id, deadline + 3).state;
    const secondAccusation = resolveGroupVote(state, state.voteEndsAt!);
    const secondDeadline = secondAccusation.state.voteEndsAt!;
    let secondVerdict = castExecutionVote(
      secondAccusation.state,
      p1.id,
      true,
      secondDeadline - 2
    );
    secondVerdict = castExecutionVote(
      secondVerdict.state,
      p3.id,
      true,
      secondDeadline - 1
    );
    const ended = resolveGroupVote(secondVerdict.state, secondDeadline);
    expect(ended.state.status).toBe("finished");
    expect(ended.state.winner).toBe("spies");
    expect(ended.state.eliminatedPlayerIds).toEqual([p2.id, p4.id]);
    expect(ended.state.resultText).toMatch(/один шпигун і один агент/);
  });

  it("spares the suspect without a strict 👍 majority and keeps accusation history", () => {
    const accusation = accuseSpy();
    const deadline = accusation.state.voteEndsAt!;
    let verdict = castExecutionVote(
      accusation.state,
      p1.id,
      false,
      deadline - 3
    );
    verdict = castExecutionVote(verdict.state, p2.id, false, deadline - 2);
    verdict = castExecutionVote(verdict.state, p4.id, false, deadline - 1);
    expect(verdict.resolved).toBe(false);
    const rejected = resolveGroupVote(verdict.state, deadline);
    expect(rejected.result).toBe("continue");
    expect(rejected.state.status).toBe("playing");
    expect(rejected.state.accusedId).toBeNull();
    expect(rejected.state.accusationVoteHistory).toHaveLength(3);
    expect(
      beginGroupVote(rejected.state, p1.id, 3_000).accusationVoteHistory
    ).toHaveLength(3);
  });

  it("treats a timed-out execution tie as no execution, but the expired round as a spy win", () => {
    const accusation = accuseSpy();
    const tied = {
      ...accusation.state,
      voteEndsAt: 10,
      roundEndsAt: 100,
      executionVotes: { [p1.id]: true, [p2.id]: false },
    };
    const spared = resolveGroupVote(tied, 11);
    expect(spared.result).toBe("continue");
    expect(spared.state.status).toBe("playing");

    const expired = resolveGroupVote({ ...tied, roundEndsAt: 5 }, 11);
    expect(expired.result).toBe("spies_win");
    expect(expired.state.winner).toBe("spies");
  });

  it("rejects repeated and non-player execution votes", () => {
    const accusation = accuseSpy();
    const voteAt = accusation.state.voteEndsAt! - 2;
    const first = castExecutionVote(accusation.state, p1.id, true, voteAt);
    expect(() =>
      castExecutionVote(first.state, p1.id, false, voteAt + 1)
    ).toThrow(/вже проголосували/);
    expect(() =>
      castExecutionVote(first.state, "outsider", true, voteAt + 1)
    ).toThrow(/активні учасники/);
  });

  it("continues after a complete non-majority accusation vote but a timed-out final accusation ends expired round for spies", () => {
    let state = beginGroupVote(fourPlayerRound(), p1.id, 2_000);
    state = castGroupVote(state, p1.id, p2.id, 2_001).state;
    state = castGroupVote(state, p2.id, p1.id, 2_002).state;
    const waiting = castGroupVote(state, p3.id, p4.id, 2_003);
    expect(waiting.resolved).toBe(false);
    const allVoted = castGroupVote(waiting.state, p4.id, p1.id, 2_004);
    expect(allVoted.resolved).toBe(false);
    const continueResult = resolveGroupVote(
      allVoted.state,
      allVoted.state.voteEndsAt!
    );
    expect(continueResult.result).toBe("continue");
    expect(continueResult.state.status).toBe("playing");

    state = {
      ...fourPlayerRound(),
      status: "voting",
      phase: "voting",
      voteEndsAt: 10,
      roundEndsAt: 10,
      votes: { [p1.id]: p2.id },
    };
    const timedOut = resolveGroupVote(state, 11);
    expect(timedOut.state.winner).toBe("spies");
  });

  it("starts an accusation ballot at round timeout and immediately finishes legacy last-guess states", () => {
    const state = { ...fourPlayerRound(), roundEndsAt: 10 };
    const started = tickGroupRound(state, 11);
    expect(started.state).toMatchObject({
      status: "voting",
      voteStage: "accusation",
      voteMessageId: null,
    });

    const spyGuess = {
      ...started.state,
      status: "spy_guess" as const,
      phase: "spy_guess" as const,
      guessEndsAt: 20,
    };
    const timeout = tickGroupRound(spyGuess, 21);
    expect(timeout.state.status).toBe("finished");
    expect(timeout.state.winner).toBe("civilians");
  });

  it("leases a final announcement to one worker and formats singular versus plural winners", () => {
    const finished = finishGroupRound(
      fourPlayerRound(),
      "spies",
      "Шпигун викритий."
    );
    const first = claimGroupResultAnnouncement(
      finished,
      "worker-a",
      1_000,
      5_000
    );
    const second = claimGroupResultAnnouncement(
      first.state,
      "worker-b",
      1_001,
      5_000
    );
    expect(first.claimed).toBe(true);
    expect(second.claimed).toBe(false);
    const completed = completeGroupResultAnnouncement(first.state, "worker-a");
    expect(completed.resultAnnounced).toBe(true);
    expect(
      claimGroupResultAnnouncement(completed, "worker-c", 6_001).claimed
    ).toBe(false);

    expect(
      formatGroupWinnerAnnouncement({
        winner: "spies",
        spyCount: 1,
        players: [{ ...p3, role: "spy" }],
      })
    ).toBe("Переміг шпигун 🕵️‍♂️ — агенти програли.");
    expect(
      formatGroupWinnerAnnouncement({
        winner: "spies",
        spyCount: 2,
        players: [
          { ...p3, role: "spy" },
          { ...p4, role: "spy" },
        ],
      })
    ).toBe("Перемогли шпигуни 🕵️‍♂️ — агенти програли.");
    expect(
      formatGroupWinnerAnnouncement({
        winner: "civilians",
        spyCount: 1,
        players: [{ ...p3, role: "spy" }],
      })
    ).toBe("Перемогли агенти 🕴️ — шпигун програв.");
  });
});
