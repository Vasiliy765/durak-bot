import { describe, expect, it } from "vitest";
import { chatPrankCategories } from "../../shared/chatPrankCatalog";
import {
  formatChatPrank,
  isEligibleChatPrankReply,
  parseChatPrank,
} from "./chatPranks";

const expectedCategories = [
  {
    title: "Романтичні дії",
    actions: ["поцілувати", "подарувати квіти", "обійняти"],
  },
  {
    title: "Дружні дії",
    actions: [
      "потиснути руку",
      "дати п'ять",
      "віддати честь",
      "пригостити кавою",
      "почастувати піцою",
      "підбадьорити",
      "похвалити",
      "дякую",
    ],
  },
  {
    title: "Жарти та приколи",
    actions: [
      "вдарити",
      "облити",
      "штовхнути",
      "кинути яйце",
      "підколоти",
      "підставити підніжку",
      "вилити відро води",
      "відлупцювати подушкою",
    ],
  },
  {
    title: "Агресивні та кумедні",
    actions: [
      "викликати на бій",
      "пригрозити",
      "заморозити",
      "обізвати жабою",
      "налякати",
      "влаштувати пастку",
      "врізати",
      "облити холодною водою",
      "сильно штовхнути",
      "дати ляпаса",
    ],
  },
];

const actor = { id: 101, name: "Василь" };
const target = { id: 202, name: "Оля" };

describe("reply-only RP chat actions", () => {
  it("has exactly the four requested categories and 29 canonical actions", () => {
    expect(
      chatPrankCategories.map(category => ({
        title: category.title,
        actions: category.actions.map(action => action.id),
      }))
    ).toEqual(expectedCategories);
    expect(
      chatPrankCategories.reduce((count, category) => count + category.actions.length, 0)
    ).toBe(29);
  });

  it("recognizes all primary and alternate triggers case-insensitively", () => {
    for (const category of chatPrankCategories) {
      for (const action of category.actions) {
        for (const trigger of action.triggers) {
          expect(parseChatPrank(trigger)?.action).toBe(action.id);
          expect(parseChatPrank(trigger.toLocaleUpperCase("uk"))?.action).toBe(action.id);
        }
      }
    }
    expect(parseChatPrank("СИЛЬНО   ВДАРИТИ")?.action).toBe("врізати");
    expect(parseChatPrank("поцілувати в щічку")).toEqual({
      action: "поцілувати",
      trigger: "поцілувати",
      suffix: "в щічку",
    });
  });

  it("accepts extra text only after a complete trigger and rejects the old catalog", () => {
    expect(parseChatPrank("поцілуватися")).toBeNull();
    expect(parseChatPrank("зробити поцілунок")).toBeNull();
    expect(parseChatPrank("/поцілувати")).toBeNull();
    expect(parseChatPrank("погладити")).toBeNull();
    expect(parseChatPrank("освідчитися")).toBeNull();
    expect(parseChatPrank("облити водою")).toEqual({
      action: "облити",
      trigger: "облити",
      suffix: "водою",
    });
  });

  it("allows a reply only to a different human Telegram participant", () => {
    expect(isEligibleChatPrankReply(actor, target)).toBe(true);
    expect(isEligibleChatPrankReply(actor, undefined)).toBe(false);
    expect(isEligibleChatPrankReply(actor, { id: actor.id })).toBe(false);
    expect(isEligibleChatPrankReply(actor, { id: 202, is_bot: true })).toBe(false);
    expect(isEligibleChatPrankReply({ id: actor.id, is_bot: true }, target)).toBe(false);
    expect(isEligibleChatPrankReply(undefined, target)).toBe(false);
  });

  it("formats Telegram ID mentions and the optional italic suffix exactly", () => {
    expect(formatChatPrank("поцілувати", actor, target, "в щічку")).toBe(
      '💋 <a href="tg://user?id=101">Василь</a> ніжно поцілував(ла) <a href="tg://user?id=202">Оля</a> 💋 <i>(в щічку)</i>'
    );
    expect(formatChatPrank("подарувати квіти", actor, target)).toBe(
      '🌹 <a href="tg://user?id=101">Василь</a> подарував(ла) чудовий букет квітів <a href="tg://user?id=202">Оля</a> 🌹'
    );
  });

  it("HTML-escapes participant names and user-provided suffix text", () => {
    const formatted = formatChatPrank(
      "обійняти",
      { id: 101, name: 'Василь <b>& "тест"' },
      { id: 202, name: "Оля > Олена" },
      "</i><a href=\"tg://user?id=9\">ін'єкція</a>"
    )!;
    expect(formatted).toContain("Василь &lt;b&gt;&amp; &quot;тест&quot;");
    expect(formatted).toContain("Оля &gt; Олена");
    expect(formatted).toContain("&lt;/i&gt;&lt;a href=&quot;tg://user?id=9&quot;&gt;");
    expect(formatted).not.toContain("</i><a href=");
  });

  it("rejects invalid Telegram IDs instead of building unsafe mentions", () => {
    expect(formatChatPrank("дякую", { id: 0, name: "Василь" }, target)).toBeNull();
    expect(formatChatPrank("дякую", actor, { id: Number.NaN, name: "Оля" })).toBeNull();
  });
});
