import { randomInt as cryptoRandomInt } from "node:crypto";

export type ArcadeGameId = "battleship" | "durak" | "blackjack" | "tic_tac_toe";

export type ArcadePlayer = {
  id: string;
  name: string;
  seat: number;
};

export type RandomInt = (maxExclusive: number) => number;

export const secureRandomInt: RandomInt = maxExclusive => {
  if (!Number.isSafeInteger(maxExclusive) || maxExclusive < 1) {
    throw new RangeError("maxExclusive must be a positive safe integer");
  }
  return cryptoRandomInt(maxExclusive);
};

export function shuffle<T>(items: readonly T[], random: RandomInt): T[] {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = random(index + 1);
    [shuffled[index], shuffled[swapIndex]] = [
      shuffled[swapIndex],
      shuffled[index],
    ];
  }
  return shuffled;
}

export type ArcadeEvent = {
  type: string;
  actorId?: string;
  at: number;
  publicText: string;
};

export type ArcadeOutcome = {
  winnerIds: string[];
  draw: boolean;
  reason: string;
  /** Players whose contributions are returned before the losing pool is shared. */
  refundIds?: string[];
  /** Relative claims on the losing pool; ordinary winners default to 1. */
  winnerWeights?: Record<string, number>;
  /** Total return multiplier (including stake) for games settled against the shared bank. */
  payoutMultipliers?: Record<string, number>;
  /** Settlement facts added by the server; never accepted from a client. */
  bankSettlement?: {
    targetPayouts: Record<string, number>;
    bankBalanceBefore: number;
    availableBank: number;
    bankBalanceAfter: number;
    bankCapped: boolean;
  };
};

export type ArcadeStep<State> = {
  state: State;
  events: ArcadeEvent[];
  outcome?: ArcadeOutcome;
  /** Additional coins that must be escrowed in the same DB transaction as this action. */
  additionalStake?: { playerId: string; amount: number };
};

export type ArcadeAction = Record<string, unknown>;

export type ArcadeEngineContext = {
  now: number;
  randomInt: RandomInt;
};

export class GameRuleError extends Error {
  constructor(
    message: string,
    public readonly code = "INVALID_ACTION"
  ) {
    super(message);
    this.name = "GameRuleError";
  }
}

export interface ArcadeEngine<State = unknown, View = unknown> {
  readonly gameId: ArcadeGameId;
  readonly minPlayers: number;
  readonly maxPlayers: number;
  create(
    players: ArcadePlayer[],
    settings: Record<string, unknown>,
    context: ArcadeEngineContext
  ): State;
  applyAction(
    state: State,
    actorId: string,
    action: ArcadeAction,
    context: ArcadeEngineContext
  ): ArcadeStep<State>;
  toView(state: State, viewerId: string): View;
  getDeadline(state: State): number | null;
  onTimeout?(
    state: State,
    context: ArcadeEngineContext
  ): ArcadeStep<State> | null;
}

export function requirePlayer(
  players: readonly ArcadePlayer[],
  playerId: string
) {
  const player = players.find(candidate => candidate.id === playerId);
  if (!player)
    throw new GameRuleError(
      "Цей гравець не бере участі в партії.",
      "NOT_A_PLAYER"
    );
  return player;
}

export function uniqueIds(ids: readonly string[]) {
  return [...new Set(ids)];
}
