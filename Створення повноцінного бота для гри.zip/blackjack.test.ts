import { describe, expect, it } from "vitest";
import {
  blackjackEngine,
  blackjackTotal,
  type BlackjackCard,
  type BlackjackState,
} from "./blackjack";
import { GameRuleError } from "./engine";

const c = (
  rank: BlackjackCard["rank"],
  suit: BlackjackCard["suit"] = "clubs"
): BlackjackCard => ({ rank, suit });
const players = [
  { id: "a", name: "A", seat: 0 },
  { id: "b", name: "B", seat: 1 },
];
const context = (now = 1000) => ({ now, randomInt: (_max: number) => 0 });
function state(
  hands: BlackjackState["hands"],
  dealer: BlackjackCard[],
  phase: BlackjackState["phase"] = "players"
): BlackjackState {
  const fullDeck = [
    "A",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "J",
    "Q",
    "K",
  ].flatMap(rank =>
    ["clubs", "diamonds", "hearts", "spades"].map(suit =>
      c(rank as BlackjackCard["rank"], suit as BlackjackCard["suit"])
    )
  );
  const used = new Set([...hands.flatMap(h => h.cards), ...dealer]);
  return {
    players,
    hands,
    dealer,
    deck: fullDeck.filter(x => !used.has(x)),
    currentIndex: 0,
    phase,
    createdAt: 0,
    deadline: 5000,
    turnMs: 60_000,
    doubleAllowed: true,
  };
}
const hand = (
  playerId: string,
  cards: BlackjackCard[],
  status: "playing" | "stood" | "bust" | "natural" = "playing"
) => ({
  playerId,
  cards,
  initialStake: 20,
  stake: 20,
  firstAction: true,
  status,
});

describe("blackjackEngine", () => {
  it("calculates hard and soft Ace totals and soft 17", () => {
    expect(blackjackTotal([c("A"), c("6")])).toEqual({ total: 17, soft: true });
    expect(blackjackTotal([c("A"), c("6"), c("9")])).toEqual({
      total: 16,
      soft: false,
    });
    expect(blackjackTotal([c("A"), c("A"), c("9")])).toEqual({
      total: 21,
      soft: true,
    });
  });
  it("deals a single 52-card deck in seat order and honors configured stake", () => {
    const s = blackjackEngine.create(players, { stake: 75 }, context());
    expect(s.hands.map(h => h.cards)).toHaveLength(2);
    expect(s.hands.map(h => h.playerId)).toEqual(["a", "b"]);
    expect(s.hands[0].stake).toBe(75);
    expect(
      s.deck.length +
        s.hands.reduce((n, h) => n + h.cards.length, 0) +
        s.dealer.length
    ).toBe(52);
  });
  it("hides hole card and opponents' hands until final, then reveals them", () => {
    const s = state(
      [hand("a", [c("10"), c("7")]), hand("b", [c("9"), c("8")])],
      [c("6"), c("K")]
    );
    const before = blackjackEngine.toView(s, "a");
    expect(before.dealer.cards[1]).toEqual({ hidden: true });
    expect(before.dealer.total).toBeNull();
    expect(before.players[1].cards).toBeNull();
    s.phase = "finished";
    expect(blackjackEngine.toView(s, "a").dealer.cards[1]).toEqual(c("K"));
  });
  it("natural beats a regular 21; natural against natural is a push", () => {
    const s = state(
      [
        hand("a", [c("A"), c("K")], "natural"),
        hand("b", [c("7"), c("7"), c("7")], "stood"),
      ],
      [c("9"), c("8")],
      "dealer"
    );
    blackjackEngine.onTimeout?.(s, context());
    // Directly exercise finalization by standing the active hand.
    s.phase = "players";
    s.currentIndex = 1;
    const result = blackjackEngine.applyAction(
      s,
      "b",
      { type: "stand" },
      context()
    );
    expect(result.state.outcome?.winnerIds).toContain("a");
    expect(result.state.outcome?.payoutMultipliers?.a).toBe(2.5);
    // The two naturals push; the other ordinary hand loses to the dealer's natural.
    const equal = state(
      [
        hand("a", [c("A"), c("Q")], "natural"),
        hand("b", [c("10"), c("8")], "stood"),
      ],
      [c("A"), c("K")],
      "players"
    );
    equal.currentIndex = 1;
    const push = blackjackEngine.applyAction(
      equal,
      "b",
      { type: "stand" },
      context()
    );
    expect(push.state.outcome?.draw).toBe(false);
    expect(push.state.outcome?.refundIds).toEqual(["a"]);
  });
  it("handles bust, push, and the all-lose refund policy", () => {
    const bust = state(
      [
        hand("a", [c("K"), c("8"), c("5")], "bust"),
        hand("b", [c("10"), c("7")], "stood"),
      ],
      [c("10"), c("9")]
    );
    bust.currentIndex = 1;
    const loss = blackjackEngine.applyAction(
      bust,
      "b",
      { type: "stand" },
      context()
    );
    expect(loss.state.outcome?.draw).toBe(true);
    expect(loss.state.outcome?.refundIds).toEqual(["a", "b"]);
    expect(loss.state.outcome?.reason).toMatch(/усі гравці програли/i);
    const mix = state(
      [
        hand("a", [c("10"), c("9")], "stood"),
        hand("b", [c("9"), c("9")], "stood"),
      ],
      [c("10"), c("9")]
    );
    mix.currentIndex = 2;
    // A Push is refunded, while the other losing hand funds the shared bank.
    const timeout = blackjackEngine.onTimeout?.(
      { ...mix, currentIndex: 0, deadline: 0 },
      context(1000)
    );
    expect(timeout?.outcome?.draw).toBe(false);
    expect(timeout?.outcome?.refundIds).toEqual(["a"]);
    expect(timeout?.outcome?.reason).toMatch(/Push-гравцям/i);
  });
  it("allows Double once, reports exact extra escrow, and rejects a second Double", () => {
    const s = state(
      [hand("a", [c("5"), c("6")]), hand("b", [c("10"), c("8")])],
      [c("9"), c("7")]
    );
    const first = blackjackEngine.applyAction(
      s,
      "a",
      { type: "double" },
      context()
    );
    expect(first.additionalStake).toEqual({ playerId: "a", amount: 20 });
    expect(first.state.hands[0].stake).toBe(40);
    const secondState = { ...first.state, currentIndex: 0 };
    expect(() =>
      blackjackEngine.applyAction(
        secondState,
        "a",
        { type: "double" },
        context()
      )
    ).toThrow(GameRuleError);
  });
  it("dealer stands on soft 17 and reveals hole card when finished", () => {
    const s = state([hand("a", [c("10"), c("8")])], [c("A"), c("6")]);
    s.hands[1] = hand("b", [c("8"), c("8")]);
    s.players.push({ id: "c", name: "C", seat: 2 });
    s.hands.push(hand("c", [c("9"), c("8")]));
    s.hands[1].status = "stood";
    s.hands[2].status = "stood";
    s.currentIndex = 0;
    const out = blackjackEngine.applyAction(
      s,
      "a",
      { type: "stand" },
      context()
    );
    expect(out.state.dealer).toHaveLength(2);
    expect(out.state.phase).toBe("finished");
    expect(blackjackEngine.toView(out.state, "a").dealer.total).toBe(17);
  });
  it("automatically stands all unfinished hands at timeout and resolves", () => {
    const s = state(
      [hand("a", [c("10"), c("8")]), hand("b", [c("9"), c("8")])],
      [c("10"), c("7")]
    );
    expect(blackjackEngine.onTimeout?.(s, context(2000))).toBeNull();
    const result = blackjackEngine.onTimeout?.(s, context(6000));
    expect(result?.state.phase).toBe("finished");
    expect(result?.events[0].type).toBe("timeout-stand");
  });
  it("exposes only active player's executable actions and honors Double settings", () => {
    const s = state(
      [hand("a", [c("5"), c("6")]), hand("b", [c("10"), c("8")])],
      [c("9"), c("7")]
    );
    expect(
      blackjackEngine.toView(s, "a").legalActions.map(a => a.type)
    ).toEqual(["hit", "stand", "double"]);
    expect(blackjackEngine.toView(s, "b").legalActions).toEqual([]);
    expect(() =>
      blackjackEngine.applyAction(s, "b", { type: "stand" }, context())
    ).toThrow(GameRuleError);
    s.doubleAllowed = false;
    expect(
      blackjackEngine.toView(s, "a").legalActions.map(a => a.type)
    ).toEqual(["hit", "stand"]);
    expect(() =>
      blackjackEngine.applyAction(s, "a", { type: "double" }, context())
    ).toThrow(GameRuleError);
  });
  it("uses configured turn duration and immediately resolves dealer natural", () => {
    const timed = blackjackEngine.create(
      players,
      { turnMs: 2500 },
      context(1000)
    );
    expect(timed.deadline).toBe(3500);
    expect(timed.turnMs).toBe(2500);
    const natural = Array.from({ length: 52 }, (_, n) =>
      blackjackEngine.create(
        players,
        {},
        { now: 1000, randomInt: max => n % max }
      )
    ).find(s => s.dealer.length === 2 && blackjackTotal(s.dealer).total === 21);
    expect(natural).toBeDefined();
    expect(natural?.phase).toBe("finished");
    expect(natural?.outcome).toBeDefined();
  });
  it("rejects invalid actors/actions and preserves original state", () => {
    const s = state(
      [hand("a", [c("10"), c("8")]), hand("b", [c("9"), c("8")])],
      [c("10"), c("7")]
    );
    expect(() =>
      blackjackEngine.applyAction(s, "b", { type: "hit" }, context())
    ).toThrow(/не ваш хід/);
    expect(() =>
      blackjackEngine.applyAction(s, "outsider", { type: "hit" }, context())
    ).toThrow(/не бере участі/);
    expect(() =>
      blackjackEngine.applyAction(s, "a", { type: "split" }, context())
    ).toThrow(GameRuleError);
    expect(s.hands[0].cards).toHaveLength(2);
  });
});
